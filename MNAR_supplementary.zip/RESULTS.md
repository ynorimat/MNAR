# Result index

This index uses the numbering in `MNAR_main.pdf`. Paths below are relative
to `results/`. The 101 files retain all numerical records, including settings
omitted from concise displays. Raw files retain runs; summary, paired and
mc files report aggregates, paired differences and Monte Carlo uncertainty.
Dated designs and the order of exploratory studies are recorded in `protocols/`.

## Paired point-estimator comparison

Appendix G.1 and Table 6: `point_baselines_raw.csv` (all 600 datasets),
`point_baselines_summary.csv` (all six design cells, bias/RMSE, Monte Carlo
SE, widths, coverage and certification), `point_baselines_population.csv`
(truth, identified endpoints and point-estimator limits), and
`point_baselines_manifest.json` (settings, seeds, checks and environment).
See `protocols/POINT_BASELINES_PROTOCOL.txt` and
`code/experiment_point_baselines.py`; Table 6 can be reconstructed with
`code/build_point_baselines_table.py`.

## Evidence retained in the main text and appendices

| Manuscript location | Complete records |
| --- | --- |
| Figure 1 | Conceptual history diagram; not an experimental result |
| Section 6.1; Appendix F.1, exact aggregation | `signed_aggregation_audit.json`, `signed_aggregation_scaling.csv` |
| Figure 2(a), cancellation; Figure 3, pooling; Appendix F.2 | `dynamic_grid.csv`, `dynamic_grid_summary.csv`, `dynamic_grid_audit.json` (all 81 settings) |
| Figure 2(b); Appendix F.3, ICU sensitivity curve | `physionet_policy_contrast.csv`, `policy_contrast_audit.json` (full radius grid; Figure 2(b) displays .05-.11) |
| Appendix F.3, aggregate clinical calibration | `physionet_initial_distribution.csv`, `physionet_empirical_transitions.csv`, `physionet_bridge_conditioning.csv` |
| Section 6.2; Appendix F.4, adverse completion | `adverse_completion_kernels.csv`, `adverse_completion_audit.json` |
| Table 3; Table 8; Appendix I, proxy/overlap grid | `overlap_raw.csv`, `overlap_summary.csv` (all 54 design/pair cells, both methods and the oracle decomposition) |
| Appendix D.2, exact state-sufficiency example | `state_sufficiency_check.csv`; `code/check_state_sufficiency.py` reproduces it with exact rational arithmetic |
| Table 4; Appendix F.5, heterogeneous effects | `heterogeneous_contrasts.csv`, `heterogeneous_summary.csv` (all 93 design/radius combinations) |
| Table 5; Appendix G, original inference | `state_confidence_raw.csv`, `state_confidence_summary.csv`, `state_confidence_paired.csv`, `state_confidence_width_mc.csv`, `state_confidence_paired_mc.csv` |
| Table 5; Appendix G, larger-sample follow-up | `state_confidence_followup_raw.csv`, `state_confidence_followup_summary.csv`, `state_confidence_followup_paired.csv` |
| Table 7; Appendix H.2, sequential refinement | `refinement_raw.csv`, `refinement_summary.csv`, `refinement_paired.csv` (600 datasets, 48 method summaries) |
| Appendix H.2, seeds/counts/runtime/validation | `refinement_manifest.json`, `refinement_design_0_counts.npz` through `refinement_design_5_counts.npz`, `refinement_serial_timings.csv`, `refinement_checks.json` |
| Appendix J, shared observed row | `comparison_shared_row_raw.csv`, `comparison_shared_row_summary.csv`, `comparison_shared_row_mc.csv` (all eight settings) |
| Appendix E, general-history implementation checks | `experiment_sequential_sharpness.csv`, `audit_theory.json`, `counterexample_summary.csv`, `common_observed_law.csv` |

Tables 1, 2 and 9 compare guarantees, assumptions and prior work; they are not
empirical summaries. Table 3 contains all three q values at fixed
T=6, n=128000, behavior probability .5 and the middle switch. The broader
overlap study includes unfavorable behavior probabilities and sample sizes.
Table 7 combines endpoint, width and certification summaries for
all 12 refinement cells; none of that study's settings has been dropped.

## Auxiliary studies indexed by the appendices

These are retained for transparency, including unsuccessful outcomes. They
are not additional claims of small-sample performance for the proposed method.

| Study and current pointer | Complete records |
| --- | --- |
| Conditional-row refinement; Appendix H.1 | `consistency_local_raw.csv`, `consistency_local_summary.csv` (all six settings), `consistency_local_manifest.json` |
| Propagation timing; Appendix H.1 | `consistency_scaling.csv` (all four state counts, including no speedup at the largest size) |
| Same-sample selection; end of Appendix J | `comparison_selection_raw.csv`, `comparison_selection_summary.csv`, `comparison_selection_followup_raw.csv`, `comparison_selection_followup_summary.csv`, `comparison_selection_paired_widths.csv` |
| Sensitivity-anchor examples; end of Appendix D.6 | `anchor_diagnostic_examples.csv`, `anchor_diagnostic_grid.csv`, `anchor_diagnostic_summary.csv`, `anchor_diagnostic_audit.json` |

## Earlier development studies retained without new performance claims

- `endpoint_inference_*`, `ranking_certificates_*`, `local_confidence_*`:
  earlier general-history/two-stage inference and ranking studies.
- `seed_overlap_validation_*`: superseded runs with overlapping seed formulas,
  disclosed in `protocols/DYNAMIC_AND_RANKING_PROTOCOL.md`; subsequent validation
  uses the corrected disjoint seed block.
- `consistency_state_margins.csv`, `consistency_proxy_margins.csv`: endpoint-margin
  reanalyses of retained studies.
- `physionet_gamma_calibration.csv`, `physionet_mc_raw_50k.csv`,
  `physionet_semisynth_summary_50k.csv`, `physionet_population_summary.csv`,
  `proxfqe_*`, `gamma_min_*`, `population_results.csv`, `runtime.json`:
  earlier calibration and auxiliary comparisons.

The combined raw refinement CSV retains every run; its six NPZ files retain
the observed counts. Redundant per-design CSV checkpoints were already replaced
by the combined file and can be regenerated by a new experiment run.

## Numerical checks and display generation

`verification/validation_summary.json` records eight focused checks and
their scope. `code/run_validation.py --output verification_new` repeats
them in a separate working copy. It does not rerun the full simulations.

Figure 3 shows the pooling panel; cancellation appears in Figure 2(a).
`code/build_appendix_display.py` rebuilds its input from `dynamic_grid.csv`
without modifying experimental records. The source archive supplies
the standalone TeX and compiled vector PDF.
