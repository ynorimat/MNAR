# Finite-state confidence extension: fixed protocol (2026-09-17)

Purpose: retain the population three-flow contribution and examine finite-sample
outer inference under a stronger, explicitly observable state-sufficiency
condition. No latent reward completions are pooled. Classical rectangular
robust dynamic programming is a cited ingredient, not a novelty claim.

Before running new Monte Carlo results, fix the following settings.
- Reuse the original treatment-dependent four-state binary Y/Z/R DGP.
  Proxy strength .8, observation intercept .8, kappa .04, Gamma .1.
- Horizons 3, 6, 12; n=4000,16000,64000; 100 independent datasets per cell.
- Behavior actions are fair binary draws. Estimators do not receive propensities.
- Policy zero takes action zero throughout; each alternative takes action one
  from first disagreement 0, floor(T/2), or T-1 onward. All three use the same
  dataset. Reward weights are 1/T.
- Confidence event: Bonferroni Clopper--Pearson intervals for every baseline
  state, stage/state/action observed atom, complete-case proxy conditional,
  and transition-coordinate probability. Empty cells receive [0,1]. Alpha .05.
- Compare the three-status robust recursion and subtraction of two separate
  robust policy-value intervals using EXACTLY the same confidence inputs.
- Include estimated transitions. The original population law supplies evaluation
  targets, not inputs to the confidence algorithm.
- Record identified-set coverage, wrong robust certificates, correct certificates,
  abstention, width, paired width differences, interval-construction runtime,
  sparse cells and LP fallback flags. Keep every setting and repetition.
- The new data consist of 900 independent Markov count tables; the three policy
  comparisons are paired. Aggregate multinomial generation is an exact simulator
  of the fixed observed Markov law; it is checked against individual trajectories.
- Seed base 202609170800000; seed=base+100000*horizon_index+1000*n_index+rep.
  Check disjointness against existing experiment seed columns.

Independent numerical checks before Monte Carlo: interval-simplex extrema against
linear programming, singleton-confidence recursion against original three flows,
coverage against finite enumerated uncertain models, algebraic containment in the
separate-policy interval, identical-policy zero interval, and empty-cell behavior.
These are implementation checks, not a formal proof certificate.

No clinical records are reprocessed. Existing simulations remain unchanged.
