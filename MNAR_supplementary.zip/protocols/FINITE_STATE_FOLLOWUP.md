# Disclosed sample-size follow-up (2026-09-17)

The initial fixed 900-dataset study has finished. All 27 three-status cells
covered the population interval in every run, but none certified a ranking.
These inconclusive primary results are retained alongside the follow-up.

To distinguish practical conservatism from failure to reach nonempty certificates,
we add n=128000 and n=256000 for EACH of the original three horizons and all
three policy pairs. The law, radius, confidence allocation and methods remain
unchanged. There are 100 new datasets per horizon/sample-size cell (600 in total).
Seed base 202609171900000; disjointness is checked against the primary and all
existing seed columns. All outcomes, including non-improvements, will be reported.
These settings were fixed after examining the initial results and before running
this follow-up; they are not described as independently preregistered settings.
No further method tuning is planned in response to these results.

Primary summary SHA256: 704417f539752bc9238d3a11efa4ed70065fe25eb886c3acf90e72a2961ab424
