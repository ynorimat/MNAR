# Additional studies: fixed protocol, 2026-09-17

This protocol was written before executing the additional Monte Carlo studies.
The earlier supplied studies are retained with their original provenance.

## Exact computation

Implement a three-flow recursion for two deterministic finite-state policies:
common paths, paths exclusive to policy 1, and paths exclusive to policy 2.
Validate against full observed-history enumeration, including random kernels,
identical policies, policies that disagree and later choose the same action,
and the existing ICU-calibrated benchmark. Check the exact pooling-gap identity.
Measure runtime and state/history counts at prespecified horizons 3, 5, 7, 9,
15, 30; omit full enumeration when its predicted size exceeds 1,000,000 paths.

## Heterogeneous-effect benchmark

Keep the supplied aggregate ICU initial distribution and transition matrices.
Use three decisions; compare the existing missingness-aware and state-only
policies. Replace the treatment log-odds effect in the synthetic reward by
tau = current_state + eta*(1-previous_observation) - 0.3*age_bin, with
eta in {0, 1.1, 2.0}. The reward intercept remains 0.15 - 1.05*next_state.
Keep the observation mechanism at exact shadow validity (kappa=0).
Evaluate every radius in {0, .01, ..., .30}; report all three designs and the
direction of their true contrast. No design is selected by observed results.
These are sensitivity analyses of a fixed observed law for each design.

## Finite-sample endpoint and outer-confidence study

Use the supplied two-stage binary enumeration with kappa=.1, Gamma=.2, and
its known behavior randomization. Compare two policies that share first action
1 and then use, respectively, d1(h)=1{z1=1 or r1=0} and d2(h)=1{z1=1}.
Generate independent multinomial observed-trajectory counts at n in
{1000, 4000, 16000, 64000}, 200 replications per n. Seeds are
2027091700 + 100000*j + r, with j the ordered sample-size index and r=0,...,199.

Report empirical plug-in feasibility and conditional endpoint RMSE; retain
every infeasible run. Do not silently enlarge Gamma or smooth empty cells.
For known randomization, also form a conservative trajectory-LP outer region
using simultaneous exact binomial intervals for observed-atom probabilities
and complete-case conditional proxy probabilities. Allocate alpha=.05 equally
across the prespecified scalar intervals, use both tails, and report coverage
of BOTH population identified-set endpoints, mean width, and its MC standard
error. Count an infeasible confidence LP as noncoverage. This is an outer
confidence interval, not a claim of sharp finite-sample inference or efficiency.

Diagnostic executions may test numerical implementation on separate seeds.
They do not select designs, sample sizes, radii, or reported settings. All final
scheduled results, including failures, must remain in the shipped CSV files.

## Transparent reporting addendum

The common reporting slice Gamma=.08 matches the already-existing policy-ranking
benchmark; all 31 radii are retained. After the scheduled studies and their
first inspection, an additional deterministic comparison was added: subtract
the separately sharp single-policy value intervals on the same three designs
and all the same radii. This derived comparison uses no new sampled data or
selected settings. It was not part of the initial fixed protocol. The source
records these endpoints as `separate_lower` and `separate_upper`.
