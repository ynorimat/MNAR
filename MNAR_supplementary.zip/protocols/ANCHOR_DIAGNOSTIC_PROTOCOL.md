# Continuation: oracle anchor diagnostic and comparison presentation

This study is fixed before calculating its results. It does not select a sensitivity
radius for the ICU analysis. Existing ranking-validation results are unchanged.

Use the complete action-dependent MNAR generator specified in Appendix F.2.
Fix T=6 and randomized behavior .5. Cross q=(.6,.8,.95), measurement intercept
b=(-1.8,-.4,.8), and direct proxy coefficients kappa=(0,.04,.2,.5): 36 laws.
For each law, compute the true uniform conditional shadow violation exactly.
Compute oracle full P(R_next=1|t,S,A) and oracle reduced predictions omitting
one of previous proxy, previous observation indicator, or action. Marginalize
using exact behavior occupancies and report weighted 95th percentiles and
maxima of their absolute log ratios for all three omissions: 108 rows.
The 95th percentile is the smallest value whose cumulative mass is at least .95.
No fitted classifier, Monte Carlo, sampling split, or hyperparameter search is used.

Also evaluate three pre-specified binary demonstrations, with all probabilities
positive: (1) balanced Y and noisy proxy with agreement .8, observation .8/.2
by Y and no direct Z effect; (2) agreement .75, observation .8 for Y=Z and .2
otherwise; (3) rare Z=1 with probability .01, independent balanced Y, observation
.1 for rare Z and .9 otherwise. The observed-predictor anchor in these examples
drops Z itself, strengthening the demonstration that the observational scale
need not bound the latent conditional scale. The third isolates tail loss.

Retain all laws, anchors, exact probability checks and counterexamples. Add the
result to the appendix and state its limitation in the main discussion. The
clinical anchors remain descriptive; no link from their values to a clinical
latent radius is asserted. This is a fixed experimental protocol, not preregistration.
