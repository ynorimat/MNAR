# Proxy-strength and behavior-overlap protocol (2026-09-24)

This protocol extends the initial finite-state inference experiment.
It is an exploratory, disclosed extension, not a preregistered confirmation.
The following settings are fixed before executing the new Monte Carlo study.

## Fixed diagnostic design

- Reuse the four-state treatment-dependent MNAR model and its existing local
  confidence LP and three-status algorithm, with no tuning to new results.
- Horizon 6; proxy strength q in {0.6, 0.8, 0.95}; observation intercept 0.8;
  kappa 0.04; Gamma 0.1; reward weights 1/6.
- Independent behavior action probability P(A=1)=p in {0.1, 0.5, 0.9}.
  The estimator is not supplied p. Simulation alone uses this parameter.
- n in {64000, 128000}; 100 independent datasets per design cell, hence
  1800 datasets. Three fixed policy pairs reuse each dataset: action zero
  versus permanently switching to action one at stage 0, 3, or 5.
- Alpha=0.05, with the original Bonferroni budget and two-sided
  Clopper--Pearson scalar intervals. No pooling across time.
- Compare the original three-status and separate-policy bounds, and retain
  every design cell, seed, interval, coverage, certificate, LP fallback,
  empty-cell count, and runtime.
- Diagnostic only: replace initial and transition confidence sets by their
  exact population rows while retaining the estimated local reward intervals.
  This oracle is unavailable to the estimator. Its difference from the full
  width measures the total effect of uncertainty about observed dynamics,
  not solely the loss from relaxing shared-row compatibility. Subtract the
  population sharp width to report residual local reward uncertainty.
- Seed base 202609240000000, plus 100000*design_index + replication;
  check against all previously recorded seed columns before running.
- Report pointwise Monte Carlo intervals for coverage/certification rates,
  separately from the nominal 95% identified-set confidence level.

## Mathematical scope

Population LPs must handle zero-complete-case strata explicitly. The
propagation perturbation bound and the consistency result for a summable
confidence-error schedule are separate from the fixed-alpha experiment.
The study does not claim a finite-sample LP rate.

## Integrity

Raw records from the preceding experiments remain available. Outputs use
the overlap prefix. PhysioNet Set A is used only for an aggregate calibration
check; individual patient records are not distributed. Record numerical
checks and their limitations alongside the results.
