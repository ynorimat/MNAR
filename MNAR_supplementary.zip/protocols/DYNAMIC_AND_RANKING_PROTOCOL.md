# Dynamic-model and ranking studies: fixed before execution

The existing 800 runs have already been inspected: none of their outer intervals
certifies either policy. Those runs will be retained, not replaced. This
protocol is not an external preregistration.

## Finite-sample ranking certificates

Retain the original two-stage design, kappa=.1, Gamma=.2, known behavior law,
policies, reward support {-1,+1}, weights (1,1), and simultaneous confidence LP.
Change only the stage-two treatment log-odds coefficient from .6 to 2.4, -2.4,
or 0. These settings test larger positive effects, reverse effects, and a null.
Run every new setting at n=1000,4000,16000,64000 with 200 independent replications.
Use seed 2027091800 + 1000000*j + 100000*k + r, with j indexing (2.4,-2.4,0),
k the sample sizes, and r=0,...,199. Retain every run and failure. Reuse the
original .6 setting as the difficult-margin reference.

A positive/negative certificate requires the outer lower endpoint >0 / upper
endpoint <0, respectively. A robustly correct certificate has the same strictly
signed population identified interval. A false robust certificate asserts a
direction not valid for every population-compatible law; separately report
certificates contradicting the generating causal truth. All other cases,
including failed LPs, abstain. Report denominators, exact binomial MC intervals,
identified-set coverage, mean width, and all three decision outcomes.

## Treatment-dependent, fully specified MNAR dynamics

Use S=(previous proxy, previous reward-observation indicator), initial masses
P(S=(-1,1))=P(S=(1,1))=.5, randomized behavior pi=.5, and a stage joint kernel:
P(Y=1|s,r,a)=expit(-.25+.5*s+.9*a),
P(Z=1|Y=y,s,r,a)=expit(logit(q)*y+.35*s-.6*a),
P(R=1|y,z,s,r,a)=expit(b+1.1*y+.2*a+.1*r+.04*z).
Thus action changes the future observed state, R is MNAR, and shadow exclusion
is imperfect. Set Gamma=.1, which contains the generating law because 2*.04<.1.
Use all q in {.6,.8,.95}, b in {-1.8,-.4,.8}, horizons T in {3,6,12}, and first
disagreement j in {0,floor(T/2),T-1}: 81 settings. Policy 1 treats only at j;
policy 2 never treats. Both use zero action afterward, while full histories
retain the past disagreement. Normalize reward weights to 1/T in this grid.

Report exact true contrasts, sharp/mean-pooled/separate-value intervals,
common-history cancellation gain, observed missingness, and action-dependence
of the next-state kernel. Check all identities. For T=3 independently enumerate
full observed histories including actions and observed rewards. Report every
setting, not selected examples. These are population computations, separate
from the known-behavior trajectory-LP inference study.

## Explicit adverse completion

At the original ICU benchmark Gamma=.08, construct and export a complete set
of local reward/observation kernels attaining the negative sharp contrast.
Use the fitted observed law and known behavior kernel; select lower/upper local
optimizers by the full-history coefficient sign. Verify observed-law agreement,
clock constraints, and both policy values under this single full-data law.

## Theory and presentation checks

Separate equal mean ranges from equal local polytopes. The sign-first aggregation
gap concerns common mean ranges. Interpreting the pooled calculation as equality
of full completion kernels needs equal polytopes, or an intersection with the
same attainable mean range. Add the exact common-history cancellation identity.
Document the response-odds/probability nesting and give an explicit sufficient
condition for inner semicontinuity. Move descriptive calibration anchors to
the appendix; do not compare their quantiles to a uniform latent radius as an
empirical conclusion. No claim of efficient finite-sample inference is made.

## Recorded methodological follow-up after the first ranking study

The initial ranking results showed only 27/200 and 6/200 correct certificates
at n=64000 for effects +2.4 and -2.4, respectively. We therefore develop a
contrast-specific specialization for the two-stage, one-disagreement-history
case. Its identity is Delta=p_h*(m_1-m_0). Construct 17 simultaneous exact
binomial intervals: one for p_h conditional on the common first action, and
six observed-outcome-atom probabilities plus two proxy conditionals for each
of the two relevant second-stage action cells. Solve an eight-variable local
outer LP for each action; multiply the difference interval by the p_h interval
using all four endpoint products. This is a restricted-case method, not a
polynomial-time inference result for the general three-flow theorem.

Before executing this comparison, fix an independent validation set with every
effect in {.6,2.4,-2.4,0}, every n=1000,4000,16000,64000, and 200 replications
per cell. Seeds: 2027091900+1000000*j+100000*k+r, indices in the stated order.
On the same fresh counts compare the original 196-interval trajectory LP and
the 17-interval local construction, both at alpha=.05. Report all 3,200 paired
replications and all failures; retain the initial development results separately.
The confidence construction and all reported settings are fixed before these
fresh runs. The study sequence is disclosed rather than retrospectively called
part of the initial protocol.

## Validation seed correction before a fresh rerun

A final audit found that the initial development and validation seed formulas
had overlapping integer seeds (their base values differed by only 100 while
replications run from 0 to 199). Although paired effects differed, those runs
are not presented as an independent validation set. Their raw and summary
records are retained as `seed_overlap_validation_*` for transparency.
All models, methods, sample sizes, classifications, and plotting choices remain
fixed. Before rerunning, replace the validation base by **202709190000**, with
seed `202709190000+1000000*j+100000*k+r`. These 3,200 distinct seeds are disjoint
from all development and original endpoint-study seeds. The paper reports only
this corrected, fresh validation; no choice is tuned using its outcomes.
