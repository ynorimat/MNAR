# Shared-row and policy-selection diagnostics (2026-09-24)

This exploratory protocol is fixed before executing the new diagnostics below.
It examines shared-transition relaxation and same-sample policy selection.
It is not a preregistered confirmatory study. All earlier raw results are retained.

## A. Exact comparison on the same confidence inputs

Use three stages, three states, a known initial state, known rewards and known
transitions except one shared Bernoulli row with probability p=0.4. Policies
disagree at the first action, reach that row with probabilities a=1 and
b in {0, 0.25, 0.75, 1}, and then use the same actions. Only the terminal
success-state reward is one; all other rewards are zero. For each b and
conditional row sample size N in {200, 2000}, draw 100 independent binomial
counts, using seeds 202609246000000 + 10000*design + repetition. Construct a
two-sided 95% Clopper--Pearson interval [l,u] for that one unknown row.

Under the SAME input set, the exact shared-model contrast is (a-b)*p, so its
endpoints are (a-b)*l and (a-b)*u. Solve that one-dimensional optimization
independently with scipy.linprog. Compare to the unmodified three-status
recursion, whose endpoints should be a*l-b*u and a*u-b*l. Retain endpoints,
widths, coverage, certification, and both numerical residuals for every run.
N counts visits to the uncertain row, not whole trajectories. This diagnostic
isolates shared-transition rectangularization with exact rewards; it does not
measure the complete MNAR confidence construction's efficiency.

## B. Selection of both policies on the evaluation sample

Use the existing four-state treatment-dependent MNAR law with T=3,
q=0.8, b=0.8, kappa=0.04, Gamma=0.1, balanced behavior, weights 1/T,
alpha=0.05, and n in {4000, 64000, 128000}. Run 100 independent datasets
per n with seeds 202609247000000 + 10000*design + repetition.

The candidate class is all 16 stationary deterministic action maps on the four
fixed states. Use each dataset to build the unchanged confidence inputs and
to rank candidates by plug-in value: midpoint local reward bounds, empirical
initial probabilities, and empirical transition rows (uniform if empty).
Choose the largest- and smallest-value candidates; ties go to the smallest
binary-encoded policy index. Neither the true observed rows nor latent rewards
enter selection. Compare the selected pair with the existing three-status and
separate intervals and its sharp population interval. Retain every record,
selected policy IDs, fallbacks, coverage, correct/false certification, and widths.
Use pointwise exact 95% binomial Monte Carlo intervals for reported rates.
Do not retune the selection rule, DGP, sample sizes, or candidate class after
observing results. Empirical coverage assesses this selection rule only, not
the theorem's event for all policy pairs and not conditional coverage.

## Validation and reporting

Check seed disjointness against the other experiments' CSV seed columns. Check exact-row
endpoints against both an independent LP and the existing recursion. Check
population selected-pair endpoints against the original forward three-flow
implementation. Report all settings and failures, irrespective of results.
Regenerate manuscript summaries from retained CSVs. Preserve existing raw CSVs
byte-for-byte and record their hashes. Verify that the manuscript builds from the retained results.
Recheck all 4,000 Set-A records and the exported
adverse completion separately; do not distribute individual clinical records.

## Disclosed selection follow-up (after diagnostic B)

Diagnostic B completed with the same selected pair in every replication.
Before further execution, add a null-effect DGP that sets the action
coefficients in the reward, proxy, and observation logits to zero. Equivalently,
use the original action-zero joint law for BOTH actions. This gives identical
observed dynamics and generating rewards under either action, while the MNAR
sensitivity class still permits history-specific completions. Keep T=3,
Gamma=0.1, the candidate class, selector, confidence construction, and all other
parameters unchanged. Use n in {4000, 64000}, 100 datasets per size, with seeds
202609248000000 + 10000*design + repetition. Retain B unchanged and label the
new outputs as a disclosed follow-up. Report selected-pair diversity, identified-
set coverage and false certification, including inconclusive results. Do not
claim that simulation establishes the uniform or conditional coverage theorem.
