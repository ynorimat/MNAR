# Aggregation, endpoint margins, and local confidence relaxation

This exploratory protocol was written before running the diagnostics below.
It is not a preregistered study. Raw files from the preceding experiments
remain available.

## Reanalysis of retained results

Report population lower endpoints, mean estimated lower endpoints, endpoint
slack, and certification from every original finite-state and overlap/proxy
record. Main-text slices are fixed at T=12 (the original confidence table) and
T=6, balanced behavior, middle split (the three original proxy strengths and
both sample sizes). No selection by observed certification is performed.

## Equivalent computational improvement

Reuse one sorted coordinate order for each continuation vector at each stage.
The box-simplex feasible sets, confidence allocation, and inferential targets
are unchanged. Check the optimized recursion against per-row sorting,
independent general linear programs, and the existing forward-flow checks.
Report propagation timings for m=4,16,64,128 at T=6, with a fixed random seed,
as descriptive measurements excluding counting and reward LP construction.

## Local statistical-relaxation diagnostic

Use one conditional row of the original DGP, state (-1,1), action 0, with
q in {0.6,0.8,0.95}, b=0.8, kappa=0.04, Gamma=0.1. Draw N in {500,5000}
observed tuples, 30 repetitions per design, using seed base 202609243000000
and seed base+10000*design_index+replication. N counts visits to this one row,
not total trajectories. All six designs are retained. The scalar interval
budget is the same eight probabilities per row, total alpha=0.05.

Compare the original local outer LP with a tighter outer construction using
the same scalar confidence intervals. Partition each of the two complete-case
proxy intervals into four equal subintervals (16 rectangles). Within a rectangle,
require its proxy probabilities to be consistent with the complete-case masses
of the same candidate observed law, and apply the original sensitivity envelope
using that rectangle's endpoints. Optimize over the union of the 16 LPs.
This remains an outer bound, not exact joint nonlinear optimization. It contains
every jointly feasible law and is nested in the original local outer interval.
For population interval [L,U], let Wpop=U-L, Wbase=base width and Wpart=partition
width. Report Wbase-Wpart (a demonstrated removable relaxation component) and
Wpart-Wpop (sampling uncertainty plus remaining relaxation). Do not label the
latter term pure sampling error. Retain signed increments, all solver statuses,
coverage indicators, endpoints, seeds and runtime. Numerical solver failures
use the full reward range for the affected branch; infeasibility excludes only
that rectangle. This diagnostic is separate from the principal estimator.

## Validation and reporting

Recheck all 4000 PhysioNet Set-A records against the retained aggregate
tables, and reevaluate the exported adverse completion. Run focused checks for
the local construction and the existing theory/recursion implementation.
Retain the earlier validation records.
Record software versions and hashes of unchanged raw records. Build the PDF
with the supplied unmodified venue style, inspect rendered pages, check main
text length and references, and distribute code and actual outputs. Checks are
AI-assisted numerical checks, not independent human proof verification.
