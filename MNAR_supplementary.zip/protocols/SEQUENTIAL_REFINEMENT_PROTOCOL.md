# Sequential local-consistency refinement: fixed exploratory protocol

Written 2026-09-24 before drawing the new stochastic samples. This extension
addresses limitations observed in the preceding experiments; it is exploratory,
not preregistered confirmation. Results of the preceding experiments remain available.

## Design

Use the published four-state law in Appendix F.2: T=6, b=.8, kappa=.04,
Gamma=.1, alpha=.05, balanced behavior, and rewards weighted by 1/6.
Cross q in {.8,.95} with n in {32000,64000,128000}; retain 100 independent
datasets per cell. These six settings are fixed before execution. Deterministic
population calculations, but no new sample outcomes, informed this design.

Compare identical scalar confidence inputs using the original local LP and
the four-pieces-per-proxy partition in Appendix K (16 rectangles, at most
32 endpoint LPs per nonempty row). Apply the same confidence recursion to both.
Each dataset is reused for two prespecified pairs:

1. Middle switch: first takes action 1 from t=3 onward; second always takes 0.
2. State-dependent: first takes 1 when Z_previous=1 or R_previous=0;
   second takes 1 only when Z_previous=1. These decisions depend on each path,
   and their first disagreement is not a fixed time.

Compute both three-status and separate-value intervals. Population endpoints
are evaluated by the existing forward method and exact-input backward method.
Report every design/pair/method: endpoints, widths, identified-set coverage,
positive certificates, false certificates, paired changes and Monte Carlo SEs.
Coverage and certification rates receive pointwise exact 95% binomial intervals.
No method/setting is selected or dropped based on its results.

Seeds are 202609249000000 + 10000*design + repetition, designs ordered by
q then n. Check nonoverlap with all other experiment seeds. Retain initial
and observed counts, seed, endpoints, LP flags, timings and version information.
Empty rows retain [-1,1]. A numerical failure or empty partition union falls
back to the original local outer interval and is recorded. This preserves the
coverage event and nesting; failures are never discarded.

## Validation and scope

Check exact-input agreement with the population LP and the forward recursion,
samplewise nesting, and identical initial/transition confidence sets. Independently
enumerate full observed histories for the state-dependent pair at T=3.
Recheck the existing shared-row and state-confidence invariants. Reparse the
4000 PhysioNet Set-A records without redistributing individual records.

The experiment tests fixed sufficient observed states. It does not establish
robustness to approximate sufficiency, fixed-alpha asymptotic consistency,
small-sample efficiency generally, or conditional post-selection coverage.
The primary experiments remain available. Runtime comparisons are
descriptive: one BLAS/OpenMP thread per worker, up to four workers, with CPU
contention; a separate serial timing check is reported if performed.
