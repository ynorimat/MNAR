from itertools import product
import pandas as pd


def observed_atoms(model):
    rows = []
    for u, z, r in product([0, 1], [0, 1], [0, 1]):
        p0 = 1 / 8
        if model == "stable":
            action_probs = {0: 0.5, 1: 0.5}
        else:
            action_probs = ({0: 1.0 - u, 1: float(u)} if r == 0
                            else {0: 0.5, 1: 0.5})
        for a, pa in action_probs.items():
            if pa == 0:
                continue
            y2 = a if model == "stable" else (u if r == 0 else a)
            rows.append({"Z1": z, "R1": r, "R1Y1": r * u,
                         "A1": a, "Y2": y2, "prob": p0 * pa})
    return (pd.DataFrame(rows)
            .groupby(["Z1", "R1", "R1Y1", "A1", "Y2"], as_index=False)["prob"].sum()
            .sort_values(["Z1", "R1", "R1Y1", "A1", "Y2"])
            .reset_index(drop=True))

if __name__ == "__main__":
    from pathlib import Path
    stable = observed_atoms("stable")
    unstable = observed_atoms("unstable")
    assert stable.equals(unstable)
    # Direct enumeration after fixing A1=1, without factual-treatment weights.
    vs = sum(1 / 8 for u, z, r in product([0, 1], repeat=3))
    vn = sum((1 if r else u) / 8 for u, z, r in product([0, 1], repeat=3))
    assert vs == 1.0 and vn == 0.75
    out = Path(__file__).resolve().parents[1] / "results"
    stable.to_csv(out / "common_observed_law.csv", index=False)
    pd.DataFrame([{"model": "stable", "value_always_treat": vs},
                  {"model": "unstable", "value_always_treat": vn}]).to_csv(out / "counterexample_summary.csv", index=False)
    print("Observed laws identical:", stable.equals(unstable))
    print("Direct intervention values:", vs, vn)
