#!/usr/bin/env python3
"""Validate exact state aggregation and run prespecified heterogeneous designs."""
import argparse
import itertools
import json
import time
from collections import defaultdict
from functools import lru_cache
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import expit

import experiment_policy_robustness as old
import run_physionet_semisynthetic as phys
from sign_preserving import iter_signed_flows, signed_flows, contrast_bounds

ROOT=Path(__file__).resolve().parents[1]


def enumerated_flows(initial, transition, p1, p2, horizon):
    """Independent full-history enumeration retaining all action coordinates."""
    one={(s,):v for s,v in initial.items()}
    two=dict(one);out=[];counts=[]
    for t in range(horizon):
        coefficients=defaultdict(float)
        for history,mass in one.items():coefficients[history,p1(t,history[-1])]+=mass
        for history,mass in two.items():coefficients[history,p2(t,history[-1])]-=mass
        pos,neg=defaultdict(float),defaultdict(float)
        for (history,action),c in coefficients.items():
            if c>=0:pos[history[-1],action]+=c
            else:neg[history[-1],action]-=c
        out.append((dict(pos),dict(neg)));counts.append(len(one)+len(two))
        if t==horizon-1:break
        def advance(masses,policy):
            nxt=defaultdict(float)
            for history,mass in masses.items():
                a=policy(t,history[-1])
                for state,prob in transition(t,history[-1],a).items():
                    nxt[history+(a,state)]+=mass*prob
            return dict(nxt)
        one,two=advance(one,p1),advance(two,p2)
    return out,counts


def flow_error(first,second):
    return max([0.]+[abs(a.get(key,0)-b.get(key,0))
        for pair1,pair2 in zip(first,second) for a,b in zip(pair1,pair2)
        for key in a.keys()|b.keys()])


def validations():
    rng=np.random.default_rng(17202609);maximum=0.
    for j in range(40):
        horizon=5;states=range(3)
        initial=dict(enumerate(rng.dirichlet(np.ones(3))))
        kernels={(t,s,a):dict(enumerate(rng.dirichlet(np.ones(3))))
                 for t in range(horizon) for s in states for a in range(2)}
        first=rng.integers(0,2,(horizon,3));second=rng.integers(0,2,(horizon,3))
        if j%4==0:second=first.copy()
        if j%4==1:
            second=first.copy();second[0]=1-first[0]  # remerge in state and action later
        p1=lambda t,s:int(first[t,s]);p2=lambda t,s:int(second[t,s])
        transition=lambda t,s,a:kernels[t,s,a]
        flow=signed_flows(initial,transition,p1,p2,horizon)
        ref,_=enumerated_flows(initial,transition,p1,p2,horizon)
        maximum=max(maximum,flow_error(flow,ref))
        endpoints={(t,s,a):tuple(sorted(rng.uniform(-1,1,2)))
                   for t in range(horizon) for s in states for a in range(2)}
        a=contrast_bounds(flow,lambda t,s,a:endpoints[t,s,a])
        b=contrast_bounds(ref,lambda t,s,a:endpoints[t,s,a])
        streamed=contrast_bounds(iter_signed_flows(initial,transition,p1,p2,horizon),
                                 lambda t,s,a:endpoints[t,s,a])
        assert all(abs(a[k]-streamed[k])<1e-12 for k in a)
        maximum=max(maximum,max(abs(a[k]-b[k]) for k in a))
        if j%4==0:assert abs(a['lower'])+abs(a['upper'])<1e-12
    assert maximum<1e-10
    init,tr=old.read_mdp(ROOT);coeff=old.contrast_coefficients(init,tr)
    start={(s,ag,1):v for (s,ag),v in init.items()}
    def transition(t,s,a):
        joint=phys.local_joint(t,s,a,0.,tr)
        return {(z,s[1],r):sum(joint[y,z,r] for y in [-1,1])
                for z in [-1,1] for r in [0,1]}
    flows=signed_flows(start,transition,lambda t,s:int(s[0]==1 or s[2]==0),
                       lambda t,s:int(s[0]==1),phys.T)
    errors=[]
    for gamma in [0,.05,.08,.2,.45]:
        a=contrast_bounds(flows,lambda t,s,a:phys.lp_from_joint(phys.local_joint(t,s,a,0.,tr),gamma))
        b=old.bounds(coeff,tr,gamma)
        errors.extend([abs(a['lower']-b[0]),abs(a['upper']-b[1])])
    assert max(errors)<1e-10
    return dict(random_cases=40,max_random_error=maximum,
                icu_radii=5,max_icu_error=max(errors))


def scaling():
    """Time occupancy propagation only; local LPs are common to both methods."""
    rng=np.random.default_rng(3002027)
    initial={0:.25,1:.25,2:.25,3:.25}
    kernel={(s,a):dict(enumerate(rng.dirichlet(np.ones(4)))) for s in range(4) for a in range(2)}
    transition=lambda t,s,a:kernel[s,a]
    p1=lambda t,s:int(s>=2 or t%3==1)
    p2=lambda t,s:int(s>=2)
    rows=[]
    for horizon in [3,5,7,9,15,30]:
        start=time.perf_counter()
        for _ in range(20):
            for stage_flow in iter_signed_flows(initial,transition,p1,p2,horizon):
                pass  # consume stages without retaining the history of flows
        elapsed=(time.perf_counter()-start)/20
        paths=2*4**horizon
        reference_time=error=np.nan
        if paths<=1000000:
            start=time.perf_counter();ref,counts=enumerated_flows(initial,transition,p1,p2,horizon)
            reference_time=time.perf_counter()-start
            flow=signed_flows(initial,transition,p1,p2,horizon)
            error=flow_error(flow,ref)
            assert error<1e-9 and counts[-1]==paths
        rows.append(dict(horizon=horizon,last_stage_policy_history_records=paths,
                         state_flow_capacity=12,flow_seconds=elapsed,
                         enumeration_seconds=reference_time,max_error=error,
                         enumeration_run=paths<=1000000))
    return pd.DataFrame(rows)


def single_policy_interval(initial, transition, policy, endpoints, horizon):
    """Separate sharp value bounds: all occupancy coefficients are nonnegative."""
    masses=dict(initial);lower=upper=0.
    for t in range(horizon):
        following=defaultdict(float)
        for state,mass in masses.items():
            action=policy(t,state);lo,hi=endpoints(t,state,action)
            lower+=mass*lo;upper+=mass*hi
            for nxt,prob in transition(t,state,action).items():
                following[nxt]+=mass*prob
        masses=dict(following)
    return lower,upper


def heterogeneous():
    init,tr=old.read_mdp(ROOT);start={(s,ag,1):v for (s,ag),v in init.items()}
    p1=lambda t,s:int(s[0]==1 or s[2]==0)
    p2=lambda t,s:int(s[0]==1)
    rows=[];summaries=[]
    for eta in [0.,1.1,2.]:
        @lru_cache(None)
        def joint(t,state,a):
            s,ag,op=state;out={}
            tau=s+eta*(1-op)-.3*ag
            for z,pz in tr[t,s,ag].items():
                py=expit(.15-1.05*z+tau*a)
                for y in [-1,1]:
                    pr=expit(-.55+1.35*y+.15*s+.15*a)
                    for r in [0,1]:out[y,z,r]=pz*(py if y==1 else 1-py)*(pr if r else 1-pr)
            return out
        def transition(t,state,a):
            j=joint(t,state,a)
            return {(z,state[1],r):sum(j[y,z,r] for y in [-1,1])
                    for z in [-1,1] for r in [0,1]}
        flows=signed_flows(start,transition,p1,p2,3)
        truth=contrast_bounds(flows,lambda t,s,a:(sum(y*p for (y,z,r),p in joint(t,s,a).items()),)*2)['lower']
        ref,_=enumerated_flows(start,transition,p1,p2,3)
        assert flow_error(flows,ref)<1e-12
        for gamma in np.linspace(0,.30,31):
            @lru_cache(None)
            def endpoints(t,s,a):
                return phys.lp_from_joint(joint(t,s,a),gamma)
            values=contrast_bounds(flows,endpoints)
            first=single_policy_interval(start,transition,p1,endpoints,3)
            second=single_policy_interval(start,transition,p2,endpoints,3)
            values.update(separate_lower=first[0]-second[1],
                          separate_upper=first[1]-second[0])
            assert values['separate_lower']<=values['lower']+1e-9
            assert values['separate_upper']>=values['upper']-1e-9
            assert values['lower']-1e-9<=truth<=values['upper']+1e-9
            if gamma==0:assert abs(values['lower']-truth)<1e-9
            rows.append(dict(eta=eta,Gamma=gamma,true_contrast=truth,**values))
        # Fixed reporting radius .08, common across all three designs.
        row=next(row for row in rows if row['eta']==eta and abs(row['Gamma']-.08)<1e-9)
        summaries.append(row.copy())
    return pd.DataFrame(rows),pd.DataFrame(summaries)


def figures(df):
    plt.rcParams.update({'font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(1,3,figsize=(7.0,2.25),sharex=True,sharey=True)
    for ax,(eta,g) in zip(axes,df.groupby('eta',sort=True)):
        ax.fill_between(g.Gamma,g.lower,g.upper,color='#246b8e',alpha=.20)
        ax.plot(g.Gamma,g.lower,color='#246b8e',lw=1.3,label='Sharp, full history')
        ax.plot(g.Gamma,g.upper,color='#246b8e',lw=1.3)
        ax.plot(g.Gamma,g.pooled_lower,color='#b16624',ls='--',lw=1,label='Pooled completions')
        ax.plot(g.Gamma,g.pooled_upper,color='#b16624',ls='--',lw=1)
        ax.axhline(float(g.true_contrast.iloc[0]),color='#333333',ls=':',lw=1,label='True contrast')
        ax.axhline(0,color='#888888',lw=.6);ax.set_title(rf'$\eta={eta:g}$')
        ax.set_xlabel(r'Radius $\Gamma$');ax.grid(alpha=.13)
    axes[0].set_ylabel('Policy value contrast')
    axes[1].legend(loc='upper center',bbox_to_anchor=(.5,-.31),ncol=3,frameon=False,fontsize=8)
    fig.subplots_adjust(bottom=.31,left=.09,right=.99,wspace=.09,top=.85)
    (ROOT/'figures').mkdir(parents=True, exist_ok=True)
    fig.savefig(ROOT/'figures/fig_heterogeneous_contrasts.pdf',bbox_inches='tight')
    fig.savefig(ROOT/'figures/fig_heterogeneous_contrasts.png',dpi=180,bbox_inches='tight');plt.close(fig)


def main():
    checks=validations();scale=scaling();raw,summary=heterogeneous();figures(raw)
    (ROOT/'results/signed_aggregation_audit.json').write_text(json.dumps(checks,indent=2)+'\n')
    scale.to_csv(ROOT/'results/signed_aggregation_scaling.csv',index=False)
    raw.to_csv(ROOT/'results/heterogeneous_contrasts.csv',index=False)
    summary.to_csv(ROOT/'results/heterogeneous_summary.csv',index=False)
    print(json.dumps(checks,indent=2));print(scale.to_string(index=False));print(summary.to_string(index=False))


if __name__=='__main__':main()
