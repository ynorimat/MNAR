"""Rebuild the appendix pooling-panel input from the retained 81-setting CSV."""
from pathlib import Path
import argparse,csv,hashlib,json,statistics

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--paper',type=Path,required=True)
    args=parser.parse_args()
    source=args.results/'dynamic_grid.csv'
    original=source.read_bytes()
    with source.open(encoding='utf-8',newline='') as f:data=list(csv.DictReader(f))
    assert len(data)==81
    rows=[]
    for split,category in enumerate(['initial','middle','last']):
        row={'split':split}
        for horizon in [3,6,12]:
            values=[float(r['pooling_gap']) for r in data
                    if int(r['horizon'])==horizon and r['split_category']==category]
            assert len(values)==9
            row.update({f'T{horizon}_mean':statistics.mean(values),
                        f'T{horizon}_min':min(values),f'T{horizon}_max':max(values)})
        rows.append(row)
    folder=args.paper/'figures';folder.mkdir(parents=True,exist_ok=True)
    output=folder/'dynamic_pooling.csv'
    with output.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    assert source.read_bytes()==original
    report={'source':'dynamic_grid.csv','source_sha256':hashlib.sha256(original).hexdigest(),
            'settings':81,'settings_per_point':9,'series':3,'positions_per_series':3,
            'quantity':'pooling_gap','summary':'mean and full min-max range',
            'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
            'source_unchanged':True}
    (args.paper/'display_appendix_audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':main()
