#!/usr/bin/env python3
"""Numerical diagnostics for local reconstruction and latent-history transport.
These finite examples supplement, and do not certify, the mathematical proofs.
Run from the source root: python code/audit_theory.py
"""
import itertools,json
from pathlib import Path
from collections import defaultdict
import numpy as np
from scipy.optimize import linprog
import experiment_factorized_trajectory_lp as seq
import experiment_policy_robustness as contrast

ROOT=Path(__file__).resolve().parents[1]

def local_checks(rng,n=100):
    worst=0.;nested=0.
    for j in range(n):
        x=rng.dirichlet(np.ones(6)).reshape(2,3)
        if j%4==0: # structural support zeros, while both reward margins stay positive
            x[0,2]=0.;x/=x.sum()
        response=rng.uniform(.05,.95,(2,3));s=x*response
        mu=x.sum(0);q=s/s.sum(1,keepdims=True)
        pos=q>0;g=np.max(np.abs(np.log((x/x.sum(1,keepdims=True))[pos]/q[pos])))
        def solve(gamma):
            Aeq=np.tile(np.eye(3),(1,2));A=[]
            for y,z in itertools.product(range(2),range(3)):
                u=np.zeros((2,3));u[y,z]=1
                upper=u.copy();upper[y,:]-=np.exp(gamma)*q[y,z]
                lower=-u.copy();lower[y,:]+=np.exp(-gamma)*q[y,z]
                A.extend([upper.ravel(),lower.ravel()])
            c=np.repeat([-1.,1.],3);opts=[]
            for sign in [1.,-1.]:
                r=linprog(sign*c,A_ub=A,b_ub=np.zeros(12),A_eq=Aeq,b_eq=mu,bounds=list(zip(s.ravel(),[None]*6)),method='highs')
                assert r.success,r.message
                xr=r.x.reshape(2,3)
                # Reconstruct both observed strata directly from the optimizer.
                residual=xr-s
                error=max(float(np.max(np.abs(xr.sum(0)-mu))),float(np.max(-residual)),float(np.max(np.asarray(A)@r.x)))
                assert error<1e-7
                opts.append((float(c@r.x),error))
            return opts
        a=solve(g+1e-8);b=solve(g+.2)
        true=float(np.array([-1.,1.])@x.sum(1))
        assert a[0][0]-1e-7<=true<=a[1][0]+1e-7
        assert b[0][0]<=a[0][0]+1e-7 and b[1][0]>=a[1][0]-1e-7
        worst=max(worst,a[0][1],a[1][1]);nested=max(nested,b[0][0]-a[0][0],a[1][0]-b[1][0])
    return {'cases':n,'max_reconstruction_constraint_residual':worst,'max_nestedness_violation':max(0.,nested)}

def latent_checks(rng,n=12):
    cells=list(itertools.product(seq.V,seq.V,seq.B));prefixes=list(itertools.product(seq.B,seq.V,seq.V,seq.B))
    max_transport=max_value=max_lp=0.
    for j in range(n):
        first={a:dict(zip(cells,rng.dirichlet(np.ones(8)*2))) for a in seq.B}
        # Deliberately depends on hidden y1 even when r1=0.
        later={(pref,a):dict(zip(cells,rng.dirichlet(np.ones(8)*2))) for pref in prefixes for a in seq.B}
        P={};D={}
        for pref in prefixes:
            a0,y1,z1,r1=pref;h=seq.h1(*pref)
            for a1 in seq.B:
                for tup,g in later[(pref,a1)].items():
                    atom=pref+(a1,)+tup
                    P[atom]=seq.pi0(a0)*first[a0][(y1,z1,r1)]*seq.pi1(a1,h)*g
                    D[atom]=float(a0==seq.d0())*first[a0][(y1,z1,r1)]*float(a1==seq.d1(h))*g
        assert abs(sum(P.values())-1)<1e-12 and abs(sum(D.values())-1)<1e-12
        def aggregate(dist,key):
            out=defaultdict(float)
            for a,p in dist.items():out[key(a)]+=p
            return out
        fp=aggregate(P,lambda a:a[:4]);dp=aggregate(D,lambda a:a[:4]);fh=aggregate(P,lambda a:seq.h1(*a[:4]));dh=aggregate(D,lambda a:seq.h1(*a[:4]))
        for pref in prefixes:
            h=seq.h1(*pref)
            if dh[h]>0:max_transport=max(max_transport,abs(dp[pref]/dh[h]-fp[pref]/fh[h]))
        factual=defaultdict(float);den=defaultdict(float);target=defaultdict(float)
        for a,p in P.items():
            h=seq.h1(*a[:4]);factual[(h,a[4],a[5:])]+=p;den[(h,a[4])]+=p
        for a,p in D.items():target[(seq.h1(*a[:4]),a[5:])]+=p
        for h,p in dh.items():
            if p>0:
                for tup in cells:max_transport=max(max_transport,abs(target[(h,tup)]/p-factual[(h,seq.d1(h),tup)]/den[(h,seq.d1(h))]))
        direct=sum(p*(a[1]+a[5]) for a,p in D.items());max_value=max(max_value,abs(direct-seq.truth(P)))
        if j<4:
            # All eight outcomes have strictly positive Dirichlet mass; a generous radius is feasible.
            G=12.;b=seq.bellman(P,G);g=seq.global_lp(P,G)
            max_lp=max(max_lp,*[abs(u-v) for u,v in zip(b,g)])
            assert b[0]-1e-7<=direct<=b[1]+1e-7
    assert max_transport<1e-10 and max_value<1e-10 and max_lp<1e-7
    return {'latent_dependent_laws':n,'global_lp_cases':4,'max_transport_error':max_transport,'max_direct_vs_ipw_value_error':max_value,'max_global_vs_bellman_error':max_lp}

def contrast_checks():
    init,tr=contrast.read_mdp(ROOT);c=contrast.contrast_coefficients(init,tr);G=.08
    lo,hi=contrast.bounds(c,tr,G);pl,pu=contrast.bounds(c,tr,G,True);gap=0.
    for t,ct in enumerate(c):
        grouped=defaultdict(list)
        for (h,a),v in ct.items():grouped[(contrast.compressed(h),a)].append(v)
        for (state,a),vs in grouped.items():
            l,u=contrast.phys.lp_from_joint(contrast.phys.local_joint(t,state,a,0.,tr),G)
            gap+=(u-l)*.5*(sum(abs(v) for v in vs)-abs(sum(vs)))
    err=max(abs(pl-lo-gap),abs(hi-pu-gap));assert err<1e-10
    identical=[{key:0. for key in ct} for ct in c];assert contrast.bounds(identical,tr,G)==(0.,0.)
    assert lo<0<pl
    return {'Gamma':G,'full_lower':lo,'pooled_lower':pl,'pooling_gap':gap,'gap_identity_error':err,'identical_policy_interval':[0.,0.]}

def main():
    rng=np.random.default_rng(20270916)
    results={'local':local_checks(rng),'latent_dependence':latent_checks(rng),'contrast':contrast_checks()}
    (ROOT/'results/audit_theory.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
