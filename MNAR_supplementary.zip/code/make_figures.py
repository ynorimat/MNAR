#!/usr/bin/env python3
"""Regenerate the exact-enumeration figure from its numerical table."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1]
df=pd.read_csv(root/'results/experiment_sequential_sharpness.csv')
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(3.25,2.25))
ax.plot(df.Gamma,df.global_width,'o-',label='Treatment-constrained trajectory LP',color='#23628e')
ax.plot(df.Gamma,df.bellman_width,'x--',label='Clock-Bellman',color='#c16f2d')
ax.set(xlabel=r'Radius $\Gamma=2|\kappa|$',ylabel='Identified interval width')
ax.grid(alpha=.2);ax.legend(fontsize=6.5);fig.tight_layout()
(root/'figures').mkdir(parents=True, exist_ok=True)
fig.savefig(root/'figures/fig_rectangularity_sharpness.pdf')
fig.savefig(root/'figures/fig_rectangularity_sharpness.png',dpi=180)
plt.close(fig)
