#!/usr/bin/env python3
"""Export a single observationally compatible ICU law with negative policy contrast."""
import itertools
import json
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
import experiment_policy_robustness as old
import run_physionet_semisynthetic as phys

ROOT=Path(__file__).resolve().parents[1]
CELLS=list(itertools.product([-1,1],repeat=2))


def completion(joint,gamma,direction):
    s=np.array([joint[y,z,1] for y,z in CELLS]).reshape(2,2)
    mu=np.array([sum(joint[y,z,r] for y in [-1,1] for r in [0,1]) for z in [-1,1]])
    q=s/s.sum(axis=1,keepdims=True)
    eq=np.tile(np.eye(2),(1,2));rows=[]
    for iy,iz in itertools.product(range(2),repeat=2):
        cell=np.zeros((2,2));cell[iy,iz]=1
        upper=cell.copy();upper[iy,:]-=np.exp(gamma)*q[iy,iz]
        lower=-cell.copy();lower[iy,:]+=np.exp(-gamma)*q[iy,iz]
        rows.extend([upper.ravel(),lower.ravel()])
    mean=np.array([-1.,-1.,1.,1.])
    fit=linprog(direction*mean,A_ub=rows,b_ub=np.zeros(8),A_eq=eq,b_eq=mu,
                bounds=list(zip(s.ravel(),[None]*4)),method='highs')
    assert fit.success
    x=fit.x.reshape(2,2)
    result={}
    for iy,y in enumerate([-1,1]):
        for iz,z in enumerate([-1,1]):
            result[y,z,1]=s[iy,iz]
            result[y,z,0]=max(0.,x[iy,iz]-s[iy,iz])
    return result


def main():
    initial,trans=old.read_mdp(ROOT);coeff=old.contrast_coefficients(initial,trans)
    @lru_cache(None)
    def local(t,state,a,direction):
        original=phys.local_joint(t,state,a,0.,trans)
        return original if direction==0 else completion(original,.08,direction)
    kernels={};records=[];factual=dict(initial);factual_original=dict(initial);max_obs=max_clock=0.
    for t in range(phys.T):
        next_factual=defaultdict(float);next_original=defaultdict(float)
        for h,p in factual.items():
            state=old.compressed(h)
            for a in [0,1]:
                c=coeff[t].get((h,a),0.)
                direction=1 if c>1e-14 else -1 if c< -1e-14 else 0
                j=local(t,state,a,direction);kernels[t,h,a]=j
                original=phys.local_joint(t,state,a,0.,trans)
                observed=defaultdict(float);observed_orig=defaultdict(float)
                for (y,z,r),mass in j.items():
                    observed[z,r,r*y]+=mass
                    records.append(dict(stage=t,history=json.dumps(h,separators=(',',':')),
                                        action=a,coefficient=c,y=y,z=z,r=r,probability=mass))
                for (y,z,r),mass in original.items():observed_orig[z,r,r*y]+=mass
                assert abs(sum(j.values())-1)<1e-10 and min(j.values())>=0
                max_obs=max(max_obs,max(abs(observed[o]-observed_orig[o]) for o in observed))
                for y,z in CELLS:
                    full=sum(j[y,z,r] for r in [0,1])/sum(v for (yy,zz,r),v in j.items() if yy==y)
                    complete=original[y,z,1]/sum(original[y,zz,1] for zz in [-1,1])
                    max_clock=max(max_clock,abs(np.log(full/complete)))
                behavior=phys.behavior_p(state) if a else 1-phys.behavior_p(state)
                for o,mass in observed.items():next_factual[h+(a,)+o]+=behavior*p*mass
                for o,mass in observed_orig.items():next_original[h+(a,)+o]+=behavior*factual_original[h]*mass
        factual=dict(next_factual);factual_original=dict(next_original)
    values={}
    for policy in ['missingness','state']:
        masses=dict(initial);value=0.
        for t in range(phys.T):
            nxt=defaultdict(float)
            for h,p in masses.items():
                a=old.action(h,policy);j=kernels[t,h,a]
                value+=p*sum(y*v for (y,z,r),v in j.items())
                for (y,z,r),v in j.items():nxt[h+(a,z,r,r*y)]+=p*v
            masses=dict(nxt)
        values[policy]=value
    delta=values['missingness']-values['state']
    lower=old.bounds(coeff,trans,.08)[0]
    assert abs(delta-lower)<1e-10 and delta<0
    assert max_obs<1e-10 and max_clock<.08+1e-9
    pd.DataFrame(records).to_csv(ROOT/'results/adverse_completion_kernels.csv',index=False)
    trajectory_error=max(abs(factual[h]-factual_original[h]) for h in factual)
    assert trajectory_error<1e-10
    report=dict(Gamma=.08,policy_values=values,contrast=delta,sharp_lower=lower,
                max_observed_kernel_error=max_obs,max_clock_violation=max_clock,
                max_observed_trajectory_error=trajectory_error,observed_trajectories=len(factual),
                local_history_action_kernels=len(kernels),rows=len(records),
                construction='initial aggregate law times the benchmark behavior kernel times exported local kernels; no latent-past restriction on the model is inferred')
    (ROOT/'results/adverse_completion_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
