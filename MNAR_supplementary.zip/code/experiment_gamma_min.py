#!/usr/bin/env python3
"""Finite-sample minimum-compatible Gamma diagnostic (Appendix)."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.special import expit

YVAL=(-1,1); ZVAL=(0,1,2)

def gamma_min(Y,Z,R,max_gamma=3.0):
    mu={z:np.mean(Z==z) for z in ZVAL}
    syz={(y,z):np.mean((R==1)&(Y==y)&(Z==z)) for y in YVAL for z in ZVAL}
    q={}
    for y in YVAL:
        d=sum(syz[(y,z)] for z in ZVAL)
        if d<=0:return np.nan
        for z in ZVAL:q[(y,z)]=syz[(y,z)]/d
    idx={(y,z):i for i,(y,z) in enumerate(( (y,z) for y in YVAL for z in ZVAL))}
    def feasible(G):
        l,u=np.exp(-G),np.exp(G);Aeq=[];beq=[];Aub=[];bub=[]
        for z in ZVAL:
            row=np.zeros(6)
            for y in YVAL:row[idx[(y,z)]]=1
            Aeq.append(row);beq.append(mu[z])
        for y in YVAL:
            yi=[idx[(y,z)] for z in ZVAL]
            for z in ZVAL:
                j=idx[(y,z)]
                row=np.zeros(6);row[j]=-1;Aub.append(row);bub.append(-syz[(y,z)])
                row=np.zeros(6);row[j]=1
                for jj in yi:row[jj]-=u*q[(y,z)]
                Aub.append(row);bub.append(0.)
                row=np.zeros(6);row[j]=-1
                for jj in yi:row[jj]+=l*q[(y,z)]
                Aub.append(row);bub.append(0.)
        return linprog(np.zeros(6),A_ub=np.array(Aub),b_ub=np.array(bub),
                       A_eq=np.array(Aeq),b_eq=np.array(beq),bounds=[(0,None)]*6,
                       method='highs').success
    if feasible(0):return 0.
    lo,hi=0.,max_gamma
    if not feasible(hi):return np.nan
    for _ in range(30):
        m=(lo+hi)/2
        if feasible(m):hi=m
        else:lo=m
    return hi

def one(n,seed):
    rng=np.random.default_rng(seed)
    Y=2*rng.binomial(1,.55,n)-1
    pz={-1:[.6,.3,.1],1:[.1,.3,.6]}
    Z=np.array([rng.choice(ZVAL,p=pz[int(y)]) for y in Y])
    R=rng.binomial(1,expit(-.3+1.0*Y))
    return gamma_min(Y,Z,R)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path('gamma_min_results'));ap.add_argument('--reps',type=int,default=200);args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    raw=[]
    for n in [500,2000,10000]:
        for r in range(args.reps):raw.append({'n':n,'rep':r,'Gamma_min':one(n,900000+n+r)})
    raw=pd.DataFrame(raw)
    summ=raw.groupby('n',as_index=False).agg(mean=('Gamma_min','mean'),median=('Gamma_min','median'),p90=('Gamma_min',lambda x:np.quantile(x,.9)),p95=('Gamma_min',lambda x:np.quantile(x,.95)))
    raw.to_csv(args.out/'gamma_min_raw.csv',index=False);summ.to_csv(args.out/'gamma_min_summary.csv',index=False)
    print(summ.to_string(index=False))
if __name__=='__main__':main()
