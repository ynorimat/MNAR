"""Exact finite-atom check for Appendix D's state-misspecification example.

Uses only the Python standard library. No simulation or fitted model is used.
Run from supplementary/: python code/check_state_sufficiency.py
Regenerates results/state_sufficiency_check.csv. Arithmetic uses fractions.
"""
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import csv


def joint_law(delta):
    atoms = {}
    for a0, a1, y, r in product((0, 1), (0, 1), (-1, 1), (0, 1)):
        positive = F(1, 2) + delta * (2 * a0 - 1)
        py = positive if y == 1 else 1 - positive
        response = F(3, 4) if y == 1 else F(1, 4)
        pr = response if r else 1 - response
        atoms[a0, a1, y, y, r] = F(1, 4) * py * pr
    assert sum(atoms.values()) == 1
    assert all(p > 0 for p in atoms.values())
    return atoms


def conditional(atoms, indices, fixed):
    selected = [(key, p) for key, p in atoms.items()
                if all(key[i] == v for i, v in fixed.items())]
    mass = sum(p for _, p in selected)
    result = defaultdict(F)
    for key, p in selected:
        result[tuple(key[i] for i in indices)] += p / mass
    return dict(result)


def observed_row(atoms, fixed):
    raw = conditional(atoms, (2, 3, 4), fixed)
    result = defaultdict(F)
    for (y, z, r), p in raw.items():
        result[z, r, r * y] += p
    return dict(result)


def tv(p, q):
    return sum(abs(p.get(k, 0) - q.get(k, 0)) for k in p.keys() | q.keys()) / 2


def check(delta):
    atoms = joint_law(delta)
    values = []
    for a0 in (0, 1):
        # Independent randomization makes conditioning equal to intervention.
        law = conditional(atoms, (2,), {0: a0, 1: 0})
        values.append(sum(y[0] * p for y, p in law.items()))
        for y in (-1, 1):
            full = conditional(atoms, (3,), {0: a0, 1: 0, 2: y})
            complete = conditional(atoms, (3,), {0: a0, 1: 0, 2: y, 4: 1})
            assert full == complete == {(y,): F(1)}
        for a1 in (0, 1):
            # Check the treatment positivity/stability used by the example.
            assert sum(p for key, p in atoms.items() if key[0] == a0 and key[1] == a1) == F(1, 4)
    pooled = conditional(atoms, (2,), {1: 0})
    pooled_mean = sum(y[0] * p for y, p in pooled.items())
    # At Gamma=0, Q is identity and the proxy marginal fixes both means.
    assert conditional(atoms, (3,), {1: 0}) == pooled
    assert pooled_mean == 0
    contrast = values[1] - values[0]
    deviation = max(tv(observed_row(atoms, {0: a0, 1: 0}),
                       observed_row(atoms, {1: 0})) for a0 in (0, 1))
    assert values == [-2 * delta, 2 * delta]
    assert contrast == 4 * delta
    assert deviation == delta
    return dict(delta=str(delta), observed_tv=str(deviation),
                full_contrast=str(contrast), pooled_contrast='0',
                endpoint_error=str(abs(contrast)),
                full_contrast_decimal=float(contrast), atoms=len(atoms))


if __name__ == '__main__':
    rows = [check(F(x)) for x in ('0', '0.001', '0.005', '0.01', '0.025', '0.05', '0.1')]
    target = Path(__file__).resolve().parents[1] / 'results/state_sufficiency_check.csv'
    with target.open('w', newline='', encoding='utf8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f'Exact checks passed for {len(rows)} settings; wrote {target.name}.')
