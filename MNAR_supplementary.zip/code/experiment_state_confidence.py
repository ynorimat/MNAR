"""Fixed paired finite-state inference study. See FINITE_STATE_PROTOCOL.md."""
import argparse,json,time,platform
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import beta
from state_confidence import confidence_inputs,bound_pair,simulate_counts
from experiment_dynamic_grid import dgp,STATES,INITIAL
from sign_preserving import signed_flows,contrast_bounds

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--followup',action='store_true')
    args=parser.parse_args()
    started=time.perf_counter(); rows=[]
    base=202609171900000 if args.followup else 202609170800000
    sizes=[128000,256000] if args.followup else [4000,16000,64000]
    tag='state_confidence_followup' if args.followup else 'state_confidence'
    datasets=3*len(sizes)*100
    seeds={base+100000*j+1000*k+r for j in range(3) for k in range(len(sizes)) for r in range(100)}
    old_seeds=set()
    for file in (ROOT/'results').glob('*.csv'):
        if file.name in {tag+'_raw.csv',tag+'_paired.csv',tag+'_summary.csv'}:continue
        columns=pd.read_csv(file,nrows=0).columns
        if 'seed' in columns:
            old_seeds.update(pd.read_csv(file,usecols=['seed']).seed.dropna().astype(np.int64))
    assert len(seeds)==datasets and seeds.isdisjoint(old_seeds)
    joint,tr,endpoints=dgp(.8,.8)
    for j,T in enumerate([3,6,12]):
        policies=[]
        for category,split in [('initial',0),('middle',T//2),('last',T-1)]:
            p0=np.zeros((T,4),int);p1=np.repeat((np.arange(T)>=split)[:,None],4,axis=1).astype(int)
            pop=contrast_bounds(signed_flows(INITIAL,tr,lambda t,s:int(t>=split),lambda t,s:0,T),endpoints,weights=[1/T]*T)
            policies.append((category,p1,p0,pop))
        for k,n in enumerate(sizes):
            for rep in range(100):
                seed=base+100000*j+1000*k+rep
                initial,counts=simulate_counts(n,T,STATES,INITIAL,joint,np.random.default_rng(seed))
                start=time.perf_counter(); inputs=confidence_inputs(initial,counts,STATES)
                ci_seconds=time.perf_counter()-start
                for category,p1,p0,pop in policies:
                    start=time.perf_counter(); bound=bound_pair(inputs,p1,p0)
                    dp_seconds=time.perf_counter()-start
                    for method,prefix in [('three_status',''),('separate','separate_')]:
                        lo,hi=bound[prefix+'lower'],bound[prefix+'upper']
                        covered=lo<=pop['lower']+1e-9 and hi>=pop['upper']-1e-9
                        correct=(lo>0 and pop['lower']>0) or (hi<0 and pop['upper']<0)
                        wrong=(lo>0 and pop['lower']<=0) or (hi<0 and pop['upper']>=0)
                        rows.append(dict(horizon=T,n=n,split_category=category,replication=rep,seed=seed,method=method,
                            lower=lo,upper=hi,width=hi-lo,population_lower=pop['lower'],population_upper=pop['upper'],
                            covered=covered,correct=correct,wrong=wrong,abstain=not(lo>0 or hi<0),
                            scalar_intervals=inputs['scalar_intervals'],empty_cells=inputs['empty_cells'],
                            lp_fallbacks=inputs['lp_fallbacks'],confidence_seconds=ci_seconds,dp_seconds=dp_seconds))
            print('Completed',T,n,flush=True)
            pd.DataFrame(rows).to_csv(ROOT/('results/'+tag+'_raw.csv'),index=False)
    raw=pd.DataFrame(rows); summaries=[]
    for key,g in raw.groupby(['horizon','n','split_category','method'],sort=False):
        out=dict(zip(['horizon','n','split_category','method'],key));out['reps']=len(g)
        for metric in ['covered','correct','wrong','abstain']:
            x=int(g[metric].sum()); N=len(g);out[metric]=x/N
            out[metric+'_mc_lower']=0. if x==0 else float(beta.ppf(.025,x,N-x+1))
            out[metric+'_mc_upper']=1. if x==N else float(beta.ppf(.975,x+1,N-x))
        for metric in ['width','confidence_seconds','dp_seconds','lp_fallbacks','empty_cells']:
            out['mean_'+metric]=float(g[metric].mean())
        out['population_lower']=float(g.population_lower.iloc[0]);out['population_upper']=float(g.population_upper.iloc[0])
        summaries.append(out)
    pd.DataFrame(summaries).to_csv(ROOT/('results/'+tag+'_summary.csv'),index=False)
    paired=raw.pivot(index=['horizon','n','split_category','replication','seed'],columns='method',values='width').reset_index()
    paired['width_reduction']=paired.separate-paired.three_status
    assert paired.width_reduction.min()>-1e-9
    paired.to_csv(ROOT/('results/'+tag+'_paired.csv'),index=False)
    meta=dict(independent_datasets=datasets,paired_policy_comparisons=3*datasets,method_records=6*datasets,
              alpha=.05,reps_per_cell=100,seed_base=base,seed_disjoint=True,
              seconds=time.perf_counter()-started,python=platform.python_version(),numpy=np.__version__,
              timing_note='Confidence construction is shared; DP time includes both interval methods.',
              simulation='Exact Markov multinomial counts; no clinical data or hidden rewards supplied to estimators.')
    (ROOT/('results/'+tag+'_manifest.json')).write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2))
    print(pd.DataFrame(summaries).query("method=='three_status'")[["horizon","n","split_category","covered","correct","mean_width"]].to_string(index=False))

if __name__=='__main__':main()
