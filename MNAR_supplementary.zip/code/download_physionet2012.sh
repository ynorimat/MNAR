#!/usr/bin/env bash
set -euo pipefail
OUT=${1:-data/physionet2012}
mkdir -p "$OUT"
URL="https://physionet.org/files/challenge-2012/1.0.0/set-a.tar.gz"
if command -v wget >/dev/null 2>&1; then
  wget -O "$OUT/set-a.tar.gz" "$URL"
elif command -v curl >/dev/null 2>&1; then
  curl -L "$URL" -o "$OUT/set-a.tar.gz"
else
  echo "Need wget or curl." >&2
  exit 1
fi
tar -xzf "$OUT/set-a.tar.gz" -C "$OUT"
echo "Extracted PhysioNet Challenge 2012 Set A under $OUT"
