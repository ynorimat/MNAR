"""Finite-state outer confidence bounds; latent completions stay history-specific.

Observed state sufficiency is an assumption, not learned or tested here.
Box-simplex transition optimization is classical rectangular robust DP.
"""
import numpy as np
from scipy.optimize import linprog
from experiment_endpoint_inference import cp_intervals
from experiment_local_confidence import OBS, ATOMS, COARSE, MEAN


def box_extreme(value, lower, upper, maximize=False, *, order=None):
    """Optimize on a box-simplex; optionally reuse a sorted coordinate order.

    Internal callers may supply a permutation sorting value ascending for a
    minimum or descending for a maximum. Reusing it across rows costs O(m)
    per row. With no order supplied, this standalone routine costs O(m log m).
    """
    v, lo, hi = map(lambda x: np.asarray(x, float), (value, lower, upper))
    if np.any(lo > hi + 1e-12) or lo.sum() > 1+1e-10 or hi.sum() < 1-1e-10:
        raise ValueError('Empty transition confidence set')
    p = lo.copy(); left = max(0., 1-p.sum())
    if order is None:
        order = np.argsort(-v if maximize else v, kind='stable')
    for j in order:
        extra = min(left, max(0., hi[j]-p[j])); p[j] += extra; left -= extra
    if left > 1e-9:
        raise ValueError('Unfilled simplex')
    return float(p @ v)


def local_bounds(plo, phi, qlo, qhi, gamma):
    rows = [*COARSE, *(-COARSE)]; rhs = [*phi, *(-plo)]
    for j, y in enumerate([-1, 1]):
        ymass = np.array([float(a[0] == y) for a in ATOMS])
        for z, lo, hi in [(1, qlo[j], qhi[j]), (-1, 1-qhi[j], 1-qlo[j])]:
            cell = np.array([float(a[:2] == (y, z)) for a in ATOMS])
            rows.extend([np.exp(-gamma)*lo*ymass-cell, cell-np.exp(gamma)*hi*ymass])
            rhs.extend([0., 0.])
    vals = []
    for sign in [1, -1]:
        result = linprog(sign*MEAN, A_ub=np.asarray(rows), b_ub=rhs,
                         A_eq=np.ones((1, 8)), b_eq=[1.], bounds=(0, None), method='highs')
        if not result.success:
            return -1., 1., 1
        vals.append(float(sign*result.fun))
    return vals[0], vals[1], 0


def confidence_inputs(initial_counts, counts, states, gamma=.1, alpha=.05, *, local_solver=local_bounds):
    """Counts are stage x state x action x observed-atom, from iid trajectories.

    The implementation's next state is (Z,R), as in the original four-state DGP.
    No treatment propensity is an input. All intervals use one joint budget.
    """
    T, m, A, _ = counts.shape
    J = m + T*m*A*8 + (T-1)*m*A*m
    scalar_error = alpha/J
    initial = cp_intervals(np.asarray(initial_counts), np.full(m, sum(initial_counts)), scalar_error)
    lower, upper = np.zeros((T,m,A)), np.zeros((T,m,A))
    trlo, trhi = np.zeros((T-1,m,A,m)), np.ones((T-1,m,A,m))
    obs_matrix = np.array([[int(o[:2] == s) for o in OBS] for s in states])
    fallbacks = empty = 0
    for t in range(T):
        for s in range(m):
            for a in range(A):
                c = counts[t,s,a]; n = int(c.sum())
                if n == 0:
                    lower[t,s,a], upper[t,s,a] = -1., 1.; empty += 1
                else:
                    plo, phi = cp_intervals(c, np.full(6,n), scalar_error)
                    qx = np.array([sum(cc for o,cc in zip(OBS,c) if o == (1,1,y)) for y in [-1,1]])
                    qn = np.array([sum(cc for o,cc in zip(OBS,c) if o[1:] == (1,y)) for y in [-1,1]])
                    qlo, qhi = cp_intervals(qx, qn, scalar_error)
                    lower[t,s,a], upper[t,s,a], status = local_solver(plo, phi, qlo, qhi, gamma)
                    fallbacks += status
                if t < T-1:
                    trlo[t,s,a], trhi[t,s,a] = cp_intervals(obs_matrix @ c, np.full(m,n), scalar_error)
    return dict(initial=initial, transition=(trlo,trhi), reward=(lower,upper),
                scalar_intervals=J, lp_fallbacks=fallbacks, empty_cells=empty)


def bound_pair(inputs, first, second, weights=None):
    """Return coupled and separate outer intervals for two state policies.

    A pair is represented by T x m integer action arrays. Inputs can be reused
    for data-selected pairs: the stated joint event covers every such pair.
    """
    lo, hi = inputs['reward']; tl,tu = inputs['transition']; il,iu = inputs['initial']
    T,m,A = lo.shape
    w = np.ones(T)/T if weights is None else np.asarray(weights)
    if np.any(w < 0): raise ValueError('Nonnegative weights are required')
    output = []
    for maximize in [False, True]:
        plus, minus, common = np.zeros(m), np.zeros(m), np.zeros(m)
        for t in reversed(range(T)):
            pn,mn,cn = np.zeros(m),np.zeros(m),np.zeros(m)
            # Continuation values are shared by every state/action row.
            # Sort each of the three vectors once, rather than once per row.
            sort_sign = -1 if maximize else 1
            orders = [np.argsort(sort_sign*v, kind='stable')
                      for v in (plus, minus, common)] if t < T-1 else [None]*3
            for s in range(m):
                a,b = int(first[t,s]),int(second[t,s])
                def cont(v, action, order):
                    return 0. if t == T-1 else box_extreme(
                        v,tl[t,s,action],tu[t,s,action],maximize,order=order)
                pn[s] = w[t]*(hi if maximize else lo)[t,s,a] + cont(plus,a,orders[0])
                mn[s] = -w[t]*(lo if maximize else hi)[t,s,b] + cont(minus,b,orders[1])
                cn[s] = cont(common,a,orders[2]) if a == b else pn[s]+mn[s]
            plus,minus,common = pn,mn,cn
        coupled = box_extreme(common,il,iu,maximize)
        separate = box_extreme(plus,il,iu,maximize)+box_extreme(minus,il,iu,maximize)
        output.append((coupled,separate))
    result = dict(lower=output[0][0], upper=output[1][0],
                  separate_lower=output[0][1], separate_upper=output[1][1])
    assert result['lower'] >= result['separate_lower']-1e-9
    assert result['upper'] <= result['separate_upper']+1e-9
    assert result['lower'] <= result['upper']+1e-9
    return result


def simulate_counts(n, horizon, states, initial, joint, rng, behavior_probability=.5):
    """Exact aggregated iid Markov trajectory simulation, not independent rows."""
    if not 0 < behavior_probability < 1:
        raise ValueError('The simulation requires positive probability of both actions')
    m=len(states); idx={s:i for i,s in enumerate(states)}
    initial_counts=rng.multinomial(n,[initial.get(s,0.) for s in states])
    current=initial_counts.copy(); counts=np.zeros((horizon,m,2,6),dtype=np.int64)
    probabilities={}
    for s in states:
        for a in [0,1]:
            j=joint(s,a)
            probabilities[s,a]=np.array([sum(p for (y,z,r),p in j.items() if (z,r,r*y)==o) for o in OBS])
    for t in range(horizon):
        following=np.zeros(m,dtype=np.int64)
        for si,s in enumerate(states):
            action_counts=rng.multinomial(int(current[si]),[1-behavior_probability,behavior_probability])
            for a in [0,1]:
                c=rng.multinomial(int(action_counts[a]), probabilities[s,a]); counts[t,si,a]=c
                for o,num in zip(OBS,c): following[idx[o[:2]]]+=num
        current=following
    return initial_counts,counts
