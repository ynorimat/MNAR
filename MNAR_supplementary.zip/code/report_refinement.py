"""Check retained refinement results and write the numerical audit summary."""
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    summary = pd.read_csv(ROOT/'results/refinement_summary.csv')
    raw = pd.read_csv(ROOT/'results/refinement_raw.csv')
    timings = pd.read_csv(ROOT/'results/refinement_serial_timings.csv')
    assert raw.seed.nunique() == 600 and len(raw) == 2400

    def row(q, n, pair, method, propagation='three_status'):
        found = summary[(summary.q == q) & (summary.n == n) & (summary.pair == pair) &
                        (summary.local_method == method) & (summary.propagation == propagation)]
        assert len(found) == 1
        return found.iloc[0]

    timing = timings.groupby('method').total_seconds.median()
    b64, p64 = row(.8, 64000, 'middle', 'base'), row(.8, 64000, 'middle', 'partition')
    base = raw[raw.method == 'base'].set_index(['q', 'n', 'pair', 'repetition'])
    part = raw[raw.method == 'partition'].set_index(['q', 'n', 'pair', 'repetition'])
    assert (part.lower >= base.lower-1e-8).all() and (part.upper <= base.upper+1e-8).all()
    failures = int(raw.lp_fallbacks.sum())
    covered = int(sum((((raw[p+'lower'] <= raw.population_lower+1e-9) &
                        (raw[p+'upper'] >= raw.population_upper-1e-9)).sum())
                      for p in ['', 'separate_']))
    false = int(sum(((((raw[p+'lower'] > 0) | (raw[p+'upper'] < 0)) &
                     ~(((raw[p+'lower'] > 0) & (raw.population_lower > 0)) |
                       ((raw[p+'upper'] < 0) & (raw.population_upper < 0)))).sum())
                    for p in ['', 'separate_']))
    assert covered == 4800 and false == 0 and failures == 0
    audit = dict(intervals=4800, covered=covered, false_certificates=false, lp_fallbacks=failures,
                 switch_q08_n64000_certification_base=float(b64.certification),
                 switch_q08_n64000_certification_partition=float(p64.certification),
                 serial_median_seconds=timing.to_dict())
    (ROOT/'results/refinement_report_audit.json').write_text(json.dumps(audit, indent=2)+'\n')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
