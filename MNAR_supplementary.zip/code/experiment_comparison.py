"""Targeted exploratory diagnostics; see COMPARISON_PROTOCOL.md before running."""
import argparse
import itertools
import json
import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog
from scipy.stats import binomtest

from experiment_dynamic_grid import STATES, INITIAL, dgp
from experiment_endpoint_inference import cp_intervals
from experiment_local_confidence import OBS
from sign_preserving import signed_flows, contrast_bounds
from state_confidence import bound_pair, confidence_inputs, simulate_counts

ROOT = Path(__file__).resolve().parents[1]


def shared_row_inputs(b, low, high):
    # State 0 is the uncertain-row origin, 1 the terminal success, 2 the start/bypass.
    initial = np.array([0., 0., 1.])
    transition = np.zeros((2, 3, 2, 3))
    transition[..., 2] = 1.
    transition[0, 2, 0] = [1., 0., 0.]
    transition[0, 2, 1] = [b, 0., 1-b]
    tl, tu = transition.copy(), transition.copy()
    tl[1, 0, 0], tu[1, 0, 0] = [1-high, low, 0.], [1-low, high, 0.]
    reward = np.zeros((3, 3, 2)); reward[2, 1, :] = 1.
    first = np.zeros((3, 3), int)
    second = first.copy(); second[0, :] = 1
    inputs = dict(initial=(initial, initial), transition=(tl, tu), reward=(reward, reward))
    return inputs, first, second


def row_experiment():
    rows = []
    for design, (b, N) in enumerate(itertools.product([0., .25, .75, 1.], [200, 2000])):
        for rep in range(100):
            seed = 202609246000000 + 10000*design + rep
            x = int(np.random.default_rng(seed).binomial(N, .4))
            l, u = (float(v[0]) for v in cp_intervals(np.array([x]), np.array([N]), .05))
            inputs, first, second = shared_row_inputs(b, l, u)
            result = bound_pair(inputs, first, second, [0., 0., 1.])
            jl = linprog([1-b], bounds=[(l, u)], method='highs')
            ju = linprog([b-1], bounds=[(l, u)], method='highs')
            assert jl.success and ju.success
            exact_lower, exact_upper = float(jl.fun), float(-ju.fun)
            formula_error = max(abs(result['lower']-(l-b*u)), abs(result['upper']-(u-b*l)))
            lp_error = max(abs(exact_lower-(1-b)*l), abs(exact_upper-(1-b)*u))
            assert max(formula_error, lp_error) < 1e-10
            truth = (1-b)*.4
            rows.append(dict(seed=seed, repetition=rep, b=b, row_visits=N, successes=x,
                row_lower=l, row_upper=u, true_contrast=truth,
                joint_lower=exact_lower, joint_upper=exact_upper,
                outer_lower=result['lower'], outer_upper=result['upper'],
                joint_width=exact_upper-exact_lower, outer_width=result['upper']-result['lower'],
                joint_covered=exact_lower-1e-10<=truth<=exact_upper+1e-10,
                outer_covered=result['lower']-1e-10<=truth<=result['upper']+1e-10,
                joint_certified=exact_lower>1e-12, outer_certified=result['lower']>1e-12,
                formula_error=formula_error, lp_error=lp_error))
    return pd.DataFrame(rows)


def plugin_values(inputs, initial_counts, counts, candidates):
    T, m, _, _ = counts.shape
    rewards = sum(inputs['reward'])/2
    initial = initial_counts/initial_counts.sum()
    transition = np.zeros((T-1, m, 2, m))
    for t, si, a in itertools.product(range(T-1), range(m), range(2)):
        c = counts[t, si, a]
        if c.sum() == 0: transition[t, si, a] = 1/m
        else:
            for oi, o in enumerate(OBS): transition[t, si, a, STATES.index(o[:2])] += c[oi]/c.sum()
    values = []
    for policy in candidates:
        value = np.zeros(m)
        for t in reversed(range(T)):
            value = np.array([rewards[t,s,policy[t,s]]/T +
                (transition[t,s,policy[t,s]] @ value if t<T-1 else 0.) for s in range(m)])
        values.append(initial @ value)
    return np.asarray(values)


def selection_experiment(null_effect=False):
    T, m = 3, len(STATES)
    candidates = [np.tile(np.array(mask), (T, 1)) for mask in itertools.product([0,1], repeat=m)]
    joint, transition, endpoints = dgp(.8, .8)
    if null_effect:
        base_joint, base_transition, base_endpoints = joint, transition, endpoints
        joint = lambda state, action: base_joint(state, 0)
        transition = lambda t, state, action: base_transition(t, state, 0)
        endpoints = lambda t, state, action: base_endpoints(t, state, 0)
    pop_lo = np.array([[[endpoints(t,s,a)[0] for a in [0,1]] for s in STATES] for t in range(T)])
    pop_hi = np.array([[[endpoints(t,s,a)[1] for a in [0,1]] for s in STATES] for t in range(T)])
    init = np.array([INITIAL.get(s,0.) for s in STATES])
    tr = np.array([[[[transition(t,s,a).get(sn,0.) for sn in STATES] for a in [0,1]] for s in STATES] for t in range(T-1)])
    exact_inputs = dict(initial=(init,init), transition=(tr,tr), reward=(pop_lo,pop_hi))
    pop_cache = {}
    rows = []
    for design, n in enumerate([4000,64000] if null_effect else [4000,64000,128000]):
        for rep in range(100):
            seed = (202609248000000 if null_effect else 202609247000000) + 10000*design + rep
            ic, counts = simulate_counts(n,T,STATES,INITIAL,joint,np.random.default_rng(seed))
            inputs = confidence_inputs(ic,counts,STATES,gamma=.1,alpha=.05)
            values = plugin_values(inputs,ic,counts,candidates)
            best, worst = int(np.argmax(values)), int(np.argmin(values))
            first, second = candidates[best], candidates[worst]
            out = bound_pair(inputs,first,second)
            if (best,worst) not in pop_cache:
                pop = bound_pair(exact_inputs,first,second)
                p1=lambda t,s:int(first[t,STATES.index(s)])
                p2=lambda t,s:int(second[t,STATES.index(s)])
                forward=contrast_bounds(signed_flows(INITIAL,transition,p1,p2,T),endpoints,weights=[1/T]*T)
                assert max(abs(pop[k]-forward[k]) for k in ['lower','upper']) < 1e-10
                pop_cache[best,worst]=pop
            pop = pop_cache[best,worst]
            rows.append(dict(seed=seed,repetition=rep,n=n,first_policy=best,second_policy=worst,
                selected_plugin_difference=float(values[best]-values[worst]),
                population_lower=pop['lower'],population_upper=pop['upper'],
                lp_fallbacks=inputs['lp_fallbacks'],empty_cells=inputs['empty_cells'],**out))
        print(f'Selection experiment: n={n}, 100 datasets completed',flush=True)
    return pd.DataFrame(rows)


def summarize_selection(raw):
    rows=[]
    for n,g in raw.groupby('n'):
        for method,prefix in [('three_status',''),('separate','separate_')]:
            l,u=g[prefix+'lower'],g[prefix+'upper']
            covered=(l<=g.population_lower+1e-9)&(u>=g.population_upper-1e-9)
            cert=(l>0)|(u<0)
            correct=((l>0)&(g.population_lower>0))|((u<0)&(g.population_upper<0))
            false=cert&~correct
            row=dict(n=int(n),method=method,reps=len(g),mean_width=float((u-l).mean()),
                     width_mc_se=float((u-l).std(ddof=1)/np.sqrt(len(g))),
                     selected_pairs=int(g[['first_policy','second_policy']].drop_duplicates().shape[0]),
                     lp_fallbacks=int(g.lp_fallbacks.sum()))
            for name,mask in [('coverage',covered),('correct',correct),('false',false)]:
                count=int(mask.sum());ci=binomtest(count,len(g)).proportion_ci(.95,method='exact')
                row.update({name+'_count':count,name:count/len(g),name+'_mc95_lower':ci.low,name+'_mc95_upper':ci.high})
            rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--selection-followup',action='store_true')
    args=parser.parse_args()
    if args.selection_followup:
        raw=selection_experiment(null_effect=True)
        seeds=set(raw.seed)
        for path in (ROOT/'results').glob('*.csv'):
            if path.name.startswith('comparison_selection_followup'): continue
            if 'seed' in pd.read_csv(path,nrows=0).columns:
                assert seeds.isdisjoint(set(pd.read_csv(path,usecols=['seed']).seed.dropna().astype('int64')))
        raw.to_csv(ROOT/'results/comparison_selection_followup_raw.csv',index=False)
        summary=summarize_selection(raw)
        summary.to_csv(ROOT/'results/comparison_selection_followup_summary.csv',index=False)
        print(summary.to_string(index=False))
        return
    start=time.perf_counter()
    expected={202609246000000+10000*d+r for d in range(8) for r in range(100)}
    expected|={202609247000000+10000*d+r for d in range(3) for r in range(100)}
    historical=set()
    for path in (ROOT/'results').glob('*.csv'):
        if path.name.startswith('comparison_'): continue
        columns=pd.read_csv(path,nrows=0).columns
        if 'seed' in columns: historical.update(pd.read_csv(path,usecols=['seed'])['seed'].dropna().astype('int64'))
    assert not expected & historical
    row=row_experiment();row.to_csv(ROOT/'results/comparison_shared_row_raw.csv',index=False)
    raw=selection_experiment();raw.to_csv(ROOT/'results/comparison_selection_raw.csv',index=False)
    summary=summarize_selection(raw);summary.to_csv(ROOT/'results/comparison_selection_summary.csv',index=False)
    row.groupby(['b','row_visits']).agg(reps=('seed','size'),joint_width=('joint_width','mean'),
        outer_width=('outer_width','mean'),joint_coverage=('joint_covered','mean'),
        outer_coverage=('outer_covered','mean'),joint_certification=('joint_certified','mean'),
        outer_certification=('outer_certified','mean')).reset_index().to_csv(ROOT/'results/comparison_shared_row_summary.csv',index=False)
    audit=dict(protocol='COMPARISON_PROTOCOL.md',shared_row_datasets=len(row),selection_datasets=len(raw),
        max_shared_row_formula_error=float(row.formula_error.max()),max_joint_lp_error=float(row.lp_error.max()),
        historical_seed_overlap=0,selection_lp_fallbacks=int(raw.lp_fallbacks.sum()),
        python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        elapsed_seconds=time.perf_counter()-start)
    (ROOT/'results/comparison_experiment_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(summary.to_string(index=False));print(json.dumps(audit,indent=2))


if __name__=='__main__': main()
