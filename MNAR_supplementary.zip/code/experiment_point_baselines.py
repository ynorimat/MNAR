"""Exploratory paired point-estimator comparison; see POINT_BASELINES_PROTOCOL.txt.

Only observed (Z,R,RY) counts enter either point estimator or outer inference.
CC uses complete-case row means. MAR-IPW uses estimated P(R=1|S,A,Z)
to weight observed rewards, then tabular evaluation with all observed transitions.
This is not an MNAR-corrected IPW estimator.
"""
import json
import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from experiment_dynamic_grid import dgp, STATES, INITIAL
from experiment_local_confidence import OBS
from state_confidence import simulate_counts, confidence_inputs, bound_pair
from sign_preserving import signed_flows, contrast_bounds

ROOT=Path(__file__).resolve().parents[1]
T=6
SIZES=[4000,64000]
STRENGTHS=[.6,.8,.95]
REPS=100
SEED_BASE=202610030700000


def evaluate(initial, transitions, rewards, first, second):
    values=[]
    for policy in [first,second]:
        v=np.zeros(4)
        for t in reversed(range(T)):
            a=policy[t]
            v=rewards[t,np.arange(4),a]/T+np.einsum('ij,j->i',transitions[t,np.arange(4),a],v)
        values.append(float(initial@v))
    return values[0]-values[1]


def point_inputs(initial_counts, counts):
    transitions=np.zeros((T,4,2,4))
    cc=np.zeros((T,4,2)); ipw=cc.copy()
    empty_rows=empty_cc=empty_zcc=0
    for t in range(T):
        for s in range(4):
            for a in range(2):
                c=counts[t,s,a].astype(float); total=c.sum()
                if total==0:
                    transitions[t,s,a]=.25; empty_rows+=1
                    continue
                for j,state in enumerate(STATES):
                    transitions[t,s,a,j]=sum(v for o,v in zip(OBS,c) if o[:2]==state)/total
                den=sum(v for (z,r,ry),v in zip(OBS,c) if r==1)
                num=sum(ry*v for (z,r,ry),v in zip(OBS,c))
                cc[t,s,a]=num/den if den else 0.
                empty_cc+=int(den==0)
                direct=0.; standardized=0.
                for z in [-1,1]:
                    nz=sum(v for o,v in zip(OBS,c) if o[0]==z)
                    nr=sum(v for o,v in zip(OBS,c) if o[0]==z and o[1]==1)
                    yr=sum(o[2]*v for o,v in zip(OBS,c) if o[0]==z)
                    if nr:
                        direct+=yr/(nr/nz)/total
                        standardized+=(nz/total)*(yr/nr)
                    elif nz:
                        empty_zcc+=1
                assert abs(direct-standardized)<1e-12
                ipw[t,s,a]=direct
    return initial_counts/initial_counts.sum(),transitions,cc,ipw,(empty_rows,empty_cc,empty_zcc)


def main():
    start=time.perf_counter()
    first=np.repeat((np.arange(T)>=T//2)[:,None],4,axis=1).astype(int)
    second=np.zeros((T,4),dtype=int)
    raw=[]; populations=[]
    for j,q in enumerate(STRENGTHS):
        joint,tr,endpoints=dgp(q,.8)
        flow=signed_flows(INITIAL,tr,lambda t,s:int(t>=3),lambda t,s:0,T)
        pop=contrast_bounds(flow,endpoints,weights=[1/T]*T)
        transition=np.array([[[[tr(t,s,a)[ns] for ns in STATES] for a in [0,1]] for s in STATES] for t in range(T)])
        truth_means=np.array([[[sum(y*p for (y,z,r),p in joint(s,a).items()) for a in [0,1]] for s in STATES] for t in range(T)])
        probability=np.array([[[[sum(p for (y,z,r),p in joint(s,a).items() if (z,r,r*y)==o) for o in OBS] for a in [0,1]] for s in STATES] for t in range(T)])
        initial=np.array([INITIAL.get(s,0.) for s in STATES])
        pi,pt,cc,ipw,_=point_inputs(initial,probability)
        truth=evaluate(initial,transition,truth_means,first,second)
        assert np.max(np.abs(transition-pt))<1e-12
        assert pop['lower']<=truth<=pop['upper']
        # Independent forward reward evaluation checks the backward evaluator.
        mean=lambda t,s,a: (sum(y*p for (y,z,r),p in joint(s,a).items()),)*2
        exact=contrast_bounds(flow,mean,weights=[1/T]*T)
        assert abs(exact['lower']-truth)<1e-12
        cc_limit=evaluate(pi,pt,cc,first,second)
        ipw_limit=evaluate(pi,pt,ipw,first,second)
        populations.append(dict(q=q,true_contrast=truth,population_lower=pop['lower'],population_upper=pop['upper'],cc_limit=cc_limit,mar_ipw_limit=ipw_limit))
        for k,n in enumerate(SIZES):
            for rep in range(REPS):
                seed=SEED_BASE+10000*j+1000*k+rep
                ni,c=simulate_counts(n,T,STATES,INITIAL,joint,np.random.default_rng(seed))
                ii,tt,cc,ipw,empty=point_inputs(ni,c)
                ci=confidence_inputs(ni,c,STATES,gamma=.1,alpha=.05)
                bound=bound_pair(ci,first,second)
                raw.append(dict(q=q,n=n,replication=rep,seed=seed,true_contrast=truth,
                    population_lower=pop['lower'],population_upper=pop['upper'],
                    cc=evaluate(ii,tt,cc,first,second),mar_ipw=evaluate(ii,tt,ipw,first,second),
                    lower=bound['lower'],upper=bound['upper'],
                    covered=bound['lower']<=pop['lower']+1e-9 and bound['upper']>=pop['upper']-1e-9,
                    certified=bound['lower']>0,lp_fallbacks=ci['lp_fallbacks'],
                    empty_rows=empty[0],empty_cc=empty[1],empty_proxy_cc=empty[2]))
            print('Completed',q,n,flush=True)
    data=pd.DataFrame(raw); summary=[]
    for (q,n),g in data.groupby(['q','n']):
        row=dict(q=q,n=n,reps=len(g),coverage=float(g.covered.mean()),certification=float(g.certified.mean()),
                 mean_width=float((g.upper-g.lower).mean()),width_se=float((g.upper-g.lower).std(ddof=1)/np.sqrt(len(g))))
        for method in ['cc','mar_ipw']:
            err=g[method]-g.true_contrast
            row[method+'_bias']=float(err.mean()); row[method+'_rmse']=float(np.sqrt(np.mean(err**2)))
            row[method+'_bias_mcse']=float(err.std(ddof=1)/np.sqrt(len(g)))
            row[method+'_positive_rate']=float((g[method]>0).mean())
        summary.append(row)
    # Verify the seed block does not reuse any retained experimental seed.
    new_seeds=set(data.seed)
    for f in (ROOT/'results').glob('*.csv'):
        if f.name.startswith('point_baselines_'): continue
        if 'seed' in pd.read_csv(f,nrows=0).columns:
            old=set(pd.read_csv(f,usecols=['seed']).seed.dropna().astype(np.int64))
            assert new_seeds.isdisjoint(old),f.name
    assert len(new_seeds)==600
    data.to_csv(ROOT/'results/point_baselines_raw.csv',index=False)
    pd.DataFrame(populations).to_csv(ROOT/'results/point_baselines_population.csv',index=False)
    pd.DataFrame(summary).to_csv(ROOT/'results/point_baselines_summary.csv',index=False)
    meta=dict(study='exploratory paired point-estimator comparison',datasets=len(data),horizon=T,
        proxy_strengths=STRENGTHS,sizes=SIZES,reps_per_cell=REPS,alpha=.05,Gamma=.1,
        observation_intercept=.8,kappa=.04,behavior_probability=.5,seed_base=SEED_BASE,
        seeds_disjoint=True,empty_row_fallback='uniform transition and zero reward',
        empty_outcome_fallback='zero mean for an empty complete-case stratum',
        empty_rows=int(data.empty_rows.sum()),empty_cc=int(data.empty_cc.sum()),
        empty_proxy_cc=int(data.empty_proxy_cc.sum()),lp_fallbacks=int(data.lp_fallbacks.sum()),
        population_forward_backward_checked=True,ipw_standardization_identity_checked=True,
        platform=platform.system(),python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        seconds=time.perf_counter()-start)
    (ROOT/'results/point_baselines_manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(pd.DataFrame(populations).to_string(index=False))
    print(pd.DataFrame(summary).to_string(index=False))
    print(json.dumps(meta,indent=2))


if __name__=='__main__':main()
