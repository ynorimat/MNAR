"""Tabular ProxFQE stress test for approximate shadow validity.

This script implements the finite-state special case of
Wei, Qu & Miao (ICML 2026): fit a complete-case bridge, impute missing rewards
by the bridge, and run tabular FQE. It also computes the population sharp
Gamma-identified interval by clock-polytope LP + Bellman recursion.
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import linprog
from scipy.special import expit

T = 4
KAPPAS = [0.0, 0.10, 0.25, 0.50]
ALPHA = -0.35
GAMMA_Y = 1.40
N = 20_000
REPS = 50
HISTORIES = [(s, op) for s in (-1, 1) for op in (0, 1)]
ACTIONS = [0, 1]
YS = [-1, 1]
ZS = [-1, 1]
OS = [0, 1]


def target_action(s, op):
    return int(0.4 * s - 0.7 * (2 * op - 1) > 0)


def local_joint(h, a, kappa):
    s, _ = h
    out = {}
    p_y1 = expit(0.15 + 0.75 * s + 0.85 * a - 0.25 * s * a)
    for y in YS:
        py = p_y1 if y == 1 else 1 - p_y1
        p_z1 = expit(1.25 * y + 0.25 * s + 0.15 * a)
        for z in ZS:
            pz = p_z1 if z == 1 else 1 - p_z1
            p_o1 = expit(ALPHA + GAMMA_Y * y + 0.10 * s - 0.10 * a + kappa * z)
            for o in OS:
                po = p_o1 if o == 1 else 1 - p_o1
                out[(y, z, o)] = py * pz * po
    return out


def population_bridge(h, a, kappa):
    joint = local_joint(h, a, kappa)
    q = {}
    for y in YS:
        den = sum(joint[(y, z, 1)] for z in ZS)
        for z in ZS:
            q[(y, z)] = joint[(y, z, 1)] / den
    M = np.array([[q[(-1, -1)], q[(-1, 1)]],
                  [q[(1, -1)], q[(1, 1)]]])
    b = np.linalg.solve(M, np.array([-1.0, 1.0]))
    return {-1: b[0], 1: b[1]}


def local_lp_bounds(h, a, kappa, gamma):
    joint = local_joint(h, a, kappa)
    mu = {z: sum(joint[(y, z, o)] for y in YS for o in OS) for z in ZS}
    syz = {(y, z): joint[(y, z, 1)] for y in YS for z in ZS}
    q = {}
    for y in YS:
        den = sum(syz[(y, z)] for z in ZS)
        for z in ZS:
            q[(y, z)] = syz[(y, z)] / den

    idx = {(-1, -1): 0, (-1, 1): 1, (1, -1): 2, (1, 1): 3}
    lr_lo, lr_hi = np.exp(-gamma), np.exp(gamma)
    Aeq, beq, Aub, bub = [], [], [], []

    for z in ZS:
        row = np.zeros(4)
        for y in YS:
            row[idx[(y, z)]] = 1
        Aeq.append(row)
        beq.append(mu[z])

    for y in YS:
        yidx = [idx[(y, -1)], idx[(y, 1)]]
        for z in ZS:
            j = idx[(y, z)]

            row = np.zeros(4)
            row[j] = -1
            Aub.append(row)
            bub.append(-syz[(y, z)])

            row = np.zeros(4)
            row[j] = 1
            for jj in yidx:
                row[jj] -= lr_hi * q[(y, z)]
            Aub.append(row)
            bub.append(0.0)

            row = np.zeros(4)
            row[j] = -1
            for jj in yidx:
                row[jj] += lr_lo * q[(y, z)]
            Aub.append(row)
            bub.append(0.0)

    c = np.array([-1.0, -1.0, 1.0, 1.0])
    kwargs = dict(A_ub=np.asarray(Aub), b_ub=np.asarray(bub),
                  A_eq=np.asarray(Aeq), b_eq=np.asarray(beq),
                  bounds=[(0, None)] * 4, method="highs")
    lo = linprog(c, **kwargs)
    hi = linprog(-c, **kwargs)
    if not (lo.success and hi.success):
        raise RuntimeError("Population clock LP infeasible")
    return lo.fun, -hi.fun


def population_values(kappa):
    init = {(-1, 1): 0.5, (1, 1): 0.5}
    v_true = {h: 0.0 for h in HISTORIES}
    v_prox = {h: 0.0 for h in HISTORIES}
    v_lo = {h: 0.0 for h in HISTORIES}
    v_hi = {h: 0.0 for h in HISTORIES}
    gamma = 2 * abs(kappa)

    for _ in reversed(range(T)):
        nxt_true, nxt_prox, nxt_lo, nxt_hi = {}, {}, {}, {}
        for h in HISTORIES:
            a = target_action(*h)
            joint = local_joint(h, a, kappa)
            bridge = population_bridge(h, a, kappa)
            true_r = sum(y * p for (y, z, o), p in joint.items())
            prox_r = sum((y if o else bridge[z]) * p
                         for (y, z, o), p in joint.items())
            trans = {(z, o): sum(joint[(y, z, o)] for y in YS)
                     for z in ZS for o in OS}
            lb, ub = local_lp_bounds(h, a, kappa, gamma)
            nxt_true[h] = true_r + sum(p * v_true[(z, o)] for (z, o), p in trans.items())
            nxt_prox[h] = prox_r + sum(p * v_prox[(z, o)] for (z, o), p in trans.items())
            nxt_lo[h] = lb + sum(p * v_lo[(z, o)] for (z, o), p in trans.items())
            nxt_hi[h] = ub + sum(p * v_hi[(z, o)] for (z, o), p in trans.items())
        v_true, v_prox, v_lo, v_hi = nxt_true, nxt_prox, nxt_lo, nxt_hi

    avg = lambda v: sum(init[h] * v[h] for h in init)
    return dict(kappa=kappa, Gamma=gamma, true_value=avg(v_true),
                prox_population=avg(v_prox), lower=avg(v_lo), upper=avg(v_hi))


def simulate(n, kappa, seed):
    rng = np.random.default_rng(seed)
    S = rng.choice([-1, 1], size=n)
    Oprev = np.ones(n, dtype=int)
    stages = []
    for _ in range(T):
        pA = expit(0.15 + 0.45 * S - 0.45 * (2 * Oprev - 1))
        A = rng.binomial(1, pA)
        pY = expit(0.15 + 0.75 * S + 0.85 * A - 0.25 * S * A)
        Y = 2 * rng.binomial(1, pY) - 1
        pZ = expit(1.25 * Y + 0.25 * S + 0.15 * A)
        Z = 2 * rng.binomial(1, pZ) - 1
        pO = expit(ALPHA + GAMMA_Y * Y + 0.10 * S - 0.10 * A + kappa * Z)
        O = rng.binomial(1, pO)
        stages.append(dict(S=S.copy(), Oprev=Oprev.copy(), A=A, Y=Y, Z=Z, O=O))
        S, Oprev = Z.copy(), O.copy()
    return stages


def fit_bridge(stage, h, a, smoothing=0.5):
    s, op = h
    cc = ((stage["S"] == s) & (stage["Oprev"] == op) &
          (stage["A"] == a) & (stage["O"] == 1))
    q1 = {}
    for y in YS:
        ym = cc & (stage["Y"] == y)
        q1[y] = ((ym & (stage["Z"] == 1)).sum() + smoothing) / (ym.sum() + 2 * smoothing)
    M = np.array([[1 - q1[-1], q1[-1]], [1 - q1[1], q1[1]]])
    rhs = np.array([-1.0, 1.0])
    b = np.linalg.pinv(M) @ rhs if abs(np.linalg.det(M)) < 1e-4 else np.linalg.solve(M, rhs)
    return {-1: b[0], 1: b[1]}


def tabular_proxfqe(stages):
    bridges = {(t, h, a): fit_bridge(stage, h, a)
               for t, stage in enumerate(stages)
               for h in HISTORIES for a in ACTIONS}
    vnext = {h: 0.0 for h in HISTORIES}

    for t in reversed(range(T)):
        stage = stages[t]
        n = len(stage["Y"])
        cont = np.zeros(n)
        for z in ZS:
            for o in OS:
                cont[(stage["Z"] == z) & (stage["O"] == o)] = vnext[(z, o)]

        pseudo = stage["Y"].astype(float).copy()
        missing = stage["O"] == 0
        for h in HISTORIES:
            s, op = h
            for a in ACTIONS:
                base = (missing & (stage["S"] == s) & (stage["Oprev"] == op) & (stage["A"] == a))
                b = bridges[(t, h, a)]
                pseudo[base & (stage["Z"] == -1)] = b[-1]
                pseudo[base & (stage["Z"] == 1)] = b[1]

        target = pseudo + cont
        Q = {}
        for h in HISTORIES:
            s, op = h
            for a in ACTIONS:
                m = ((stage["S"] == s) & (stage["Oprev"] == op) & (stage["A"] == a))
                Q[(h, a)] = np.nan if m.sum() == 0 else target[m].mean()
        vnext = {h: Q[(h, target_action(*h))] for h in HISTORIES}

    # Only H0=(S0,1) is reachable; unreachable NaNs never enter this average.
    return np.mean([vnext[(int(s), 1)] for s in stages[0]["S"]])


def main():
    out = Path(__file__).resolve().parents[1] / "results"
    figs = Path(__file__).resolve().parents[1] / "figures"
    out.mkdir(exist_ok=True)
    figs.mkdir(exist_ok=True)

    pop = pd.DataFrame([population_values(k) for k in KAPPAS])
    pop["prox_bias"] = pop["prox_population"] - pop["true_value"]
    pop["interval_width"] = pop["upper"] - pop["lower"]
    pop.to_csv(out / "population_results.csv", index=False)

    raw = []
    for j, kappa in enumerate(KAPPAS):
        for rep in range(REPS):
            est = tabular_proxfqe(simulate(N, kappa, 2609000 + 10000 * j + rep))
            raw.append(dict(kappa=kappa, rep=rep, prox_estimate=est))
    raw = pd.DataFrame(raw)
    raw.to_csv(out / "proxfqe_mc_raw.csv", index=False)

    mc = raw.groupby("kappa", as_index=False).agg(
        prox_mc_mean=("prox_estimate", "mean"),
        prox_mc_sd=("prox_estimate", "std"),
    )
    summary = pop.merge(mc, on="kappa")
    summary.to_csv(out / "proxfqe_shadow_violation_summary.csv", index=False)

    x = summary["kappa"].to_numpy()
    fig, ax = plt.subplots(figsize=(7.4, 4.9))
    ax.fill_between(x, summary["lower"], summary["upper"], alpha=0.20,
                    label=r"Sharp $\Gamma$-identified interval")
    ax.plot(x, summary["true_value"], marker="o", label="True policy value")
    ax.plot(x, summary["prox_population"], marker="o", label="ProxFQE point functional")
    ax.errorbar(x, summary["prox_mc_mean"], yerr=summary["prox_mc_sd"], fmt="o",
                capsize=3, label=f"Tabular ProxFQE, n={N:,} (mean ± MC SD)")
    ax.set_xlabel(r"Direct shadow violation $\kappa$")
    ax.set_ylabel("Target-policy value")
    ax.set_title("Exact-shadow point evaluation fails as shadow validity is violated")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(figs / "fig_proxfqe_vs_partial_id.png", dpi=200)


if __name__ == "__main__":
    main()
