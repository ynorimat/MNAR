#!/usr/bin/env python3
"""Policy-ranking certification study; all confidence LPs use observed counts only."""
import itertools
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import expit

import experiment_factorized_trajectory_lp as seq
from experiment_endpoint_inference import Model, cp_intervals

ROOT = Path(__file__).resolve().parents[1]


def law(effect, kappa=.1):
    out = {}
    for atom in itertools.product(seq.B, seq.V, seq.V, seq.B,
                                  seq.B, seq.V, seq.V, seq.B):
        a0, y1, z1, r1, a1, y2, z2, r2 = atom
        h = seq.h1(a0, y1, z1, r1)
        py = expit(-.1 + effect*a1 + .2*z1 + .15*a0 + .15*r1*y1)
        out[atom] = (seq.pi0(a0)*seq.py1(y1,a0)*seq.pz(z1,y1)*
                     seq.pr(r1,y1,z1,kappa)*seq.pi1(a1,h)*
                     (py if y2 == 1 else 1-py)*seq.pz(z2,y2)*seq.pr(r2,y2,z2,kappa))
    assert abs(sum(out.values())-1) < 1e-12
    return out


def summary(raw):
    rows = []
    for (effect,n), g in raw.groupby(['effect','n'],sort=False):
        good = g.outer_status.eq(0)
        positive = good & g.outer_lower.gt(0)
        negative = good & g.outer_upper.lt(0)
        correct = (positive & g.population_lower.gt(0)) | (negative & g.population_upper.lt(0))
        false = (positive | negative) & ~correct
        wrong_truth = ((positive & g.true_contrast.le(1e-12)) |
                       (negative & g.true_contrast.ge(-1e-12)))
        abstain = ~(positive | negative)
        cover = good & g.outer_lower.le(g.population_lower+1e-7) & g.outer_upper.ge(g.population_upper-1e-7)
        row = dict(effect=effect,n=n,replications=len(g),population_lower=g.population_lower.iloc[0],
                   population_upper=g.population_upper.iloc[0],true_contrast=g.true_contrast.iloc[0],
                   coverage=cover.mean(),mean_width=(g.outer_upper-g.outer_lower).mean(),
                   lp_failures=int((~good).sum()),positive_count=int(positive.sum()),
                   negative_count=int(negative.sum()))
        for name, mask in [('correct',correct),('false_robust',false),
                           ('wrong_truth',wrong_truth),('abstain',abstain)]:
            count = int(mask.sum())
            lo,hi = cp_intervals(np.array([count]),np.array([len(g)]),.05)
            row.update({name+'_count':count,name+'_rate':count/len(g),
                        name+'_mc95_lower':float(lo[0]),name+'_mc95_upper':float(hi[0])})
        assert row['correct_count']+row['false_robust_count']+row['abstain_count']==len(g)
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    start = time.perf_counter()
    old = pd.read_csv(ROOT/'results/endpoint_inference_raw.csv')
    metadata = json.loads((ROOT/'results/endpoint_inference_manifest.json').read_text())
    old['effect'] = .6
    old['population_lower'],old['population_upper'] = metadata['population_endpoints']
    old['true_contrast'] = metadata['true_contrast']
    old['source'] = 'retained original 800 runs'
    results = [old]
    designs = []
    for j,effect in enumerate([2.4,-2.4,0.]):
        model = Model(truth_law=law(effect))
        pop = model.population(); assert pop[2]==0
        plugin = model.plugin(model.observed_probability*1e7)
        assert np.max(np.abs(np.array(plugin[:2])-pop[:2]))<1e-8
        truth = float(model.objective @ np.array([model.truth_law[a] for a in model.atoms]))
        assert pop[0]-1e-10<=truth<=pop[1]+1e-10
        designs.append(dict(effect=effect,population_lower=pop[0],population_upper=pop[1],true_contrast=truth))
        rows = []
        for k,n in enumerate([1000,4000,16000,64000]):
            for r in range(200):
                seed=2027091800+1000000*j+100000*k+r
                counts=np.random.default_rng(seed).multinomial(n,model.observed_probability)
                lo,hi,status=model.confidence(counts)
                rows.append(dict(effect=effect,n=n,replication=r,seed=seed,
                                 outer_lower=lo,outer_upper=hi,outer_status=status,
                                 population_lower=pop[0],population_upper=pop[1],
                                 true_contrast=truth,source='scheduled ranking experiment'))
            print(summary(pd.DataFrame(rows)).tail(1).to_string(index=False),flush=True)
        results.append(pd.DataFrame(rows))
    raw=pd.concat(results,ignore_index=True)
    raw.to_csv(ROOT/'results/ranking_certificates_raw.csv',index=False)
    summary(raw).to_csv(ROOT/'results/ranking_certificates_summary.csv',index=False)
    manifest=dict(new_replications=2400,retained_replications=800,alpha=.05,kappa=.1,Gamma=.2,
                  reward_support=[-1,1],weights=[1,1],scalar_intervals=196,
                  new_designs=designs,seconds=time.perf_counter()-start,
                  decision_target='sign valid for every law in the population compatible class',
                  false_robust='certificate whose direction fails for at least one compatible law',
                  wrong_truth='certificate contradicting the generating causal contrast')
    (ROOT/'results/ranking_certificates_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':
    main()
