"""Rebuild the focused manuscript displays from retained experiment results.

No simulation is run and no original result file is overwritten.
With --paper, writes manuscript tables and figure input CSVs into that tree.
Without --paper, writes them under display_v3/ beside the results directory.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import mean


def load(path):
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def hashes(folder):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.iterdir()) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, default=Path(__file__).resolve().parents[1] / 'results')
    parser.add_argument('--paper', type=Path)
    args = parser.parse_args()
    before = hashes(args.results)
    out = args.paper or args.results.parent / 'display_v3'
    figures, tables = out / 'figures', out / 'sections'
    figures.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)

    dynamic = load(args.results / 'dynamic_grid.csv')
    assert len(dynamic) == 81
    for r in dynamic:
        assert float(r['lower']) - 1e-12 <= float(r['true_contrast']) <= float(r['upper']) + 1e-12
        assert abs(float(r['pooled_lower']) - float(r['lower']) - float(r['pooling_gap'])) < 1e-12
        assert abs(float(r['lower']) - float(r['separate_lower']) - float(r['common_gain'])) < 1e-12
    with (figures / 'key_cancellation.csv').open('w', encoding='utf-8', newline='') as f:
        fields = ['split'] + [f'T{h}_{s}' for h in [3,6,12] for s in ['mean','min','max']]
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
        for idx, split in enumerate(['initial','middle','last']):
            row = {'split': idx}
            for h in [3,6,12]:
                vals = [float(r['width_reduction']) for r in dynamic if int(r['horizon']) == h and r['split_category'] == split]
                assert len(vals) == 9
                row.update({f'T{h}_mean':mean(vals),f'T{h}_min':min(vals),f'T{h}_max':max(vals)})
            writer.writerow(row)

    contrast = load(args.results / 'physionet_policy_contrast.csv')
    contrast = [r for r in contrast if .05 - 1e-12 <= float(r['Gamma']) <= .11 + 1e-12]
    assert len(contrast) == 13
    r08 = next(r for r in contrast if abs(float(r['Gamma'])-.08)<1e-12)
    assert round(float(r08['lower']),5) == -.01267
    assert round(float(r08['pooled_lower']),5) == .00964
    with (figures / 'key_ranking.csv').open('w', encoding='utf-8', newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['Gamma','lower','pooled_lower']);writer.writeheader()
        writer.writerows({k:r[k] for k in writer.fieldnames} for r in contrast)

    overlap = load(args.results / 'overlap_summary.csv')
    selected = sorted([r for r in overlap if int(r['n'])==128000 and float(r['behavior_probability'])==.5 and r['split_category']=='middle'], key=lambda r:float(r['proxy_strength']))
    assert len(selected)==3
    table = [r'\begin{tabular}{@{}rrrrrr@{}}',r'\toprule',r'$q$&$W_{\rm pop}$&$W_{\rm local}$&$W_{\rm dyn}$&$W_{\rm full}$&Cert. (\%)\\\midrule']
    for r in selected:
        p,l,d,w = [float(r[k]) for k in ['population_width','mean_local_excess','mean_dynamics_excess','mean_width']]
        assert abs(p+l+d-w)<1e-12
        table.append(f"{float(r['proxy_strength']):g} & {p:.3f} & {l:.3f} & {d:.3f} & {w:.3f} & {100*float(r['correct']):.0f}/{100*float(r['separate_correct']):.0f}"+r'\\')
    table += [r'\bottomrule',r'\end{tabular}']
    (tables/'uncertainty_table.tex').write_text('\n'.join(table)+'\n',encoding='utf-8')

    ref = load(args.results / 'refinement_summary.csv')
    assert len(ref)==48
    def get(q,n,pair,method,prop):
        found = [r for r in ref if float(r['q'])==q and int(r['n'])==n and r['pair']==pair and r['local_method']==method and r['propagation']==prop]
        assert len(found)==1
        return found[0]
    methods=sorted({r['local_method'] for r in ref}); props=sorted({r['propagation'] for r in ref})
    pairs=sorted({r['pair'] for r in ref})
    assert methods==['base','partition'] and 'three_status' in props
    sep=next(x for x in props if x!='three_status')
    state=next(x for x in pairs if x!='middle')
    table=[r'\begin{tabular}{@{}rrlrrrr@{}}',r'\toprule',r'$q$&$n/1000$&Pair&$\bar L$ (B/P)&$W_C$ (B/P)&$W_S$ (B/P)&Cert. (B/P, \%)\\\midrule']
    for q in [.8,.95]:
        for n in [32000,64000,128000]:
            for pair,label in [('middle','Switch'),(state,'State')]:
                b,p=[get(q,n,pair,m,'three_status') for m in methods]
                bs,ps=[get(q,n,pair,m,sep) for m in methods]
                lower='/'.join(f"{float(r['mean_lower']):.3f}" for r in [b,p])
                wc='/'.join(f"{float(r['mean_width']):.3f}" for r in [b,p])
                ws='/'.join(f"{float(r['mean_width']):.3f}" for r in [bs,ps])
                cert='/'.join(f"{100*float(r['certification']):.0f}" for r in [b,p])
                table.append(f'{q:g} & {n//1000} & {label} & {lower} & {wc} & {ws} & {cert}'+r'\\')
    table += [r'\bottomrule',r'\end{tabular}']
    (tables/'refinement_table.tex').write_text('\n'.join(table)+'\n',encoding='utf-8')
    assert hashes(args.results)==before
    report={'source_results_unchanged':True,'dynamic_settings':81,'cancellation_settings_per_point':9,'ranking_radii':len(contrast),'uncertainty_rows':len(selected),'refinement_rows':12,'source_sha256':{name:before[name] for name in ['dynamic_grid.csv','physionet_policy_contrast.csv','overlap_summary.csv','refinement_summary.csv']}}
    (out/'display_audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}))

if __name__=='__main__':
    main()
