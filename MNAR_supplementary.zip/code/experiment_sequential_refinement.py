"""Sequential paired refinement experiment; see SEQUENTIAL_REFINEMENT_PROTOCOL.md."""
import argparse
import itertools
import json
import platform
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import binomtest

from experiment_dynamic_grid import STATES, INITIAL, dgp, enumerated_bounds
from experiment_consistency_local import partition_bounds
from sign_preserving import signed_flows, contrast_bounds
from state_confidence import confidence_inputs, local_bounds, bound_pair, simulate_counts

ROOT = Path(__file__).resolve().parents[1]
BASE = 202609249000000
DESIGNS = list(itertools.product([.8, .95], [32000, 64000, 128000]))


def refined_inputs(initial, counts):
    statuses = dict(optimal=0, infeasible=0, numerical_failure=0, empty_union=0)
    def solve(plo, phi, qlo, qhi, gamma):
        lo, hi, stats = partition_bounds(plo, phi, qlo, qhi, gamma, pieces=4)
        for key in statuses:
            statuses[key] += stats[key]
        if stats['numerical_failure'] or stats['empty_union']:
            lo, hi, _ = local_bounds(plo, phi, qlo, qhi, gamma)
            return lo, hi, 1
        return lo, hi, 0
    inputs = confidence_inputs(initial, counts, STATES, local_solver=solve)
    return inputs, statuses


def pairs(T=6):
    middle = np.tile((np.arange(T) >= T//2)[:, None], (1, len(STATES))).astype(int)
    state_first = np.tile([int(z == 1 or r == 0) for z, r in STATES], (T, 1))
    state_second = np.tile([int(z == 1) for z, r in STATES], (T, 1))
    return [('middle', middle, np.zeros_like(middle)), ('state', state_first, state_second)]


def population(q, T=6):
    joint, transition, endpoints = dgp(q, .8)
    init = np.array([INITIAL.get(s, 0.) for s in STATES])
    tr = np.array([[[[transition(t,s,a)[sn] for sn in STATES] for a in [0,1]]
                    for s in STATES] for t in range(T-1)])
    lo = np.array([[[endpoints(t,s,a)[0] for a in [0,1]] for s in STATES] for t in range(T)])
    hi = np.array([[[endpoints(t,s,a)[1] for a in [0,1]] for s in STATES] for t in range(T)])
    exact = dict(initial=(init,init), transition=(tr,tr), reward=(lo,hi))
    result = {}
    for name, first, second in pairs(T):
        f = lambda t,s: int(first[t,STATES.index(s)])
        g = lambda t,s: int(second[t,STATES.index(s)])
        forward = contrast_bounds(signed_flows(INITIAL,transition,f,g,T),endpoints,weights=[1/T]*T)
        backward = bound_pair(exact,first,second)
        assert max(abs(forward[k]-backward[k]) for k in ['lower','upper']) < 1e-9
        if T == 3:
            enumeration = enumerated_bounds(joint,endpoints,f,g,T)
            assert max(abs(enumeration[i]-forward[k]) for i,k in enumerate(['lower','upper'])) < 1e-9
        result[name] = forward
    return result


def run_design(task):
    index, q, n, reps = task
    joint, _, _ = dgp(q, .8)
    pop = population(q)
    records, count_records, initial_records = [], [], []
    start = time.perf_counter()
    for rep in range(reps):
        seed = BASE + 10000*index + rep
        initial, counts = simulate_counts(n,6,STATES,INITIAL,joint,np.random.default_rng(seed))
        initial_records.append(initial); count_records.append(counts)
        # Alternate order to reduce systematic warm-cache effects on timings.
        methods = ['base','partition'] if rep % 2 == 0 else ['partition','base']
        inputs, timings, stats = {}, {}, {}
        for method in methods:
            tic = time.perf_counter()
            if method == 'base':
                inputs[method] = confidence_inputs(initial,counts,STATES)
            else:
                inputs[method], stats = refined_inputs(initial,counts)
            timings[method] = time.perf_counter()-tic
        for key in ['initial','transition']:
            for x,y in zip(inputs['base'][key],inputs['partition'][key]):
                assert np.array_equal(x,y)
        bl,bu=inputs['base']['reward']; pl,pu=inputs['partition']['reward']
        assert np.min(pl-bl)>-1e-8 and np.max(pu-bu)<1e-8
        for name,first,second in pairs():
            outputs={m:bound_pair(inp,first,second) for m,inp in inputs.items()}
            for prefix in ['', 'separate_']:
                assert outputs['partition'][prefix+'lower'] >= outputs['base'][prefix+'lower']-1e-8
                assert outputs['partition'][prefix+'upper'] <= outputs['base'][prefix+'upper']+1e-8
            for method,out in outputs.items():
                records.append(dict(design=index,q=q,n=n,repetition=rep,seed=seed,pair=name,
                    method=method,population_lower=float(pop[name]['lower']),
                    population_upper=float(pop[name]['upper']),seconds=timings[method],
                    lp_fallbacks=inputs[method]['lp_fallbacks'],empty_cells=inputs[method]['empty_cells'],
                    **{k:(v if method=='partition' else 0) for k,v in stats.items()},**out))
        if (rep+1)%20==0:
            print(f'q={q}, n={n}: {rep+1}/{reps} datasets',flush=True)
    frame=pd.DataFrame(records)
    frame.to_csv(ROOT/f'results/refinement_design_{index}_raw.csv',index=False)
    np.savez_compressed(ROOT/f'results/refinement_design_{index}_counts.npz',
        initial=np.array(initial_records),counts=np.array(count_records),
        seeds=np.array([BASE+10000*index+r for r in range(reps)],dtype=np.int64))
    return dict(design=index,q=q,n=n,datasets=reps,seconds=time.perf_counter()-start)


def summarize():
    raw=pd.concat([pd.read_csv(ROOT/f'results/refinement_design_{i}_raw.csv') for i in range(6)])
    raw.to_csv(ROOT/'results/refinement_raw.csv',index=False)
    summary=[]
    for (q,n,pair,method),g in raw.groupby(['q','n','pair','method']):
        for label,prefix in [('three_status',''),('separate','separate_')]:
            lower,upper=g[prefix+'lower'],g[prefix+'upper']
            covered=(lower<=g.population_lower+1e-9)&(upper>=g.population_upper-1e-9)
            cert=(lower>0)|(upper<0)
            correct=((lower>0)&(g.population_lower>0))|((upper<0)&(g.population_upper<0))
            row=dict(q=q,n=int(n),pair=pair,local_method=method,propagation=label,reps=len(g),
                population_lower=g.population_lower.iloc[0],population_upper=g.population_upper.iloc[0],
                mean_lower=lower.mean(),mean_upper=upper.mean(),mean_width=(upper-lower).mean(),
                width_mc_se=(upper-lower).std(ddof=1)/np.sqrt(len(g)),
                mean_seconds=g.seconds.mean(),median_seconds=g.seconds.median(),
                lp_fallbacks=int(g.lp_fallbacks.sum()))
            for name,values in [('coverage',covered),('certification',cert),('false_certification',cert&~correct)]:
                x=int(values.sum());ci=binomtest(x,len(g)).proportion_ci(.95,method='exact')
                row[name]=x/len(g);row[name+'_mc_lower']=ci.low;row[name+'_mc_upper']=ci.high
            summary.append(row)
    pd.DataFrame(summary).to_csv(ROOT/'results/refinement_summary.csv',index=False)
    base=raw[raw.method=='base'].set_index(['q','n','pair','repetition'])
    part=raw[raw.method=='partition'].set_index(['q','n','pair','repetition'])
    paired=pd.DataFrame({'lower_gain':part.lower-base.lower,
                         'width_reduction':(base.upper-base.lower)-(part.upper-part.lower)})
    paired.reset_index().to_csv(ROOT/'results/refinement_paired.csv',index=False)
    return raw


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--reps',type=int,default=100);args=parser.parse_args()
    existing=set()
    for path in (ROOT/'results').glob('*.csv'):
        if path.name.startswith('refinement_'): continue
        if 'seed' in pd.read_csv(path,nrows=0).columns:
            existing.update(pd.read_csv(path,usecols=['seed']).seed.dropna().astype('int64'))
    new={BASE+10000*i+r for i in range(6) for r in range(args.reps)}
    assert not new & existing
    for q in [.8,.95]: population(q,T=3)
    start=time.perf_counter()
    tasks=[(i,q,n,args.reps) for i,(q,n) in enumerate(DESIGNS)]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        runs=list(pool.map(run_design,tasks))
    raw=summarize()
    manifest=dict(datasets=len(new),policy_pairs=2,method_pair_records=len(raw),
        alpha=.05,gamma=.1,horizon=6,seed_base=BASE,historical_seed_overlap=0,
        workers=args.workers,python=platform.python_version(),numpy=np.__version__,
        scipy=scipy.__version__,seconds=time.perf_counter()-start,designs=runs,
        note='Exploratory fixed protocol. Timings measured with concurrent workers; see serial timing check.')
    (ROOT/'results/refinement_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2),flush=True)


if __name__=='__main__': main()
