#!/usr/bin/env python3
"""Sharp policy contrasts with full observed histories.

Equal compressed states do not force equal latent reward completions. Preserve
history until the sign of the shared-law contrast coefficient has been taken.
The optional pooled-state curve is a diagnostic under an additional restriction.
"""
import argparse,json
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import run_physionet_semisynthetic as phys


def read_mdp(project):
    df=pd.read_csv(project/'results/physionet_initial_distribution.csv')
    init={(int(r.state),int(r.agebin)):float(r.prob) for r in df.itertuples()}
    trans={}
    df=pd.read_csv(project/'results/physionet_empirical_transitions.csv')
    for (t,s,ag),g in df.groupby(['stage','state','agebin']):
        trans[(int(t),int(s),int(ag))]={int(r.next_state):float(r.prob) for r in g.itertuples()}
    return init,trans


def compressed(h):
    return (h[0],h[1],1) if len(h)==2 else (h[-3],h[1],h[-2])


def action(h,policy):
    s,ag,o=compressed(h)
    return int(s==1 or (policy=='missingness' and o==0))


def occupancies(init,trans,policy):
    by_time=[];mass=dict(init)
    for t in range(phys.T):
        assert np.isclose(sum(mass.values()),1.)
        by_time.append(mass)
        nxt=defaultdict(float)
        for h,p in mass.items():
            a=action(h,policy)
            for (y,z,o),q in phys.local_joint(t,compressed(h),a,0.,trans).items():
                nxt[h+(a,z,o,o*y)]+=p*q
        mass=dict(nxt)
    return by_time


def contrast_coefficients(init,trans):
    om=occupancies(init,trans,'missingness');os=occupancies(init,trans,'state')
    coefficients=[]
    for t in range(phys.T):
        c=defaultdict(float)
        for h,p in om[t].items(): c[(h,action(h,'missingness'))]+=p
        for h,p in os[t].items(): c[(h,action(h,'state'))]-=p
        coefficients.append(dict(c))
    return coefficients


def bounds(coeff,trans,gamma,pooled=False):
    total_lo=total_hi=0.;cache={}
    for t,c in enumerate(coeff):
        if pooled:
            cp=defaultdict(float)
            for (h,a),v in c.items(): cp[(compressed(h),a)]+=v
            pairs=[(s,a,v) for (s,a),v in cp.items()]
        else:
            pairs=[(compressed(h),a,v) for (h,a),v in c.items()]
        for s,a,v in pairs:
            if abs(v)<1e-15: continue
            key=(t,s,a)
            if key not in cache:
                cache[key]=phys.lp_from_joint(phys.local_joint(t,s,a,0.,trans),gamma)
            lo,hi=cache[key]
            total_lo+=v*(lo if v>=0 else hi)
            total_hi+=v*(hi if v>=0 else lo)
    return total_lo,total_hi


def threshold(coeff,trans,pooled=False):
    lo,hi=0.,.45
    assert bounds(coeff,trans,lo,pooled)[0]>0
    assert bounds(coeff,trans,hi,pooled)[0]<0
    for _ in range(40):
        mid=(lo+hi)/2
        if bounds(coeff,trans,mid,pooled)[0]>0:lo=mid
        else:hi=mid
    return (lo+hi)/2


def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1]);args=p.parse_args()
    init,trans=read_mdp(args.project);coeff=contrast_coefficients(init,trans)
    rows=[]
    for gamma in np.linspace(0,.45,91):
        lo,hi=bounds(coeff,trans,gamma)
        pl,pu=bounds(coeff,trans,gamma,True)
        assert lo<=pl+1e-9 and hi>=pu-1e-9
        rows.append(dict(Gamma=gamma,lower=lo,upper=hi,pooled_lower=pl,pooled_upper=pu))
    df=pd.DataFrame(rows);gs=threshold(coeff,trans);ps=threshold(coeff,trans,True)
    out=args.project/'results';figs=args.project/'figures';out.mkdir(exist_ok=True);figs.mkdir(exist_ok=True)
    df.to_csv(out/'physionet_policy_contrast.csv',index=False)
    stats={'full_history_threshold':gs,'pooled_state_threshold':ps,'zero_radius_difference':bounds(coeff,trans,0)[0], 'full_history_lower_at_0_08':bounds(coeff,trans,.08)[0]}
    (out/'policy_contrast_audit.json').write_text(json.dumps(stats,indent=2)+'\n')
    plt.rcParams.update({'font.size':7.5,'pdf.fonttype':42,'ps.fonttype':42})
    fig,ax=plt.subplots(figsize=(3.35,2.25))
    x=df.Gamma.to_numpy();ax.fill_between(x,df.lower.to_numpy(),df.upper.to_numpy(),color='#407aa4',alpha=.20,label='Sharp full-history interval')
    ax.plot(x,df.lower,color='#23628e',lw=1.0)
    ax.plot(x,df.pooled_lower,color='#ba6b24',linestyle='--',lw=1.0,label='Pooled lower endpoint')
    ax.axhline(0,color='#444444',lw=.8);ax.axvline(gs,color='#23628e',linestyle=':',label=rf'$\Gamma^\star={gs:.3f}$')
    ax.set(xlabel=r'Sensitivity radius $\Gamma$',ylabel='Policy-value difference',xlim=(0,.45))
    ax.set_xticks([0,.1,.2,.3,.4])
    ax.grid(alpha=.18);ax.legend(fontsize=6.2,loc='upper left',framealpha=.9,labelspacing=.2,handlelength=1.5);fig.tight_layout(pad=.4)
    fig.savefig(figs/'fig_policy_robustness.pdf');fig.savefig(figs/'fig_policy_robustness.png',dpi=180);plt.close(fig)
    print(json.dumps(stats,indent=2))
if __name__=='__main__': main()
