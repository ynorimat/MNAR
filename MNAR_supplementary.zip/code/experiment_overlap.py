"""Disclosed overlap/proxy extension; see OVERLAP_PROTOCOL.md.

The oracle-row calculation is a diagnostic, not an implementable estimator.
Original experiment records are never overwritten.
"""
import itertools
import json
import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import beta

from experiment_dynamic_grid import dgp, STATES, INITIAL
from sign_preserving import signed_flows, contrast_bounds
from state_confidence import confidence_inputs, bound_pair, simulate_counts

ROOT = Path(__file__).resolve().parents[1]
TAG = 'overlap'
BASE = 202609240000000
T = 6
ALPHA = .05
REPS = 100
DESIGNS = list(itertools.product([.6, .8, .95], [.1, .5, .9], [64000, 128000]))


def summarize(raw):
    rows = []
    for key, group in raw.groupby(['proxy_strength', 'behavior_probability', 'n', 'split_category']):
        row = dict(zip(['proxy_strength', 'behavior_probability', 'n', 'split_category'], key))
        row['reps'] = len(group)
        for name in ['covered', 'correct', 'wrong', 'abstain', 'separate_correct', 'separate_covered', 'separate_wrong', 'separate_abstain']:
            x, total = int(group[name].sum()), len(group)
            row[name] = x / total
            row[name+'_mc_lower'] = 0. if x == 0 else beta.ppf(.025, x, total-x+1)
            row[name+'_mc_upper'] = 1. if x == total else beta.ppf(.975, x+1, total-x)
        for name in ['width', 'separate_width', 'oracle_width', 'local_excess', 'dynamics_excess',
                     'lp_fallbacks', 'empty_cells', 'min_visited_cell_count', 'seconds']:
            row['mean_'+name] = float(group[name].mean())
            row['se_'+name] = float(group[name].std(ddof=1)/np.sqrt(len(group)))
        for name in ['population_lower', 'population_upper', 'population_width']:
            row[name] = float(group[name].iloc[0])
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    seeds = {BASE+100000*d+r for d in range(len(DESIGNS)) for r in range(REPS)}
    old_seeds = set()
    for path in (ROOT/'results').glob('*.csv'):
        if path.name.startswith(TAG):
            continue
        if 'seed' in pd.read_csv(path, nrows=0).columns:
            old_seeds.update(pd.read_csv(path, usecols=['seed']).seed.dropna().astype(np.int64))
    assert len(seeds) == 1800 and seeds.isdisjoint(old_seeds)
    started = time.perf_counter()
    rows = []
    p0 = np.zeros((T, len(STATES)), int)
    initial = np.array([INITIAL.get(s, 0.) for s in STATES])
    for index, (q, behavior, n) in enumerate(DESIGNS):
        joint, transition, endpoints = dgp(q, .8)
        tr = np.array([[[[transition(t, s, a).get(ns, 0.) for ns in STATES]
                        for a in [0, 1]] for s in STATES] for t in range(T-1)])
        policies = []
        for category, split in [('initial', 0), ('middle', 3), ('last', 5)]:
            first = np.repeat((np.arange(T) >= split)[:, None], len(STATES), axis=1).astype(int)
            pop = contrast_bounds(signed_flows(INITIAL, transition, lambda t,s,j=split: int(t>=j),
                                               lambda t,s: 0, T), endpoints, weights=[1/T]*T)
            policies.append((category, first, pop))
        for rep in range(REPS):
            seed = BASE+100000*index+rep
            ic, counts = simulate_counts(n, T, STATES, INITIAL, joint, np.random.default_rng(seed),
                                         behavior_probability=behavior)
            tick = time.perf_counter()
            inputs = confidence_inputs(ic, counts, STATES, gamma=.1, alpha=ALPHA)
            oracle = dict(inputs, initial=(initial, initial), transition=(tr, tr))
            counts_per_cell = counts.sum(axis=-1)
            positive_counts = counts_per_cell[counts_per_cell > 0]
            elapsed = time.perf_counter()-tick
            for category, first, pop in policies:
                result = bound_pair(inputs, first, p0)
                exact_rows = bound_pair(oracle, first, p0)
                lo, hi = result['lower'], result['upper']
                sl, su = result['separate_lower'], result['separate_upper']
                ow = exact_rows['upper']-exact_rows['lower']
                pw = pop['upper']-pop['lower']
                correct = lambda l,u: (l>0 and pop['lower']>0) or (u<0 and pop['upper']<0)
                wrong = (lo>0 and pop['lower']<=0) or (hi<0 and pop['upper']>=0)
                rows.append(dict(proxy_strength=q, behavior_probability=behavior, n=n,
                    horizon=T, split_category=category, replication=rep, seed=seed,
                    lower=lo, upper=hi, width=hi-lo, separate_lower=sl, separate_upper=su,
                    separate_width=su-sl, oracle_lower=exact_rows['lower'], oracle_upper=exact_rows['upper'],
                    oracle_width=ow, population_lower=pop['lower'], population_upper=pop['upper'],
                    population_width=pw, local_excess=ow-pw, dynamics_excess=hi-lo-ow,
                    covered=lo<=pop['lower']+1e-9 and hi>=pop['upper']-1e-9,
                    correct=correct(lo, hi), wrong=wrong, abstain=not(lo>0 or hi<0),
                    separate_correct=correct(sl, su),
                    separate_covered=sl<=pop['lower']+1e-9 and su>=pop['upper']-1e-9,
                    separate_wrong=(sl>0 and pop['lower']<=0) or (su<0 and pop['upper']>=0),
                    separate_abstain=not(sl>0 or su<0),
                    lp_fallbacks=inputs['lp_fallbacks'], empty_cells=inputs['empty_cells'],
                    scalar_intervals=inputs['scalar_intervals'], alpha=ALPHA,
                    min_visited_cell_count=int(positive_counts.min()), seconds=elapsed))
        raw = pd.DataFrame(rows)
        raw.to_csv(ROOT/'results'/f'{TAG}_raw.csv', index=False)
        print(f'Completed {index+1}/{len(DESIGNS)}: q={q}, behavior={behavior}, n={n}', flush=True)
    summary = summarize(raw)
    summary.to_csv(ROOT/'results'/f'{TAG}_summary.csv', index=False)
    manifest = dict(independent_datasets=1800, paired_policy_comparisons=len(raw),
        implementable_method_records=2*len(raw), oracle_diagnostic_records=len(raw),
        reps_per_cell=REPS, alpha=ALPHA, horizon=T, gamma=.1, observation_intercept=.8,
        kappa=.04, seed_base=BASE, seed_disjoint=True, python=platform.python_version(),
        numpy=np.__version__, scipy=scipy.__version__, seconds=time.perf_counter()-started,
        note='Exploratory proxy/overlap study; all results retained. Oracle knows observed dynamics only.')
    (ROOT/'results'/f'{TAG}_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(manifest, indent=2), flush=True)


if __name__ == '__main__':
    main()
