"""Focused validation and serial timings for the sequential refinement."""
import json
import time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from experiment_dynamic_grid import dgp
from experiment_local_confidence import OBS
from experiment_consistency_local import partition_bounds
from experiment_sequential_refinement import refined_inputs, STATES, pairs
from state_confidence import confidence_inputs, bound_pair
import experiment_policy_robustness as old
import run_physionet_semisynthetic as phys

ROOT=Path(__file__).resolve().parents[1]


def main():
    error=0.
    for q in [.8,.95]:
        joint,_,ends=dgp(q,.8)
        for state in STATES:
            for action in [0,1]:
                law=joint(state,action)
                p=np.array([sum(v for (y,z,r),v in law.items() if (z,r,r*y)==o) for o in OBS])
                qs=np.array([law[y,1,1]/sum(law[y,z,1] for z in [-1,1]) for y in [-1,1]])
                lo,hi,stats=partition_bounds(p,p,qs,qs,.1)
                l,u=ends(0,state,action)
                error=max(error,abs(l-lo),abs(u-hi))
                assert not stats['numerical_failure'] and not stats['empty_union']
    assert error<1e-9
    saved=np.load(ROOT/'results/refinement_design_0_counts.npz')
    initial,counts=saved['initial'][0],saved['counts'][0]
    base=confidence_inputs(initial,counts,STATES)
    # Both kinds of partition failure must retain the original outer interval.
    for status in ['numerical_failure','empty_union']:
        flags=dict(optimal=0,infeasible=0,numerical_failure=0,empty_union=0)
        flags[status]=1
        with patch('experiment_sequential_refinement.partition_bounds',return_value=(-1.,1.,flags)):
            recovered,_=refined_inputs(initial,counts)
        assert recovered['lp_fallbacks']>0
        for x,y in zip(base['reward'],recovered['reward']): assert np.allclose(x,y)
    timings=[]
    # Reuse saved counts after all parallel simulations finish: no extra samples.
    for design in range(6):
        sample=np.load(ROOT/f'results/refinement_design_{design}_counts.npz')
        for rep in range(3):
            initial,counts=sample['initial'][rep],sample['counts'][rep]
            for method in (['base','partition'] if rep%2==0 else ['partition','base']):
                tic=time.perf_counter()
                inp=(confidence_inputs(initial,counts,STATES) if method=='base' else refined_inputs(initial,counts)[0])
                construction=time.perf_counter()-tic
                tic=time.perf_counter()
                for _,a,b in pairs(): bound_pair(inp,a,b)
                propagation=time.perf_counter()-tic
                timings.append(dict(design=design,rep=rep,method=method,
                    construction_seconds=construction,two_pair_seconds=propagation,
                    total_seconds=construction+propagation))
    pd.DataFrame(timings).to_csv(ROOT/'results/refinement_serial_timings.csv',index=False)
    # Reevaluate the supplied witness, without changing its optimizer kernels.
    records=pd.read_csv(ROOT/'results/adverse_completion_kernels.csv');kernels={}
    for r in records.itertuples():
        h=tuple(json.loads(r.history))
        kernels.setdefault((r.stage,h,r.action),{})[r.y,r.z,r.r]=r.probability
    initial,trans=old.read_mdp(ROOT);values={};max_obs=0.
    for (t,h,a),kernel in kernels.items():
        law=phys.local_joint(t,old.compressed(h),a,0.,trans)
        for o in OBS:
            coarsen=lambda j:sum(v for (y,z,r),v in j.items() if (z,r,r*y)==o)
            max_obs=max(max_obs,abs(coarsen(kernel)-coarsen(law)))
    for policy in ['missingness','state']:
        masses=dict(initial);value=0.
        for t in range(phys.T):
            following={}
            for h,p in masses.items():
                a=old.action(h,policy);law=kernels[t,h,a]
                value+=p*sum(y*v for (y,z,r),v in law.items())
                for (y,z,r),v in law.items():
                    nxt=h+(a,z,r,r*y);following[nxt]=following.get(nxt,0.)+p*v
            masses=following
        values[policy]=value
    delta=values['missingness']-values['state']
    assert abs(delta+0.012674303742829296)<1e-10 and max_obs<1e-10
    raw=pd.read_csv(ROOT/'results/refinement_raw.csv')
    assert len(raw)==2400 and raw.seed.nunique()==600
    assert raw.groupby(['q','n','pair','method']).size().eq(100).all()
    report=dict(population_local_cells=16,partition_singleton_max_error=error,
        numerical_failure_fallback_checked=True,empty_union_fallback_checked=True,
        datasets=600,raw_records=2400,serial_timing_records=len(timings),
        adverse_completion_values=values,adverse_completion_contrast=delta,
        adverse_completion_observed_kernel_max_error=max_obs,
        note='Numerical verification; not independent human proof verification.')
    (ROOT/'results/refinement_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__': main()
