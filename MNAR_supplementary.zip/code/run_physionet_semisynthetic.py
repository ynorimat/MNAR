#!/usr/bin/env python3
"""
PhysioNet-calibrated semi-synthetic ICU benchmark.

Real-data input: PhysioNet/CinC Challenge 2012 Set A patient text files.
We aggregate 48h into four 12h bins, construct a fixed synthetic severity index
from real vitals/labs, bin it at the cohort median, and estimate stage-specific
Markov transitions P(S_{t+1}|S_t, age-bin) from the real ICU trajectories.
Treatment, binary reward, and MNAR observation are then semi-synthesized on top
of those empirical state dynamics. S_{t+1} is the shadow variable, matching the
future-state construction used in MNAR-reward OPE.

At kappa=0, O_{t+1} depends on (Y_{t+1}, H_t, A_t) but not S_{t+1}, so the exact
shadow condition holds. kappa != 0 creates a direct future-state -> observation
path and violates it.

Outputs include exact population dynamic-programming quantities, finite-sample
tabular ProxFQE Monte Carlo results, and sharp Clock-Bellman sensitivity bounds.
"""
from __future__ import annotations
import argparse, warnings
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.optimize import linprog
import matplotlib.pyplot as plt

DYN_VARS=["HR","RespRate","Temp","GCS","Creatinine","BUN","Glucose","WBC","Urine","MechVent"]
FEATURES=["HR","RespRate","Temp","GCS","MAPx","Creatinine","BUN","Glucose","WBC","Urine","MechVent"]
SVALS=(-1,1); OVALS=(0,1); AVALS=(0,1); YVALS=(-1,1)
T=3  # decisions between four 12h bins


def time_to_hour(s):
    hh,mm=s.split(":"); return int(hh)+int(mm)/60


def parse_patient(path):
    df=pd.read_csv(path)
    if not {"Time","Parameter","Value"}.issubset(df.columns): raise ValueError("bad columns")
    df["hour"]=df.Time.map(time_to_hour)
    base={}
    for k in ["RecordID","Age","Gender","ICUType"]:
        v=df.loc[df.Parameter==k,"Value"]; base[k]=float(v.iloc[0]) if len(v) else np.nan
    rows=[]
    for b in range(4):
        sub=df[(df.hour>=12*b)&(df.hour<12*(b+1))]
        r={"RecordID":int(base["RecordID"]),"bin":b,"Age":base["Age"],"Gender":base["Gender"],"ICUType":base["ICUType"]}
        for v in DYN_VARS:
            x=pd.to_numeric(sub.loc[sub.Parameter==v,"Value"],errors="coerce"); x=x[x>=0]
            if v=="Urine": r[v]=x.sum() if len(x) else np.nan
            elif v=="MechVent": r[v]=x.max() if len(x) else np.nan
            else: r[v]=x.median() if len(x) else np.nan
        m=pd.to_numeric(sub.loc[sub.Parameter=="MAP","Value"],errors="coerce"); m=m[m>=0]
        nm=pd.to_numeric(sub.loc[sub.Parameter=="NIMAP","Value"],errors="coerce"); nm=nm[nm>=0]
        r["MAPx"]=m.median() if len(m) else (nm.median() if len(nm) else np.nan)
        rows.append(r)
    return rows


def preprocess_states(df):
    df=df.sort_values(["RecordID","bin"]).copy()
    for c in FEATURES:
        df[c]=df.groupby("RecordID")[c].transform(lambda x:x.ffill().bfill())
        med=df[c].median(); med=0.0 if not np.isfinite(med) else med
        df[c]=df[c].fillna(med)
        sd=df[c].std(ddof=0); sd=1.0 if not np.isfinite(sd) or sd<1e-8 else sd
        df[f"z_{c}"]=(df[c]-df[c].mean())/sd
    age=df.Age.replace(-1,np.nan); df["Age"]=age.fillna(age.median())
    df["severity"]=(0.30*df.z_HR+0.25*df.z_RespRate-0.25*df.z_GCS-0.25*df.z_MAPx+
                    0.20*df.z_Creatinine+0.15*df.z_BUN+0.10*df.z_WBC+0.08*df.z_Glucose+0.08*df.z_MechVent)
    df["state"]=np.where(df.severity>df.severity.median(),1,-1).astype(int)
    age_med=df.groupby("RecordID").Age.first().median(); df["agebin"]=(df.Age>=age_med).astype(int)
    counts=df.groupby("RecordID").bin.nunique(); keep=counts[counts==4].index
    return df[df.RecordID.isin(keep)].reset_index(drop=True)


def load_physionet(data_dir,max_patients=None):
    fs=sorted((data_dir/"set-a").glob("*.txt")) if (data_dir/"set-a").exists() else sorted(data_dir.glob("*.txt"))
    fs=[p for p in fs if p.stem.isdigit()]
    if max_patients: fs=fs[:max_patients]
    if not fs: raise FileNotFoundError(f"No numeric patient files under {data_dir}")
    rows=[]
    for p in fs:
        try: rows.extend(parse_patient(p))
        except Exception as e: warnings.warn(f"Skipping {p.name}: {e}")
    return preprocess_states(pd.DataFrame(rows))


def demo_states(n=3000,seed=42):
    rng=np.random.default_rng(seed); rows=[]
    for i in range(n):
        age=np.clip(rng.normal(64,15),18,95); u=rng.normal()
        for b in range(4):
            u=.76*u+rng.normal(scale=.62)
            r={"RecordID":i,"bin":b,"Age":age,"Gender":rng.integers(0,2),"ICUType":rng.integers(1,5),
               "HR":82+10*u+rng.normal(0,7),"RespRate":18+3*u+rng.normal(0,2.5),"Temp":37+.3*u+rng.normal(0,.35),
               "GCS":np.clip(14-1.1*u+rng.normal(0,1),3,15),"MAPx":82-8*u+rng.normal(0,7),
               "Creatinine":max(.3,1+.28*u+rng.normal(0,.2)),"BUN":max(3,20+5*u+rng.normal(0,4)),
               "Glucose":max(45,125+18*u+rng.normal(0,18)),"WBC":max(1,10+2*u+rng.normal(0,2)),
               "Urine":max(0,700-120*u+rng.normal(0,150)),"MechVent":float(rng.random()<expit(-1.2+.8*u))}
            for c in FEATURES:
                if rng.random()<(0.08 if c in ["HR","RespRate","MAPx"] else .28): r[c]=np.nan
            rows.append(r)
    return preprocess_states(pd.DataFrame(rows))


def build_empirical_mdp(df):
    wide=df.pivot(index="RecordID",columns="bin",values="state")
    age=df.groupby("RecordID").agebin.first()
    ids=wide.index.intersection(age.index); wide=wide.loc[ids]; age=age.loc[ids]
    # initial P(S0, age)
    init=defaultdict(float)
    for rid in ids: init[(int(wide.loc[rid,0]),int(age.loc[rid]))]+=1
    N=len(ids); init={k:v/N for k,v in init.items()}
    # stage-specific transition with Laplace smoothing
    trans={}
    for t in range(T):
        for s in SVALS:
            for ag in (0,1):
                sub=[rid for rid in ids if int(wide.loc[rid,t])==s and int(age.loc[rid])==ag]
                cnt={sp:1.0 for sp in SVALS}
                for rid in sub: cnt[int(wide.loc[rid,t+1])]+=1
                den=sum(cnt.values()); trans[(t,s,ag)]={sp:cnt[sp]/den for sp in SVALS}
    return init,trans


def hstates(): return [(s,ag,o) for s in SVALS for ag in (0,1) for o in OVALS]

def behavior_p(h):
    s,ag,o=h; return float(np.clip(expit(-.25+.60*s+.22*ag+.45*(1-o)),.08,.92))

def target_a(h):
    s,ag,o=h; return int(s==1 or o==0)

def py1(sp,a): return float(expit(.15-1.05*sp+.72*a+.20*a*sp))
def po1(y,s,a,z,kappa): return float(expit(-.55+1.35*y+.15*s+.15*a+kappa*z))


def local_joint(t,h,a,kappa,trans):
    """P(y,z,o | h,a), where z=S_{t+1}; also z is next physiologic state."""
    s,ag,op=h; out={}
    for z,pz in trans[(t,s,ag)].items():
        p1=py1(z,a)
        for y in YVALS:
            py=p1 if y==1 else 1-p1
            oo=po1(y,s,a,z,kappa)
            for o in OVALS:
                po=oo if o==1 else 1-oo
                out[(y,z,o)]=pz*py*po
    return out


def bridge_from_joint(joint):
    # 2x2 bridge because future state z in {-1,+1}.
    q={}
    for y in YVALS:
        den=sum(joint[(y,z,1)] for z in SVALS)
        q[y]=joint[(y,1,1)]/den
    M=np.array([[1-q[-1],q[-1]],[1-q[1],q[1]]]); rhs=np.array([-1.,1.])
    b=np.linalg.solve(M,rhs) if abs(np.linalg.det(M))>1e-10 else np.linalg.pinv(M)@rhs
    return {-1:float(b[0]),1:float(b[1])}


def lp_from_joint(joint,Gamma):
    mu={z:sum(joint[(y,z,o)] for y in YVALS for o in OVALS) for z in SVALS}
    syz={(y,z):joint[(y,z,1)] for y in YVALS for z in SVALS}
    q={}; supported={}
    for y in YVALS:
        d=sum(syz[(y,z)] for z in SVALS)
        supported[y]=d>0
        for z in SVALS:q[(y,z)]=syz[(y,z)]/d if d>0 else 0.
    idx={(-1,-1):0,(-1,1):1,(1,-1):2,(1,1):3}; l,u=np.exp(-Gamma),np.exp(Gamma)
    Aeq=[];beq=[];Aub=[];bub=[]
    for z in SVALS:
        row=np.zeros(4)
        for y in YVALS:row[idx[(y,z)]]=1
        Aeq.append(row);beq.append(mu[z])
    for y in YVALS:
        yi=[idx[(y,-1)],idx[(y,1)]]
        for z in SVALS:
            j=idx[(y,z)]
            row=np.zeros(4);row[j]=-1;Aub.append(row);bub.append(-syz[(y,z)])
            row=np.zeros(4);row[j]=1
            for jj in yi:row[jj]-=u*q[(y,z)]
            Aub.append(row);bub.append(0)
            row=np.zeros(4);row[j]=-1
            for jj in yi:row[jj]+=l*q[(y,z)]
            Aub.append(row);bub.append(0)
    # Under population observation positivity, s_y=0 forces x_yz=0.
    bounds=[(0,None) if supported[y] else (0,0) for y in YVALS for z in SVALS]
    c=np.array([-1.,-1.,1.,1.]);kw=dict(A_ub=np.array(Aub),b_ub=np.array(bub),A_eq=np.array(Aeq),b_eq=np.array(beq),bounds=bounds,method="highs")
    lo=linprog(c,**kw);hi=linprog(-c,**kw)
    if not(lo.success and hi.success): raise RuntimeError("population LP infeasible")
    return float(lo.fun),float(-hi.fun)


def population_dp(init,trans,kappa):
    Gamma=2*abs(kappa); H=hstates()
    Tv={h:0. for h in H}; Pv={h:0. for h in H}; Lv={h:0. for h in H}; Uv={h:0. for h in H}
    for t in reversed(range(T)):
        Tn,Pn,Ln,Un={}, {}, {}, {}
        for h in H:
            a=target_a(h); j=local_joint(t,h,a,kappa,trans); b=bridge_from_joint(j); lo,hi=lp_from_joint(j,Gamma)
            tr={(z,o):sum(j[(y,z,o)] for y in YVALS) for z in SVALS for o in OVALS}
            true_r=sum(y*p for (y,z,o),p in j.items())
            prox_r=sum((y if o==1 else b[z])*p for (y,z,o),p in j.items())
            s,ag,op=h
            Tn[h]=true_r+sum(p*Tv[(z,ag,o)] for (z,o),p in tr.items())
            Pn[h]=prox_r+sum(p*Pv[(z,ag,o)] for (z,o),p in tr.items())
            Ln[h]=lo+sum(p*Lv[(z,ag,o)] for (z,o),p in tr.items())
            Un[h]=hi+sum(p*Uv[(z,ag,o)] for (z,o),p in tr.items())
        Tv,Pv,Lv,Uv=Tn,Pn,Ln,Un
    # previous reward observed initially
    def av(V):return sum(p*V[(s,ag,1)] for (s,ag),p in init.items())
    return av(Tv),av(Pv),av(Lv),av(Uv)


def simulate_offline(init,trans,kappa,n,seed):
    rng=np.random.default_rng(seed); init_keys=list(init); probs=np.array([init[k] for k in init_keys]); ix=rng.choice(len(init_keys),size=n,p=probs)
    s=np.array([init_keys[i][0] for i in ix]); ag=np.array([init_keys[i][1] for i in ix]); op=np.ones(n,dtype=int); stages=[]
    for t in range(T):
        hs=list(zip(s.tolist(),ag.tolist(),op.tolist())); pa=np.array([behavior_p(h) for h in hs]); a=rng.binomial(1,pa)
        z=np.empty(n,dtype=int)
        for i in range(n):
            pr=trans[(t,int(s[i]),int(ag[i]))]; z[i]=rng.choice(SVALS,p=[pr[-1],pr[1]])
        pyy=expit(.15-1.05*z+.72*a+.20*a*z); y=2*rng.binomial(1,pyy)-1
        poo=expit(-.55+1.35*y+.15*s+.15*a+kappa*z); o=rng.binomial(1,poo)
        stages.append(pd.DataFrame({"s":s,"ag":ag,"op":op,"a":a,"y":y,"z":z,"o":o}))
        s,op=z,o
    return stages


def est_bridge(st,h,a,smoothing=1.0):
    s,ag,op=h;cc=st[(st.s==s)&(st.ag==ag)&(st.op==op)&(st.a==a)&(st.o==1)];q={}
    for y in YVALS:
        yy=cc[cc.y==y]; q[y]=((yy.z==1).sum()+smoothing)/(len(yy)+2*smoothing)
    M=np.array([[1-q[-1],q[-1]],[1-q[1],q[1]]]);rhs=np.array([-1.,1.]);b=np.linalg.solve(M,rhs) if abs(np.linalg.det(M))>1e-4 else np.linalg.pinv(M)@rhs
    return {-1:float(b[0]),1:float(b[1])}


def tabular_proxfqe(stages):
    H=hstates();V={h:0. for h in H}
    for t in reversed(range(T)):
        st=stages[t].copy();B={(h,a):est_bridge(st,h,a) for h in H for a in AVALS}
        cont=np.array([V[(int(r.z),int(r.ag),int(r.o))] for r in st.itertuples()]);pseudo=st.y.to_numpy(dtype=float).copy()
        for i,r in enumerate(st.itertuples()):
            if r.o==0:pseudo[i]=B[((int(r.s),int(r.ag),int(r.op)),int(r.a))][int(r.z)]
        target=pseudo+cont;Q={};gm=float(np.mean(target))
        for h in H:
            for a in AVALS:
                s,ag,op=h;m=(st.s==s)&(st.ag==ag)&(st.op==op)&(st.a==a);Q[(h,a)]=float(np.mean(target[m])) if m.sum() else gm
        V={h:Q[(h,target_a(h))] for h in H}
    st0=stages[0];return float(np.mean([V[(int(r.s),int(r.ag),1)] for r in st0.itertuples()]))


def run(df,out,n_offline=12000,reps=30,kappas=(0,.1,.25,.5),seed=91):
    out.mkdir(parents=True,exist_ok=True);init,trans=build_empirical_mdp(df);pop=[];raw=[]
    for j,k in enumerate(kappas):
        tv,pv,lo,hi=population_dp(init,trans,k);pop.append({"kappa":k,"Gamma":2*abs(k),"true_value":tv,"prox_population":pv,"lower":lo,"upper":hi,"width":hi-lo,"covered":lo-1e-10<=tv<=hi+1e-10})
        for r in range(reps):raw.append({"kappa":k,"rep":r,"prox":tabular_proxfqe(simulate_offline(init,trans,k,n_offline,seed+10000*j+r))})
    pop=pd.DataFrame(pop);raw=pd.DataFrame(raw);mc=raw.groupby("kappa",as_index=False).agg(prox_mc_mean=("prox","mean"),prox_mc_sd=("prox","std"));summ=pop.merge(mc,on="kappa")
    df[["RecordID","bin","Age","severity","state","agebin"]].to_csv(out/"preprocessed_state_summary.csv",index=False);pop.to_csv(out/"population_summary.csv",index=False);raw.to_csv(out/"mc_raw.csv",index=False);summ.to_csv(out/"mc_summary.csv",index=False)
    fig,ax=plt.subplots(figsize=(7.4,4.9));x=summ.kappa.to_numpy();ax.fill_between(x,summ.lower.to_numpy(),summ.upper.to_numpy(),alpha=.2,label=r"Sharp $\Gamma$-identified interval");ax.plot(x,summ.true_value,marker="o",label="True policy value");ax.plot(x,summ.prox_population,marker="o",label="Exact-shadow ProxFQE functional");ax.errorbar(x,summ.prox_mc_mean,yerr=summ.prox_mc_sd,fmt="o",capsize=3,label=f"Tabular ProxFQE, n={n_offline:,}");ax.set_xlabel(r"Direct shadow violation $\kappa$");ax.set_ylabel("Cumulative policy value");ax.set_title("PhysioNet-calibrated semi-synthetic ICU stress test");ax.grid(True,alpha=.25);ax.legend();fig.tight_layout();fig.savefig(out/"fig_physionet_semisynth.png",dpi=200);plt.close(fig)
    return summ


def main():
    p=argparse.ArgumentParser();p.add_argument("--data-dir",type=Path);p.add_argument("--out",type=Path,default=Path("physionet_semisynth_results"));p.add_argument("--demo",action="store_true");p.add_argument("--max-patients",type=int);p.add_argument("--n-offline",type=int,default=50000);p.add_argument("--reps",type=int,default=10);args=p.parse_args()
    if args.demo:df=demo_states()
    elif args.data_dir is not None:df=load_physionet(args.data_dir,args.max_patients)
    else:raise SystemExit("Provide --data-dir or use --demo")
    print(f"Prepared {df.RecordID.nunique()} four-bin ICU trajectories")
    print(run(df,args.out,args.n_offline,args.reps).to_string(index=False))
if __name__=="__main__":main()
