"""Same-input nested local outer LP diagnostic; see CONSISTENCY_PROTOCOL.md.

The partitioned union is an outer relaxation of joint observed-law consistency.
It is not exact joint nonlinear optimization and is not the primary estimator.
"""
import itertools
import json
import platform
import time
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog
from scipy.stats import binomtest
from experiment_dynamic_grid import dgp
from experiment_endpoint_inference import cp_intervals
from experiment_local_confidence import ATOMS, OBS, COARSE, MEAN
from state_confidence import local_bounds

ROOT = Path(__file__).resolve().parents[1]
BASE = 202609243000000


def partition_bounds(plo, phi, qlo, qhi, gamma, pieces=4):
    """Enclose consistent kernels by a union of pieces**2 local LPs.

    Add q_lo*s_y <= s_(y,+1) <= q_hi*s_y for each candidate's own
    complete-case masses. In a rectangle, also tighten the sensitivity band.
    Every consistent candidate belongs to a rectangle; every rectangle LP is
    a subset of the original relaxed LP. Equality/zero-mass strata are safe.
    """
    grids = [np.linspace(l,u,pieces+1) for l,u in zip(qlo,qhi)]
    extrema = [[],[]]
    statuses = dict(optimal=0,infeasible=0,numerical_failure=0)
    for indices in itertools.product(range(pieces), repeat=2):
        rows = [*COARSE,*(-COARSE)]; rhs = [*phi,*(-plo)]
        for j,y in enumerate([-1,1]):
            ql,qu = grids[j][indices[j]:indices[j]+2]
            ymass = np.array([float(a[0]==y) for a in ATOMS])
            sy = np.array([float(a[0]==y and a[2]==1) for a in ATOMS])
            syplus = np.array([float(a==(y,1,1)) for a in ATOMS])
            rows.extend([ql*sy-syplus,syplus-qu*sy]);rhs.extend([0.,0.])
            for z,l,u in [(1,ql,qu),(-1,1-qu,1-ql)]:
                xyz=np.array([float(a[:2]==(y,z)) for a in ATOMS])
                rows.extend([np.exp(-gamma)*l*ymass-xyz,xyz-np.exp(gamma)*u*ymass])
                rhs.extend([0.,0.])
        for endpoint,sign in enumerate([1,-1]):
            fit=linprog(sign*MEAN,A_ub=np.asarray(rows),b_ub=rhs,
                        A_eq=np.ones((1,8)),b_eq=[1.],bounds=(0,None),method='highs')
            if fit.success:
                statuses['optimal']+=1;extrema[endpoint].append(float(sign*fit.fun))
            elif fit.status==2:
                statuses['infeasible']+=1
            else:
                statuses['numerical_failure']+=1;extrema[endpoint].append(-float(sign))
    if not all(extrema):
        return -1.,1.,dict(statuses,empty_union=1)
    return min(extrema[0]),max(extrema[1]),dict(statuses,empty_union=0)


def main():
    designs=list(itertools.product([.6,.8,.95],[500,5000]));reps=30
    seeds={BASE+10000*j+r for j in range(len(designs)) for r in range(reps)}
    existing=set()
    for path in (ROOT/'results').glob('*.csv'):
        if path.name.startswith('consistency_'):continue
        if 'seed' in pd.read_csv(path,nrows=0).columns:
            existing.update(pd.read_csv(path,usecols=['seed']).seed.dropna().astype('int64'))
    assert not seeds & existing
    records=[];started=time.perf_counter()
    for index,(q,N) in enumerate(designs):
        joint,_,endpoints=dgp(q,.8)
        law=joint((-1,1),0)
        observed=np.array([sum(p for (y,z,r),p in law.items() if (z,r,r*y)==o) for o in OBS])
        poplo,pophi=endpoints(0,(-1,1),0)
        for rep in range(reps):
            seed=BASE+10000*index+rep
            counts=np.random.default_rng(seed).multinomial(N,observed)
            plo,phi=cp_intervals(counts,np.full(6,N),.05/8)
            qx=np.array([sum(c for o,c in zip(OBS,counts) if o==(1,1,y)) for y in [-1,1]])
            qn=np.array([sum(c for o,c in zip(OBS,counts) if o[1:]==(1,y)) for y in [-1,1]])
            qlo,qhi=cp_intervals(qx,qn,.05/8)
            tic=time.perf_counter();lo,hi,status=local_bounds(plo,phi,qlo,qhi,.1)
            base_seconds=time.perf_counter()-tic
            tic=time.perf_counter();pl,pu,stats=partition_bounds(plo,phi,qlo,qhi,.1)
            part_seconds=time.perf_counter()-tic
            if not stats['numerical_failure'] and not stats['empty_union']:
                assert pl>=lo-1e-8 and pu<=hi+1e-8
            row=dict(q=q,row_visits=N,replication=rep,seed=seed,
                population_lower=poplo,population_upper=pophi,population_width=pophi-poplo,
                base_lower=lo,base_upper=hi,base_width=hi-lo,
                partition_lower=pl,partition_upper=pu,partition_width=pu-pl,
                removable_relaxation=(hi-lo)-(pu-pl),remaining_excess=(pu-pl)-(pophi-poplo),
                base_covered=lo<=poplo+1e-9 and hi>=pophi-1e-9,
                partition_covered=pl<=poplo+1e-9 and pu>=pophi-1e-9,
                base_fallback=status,base_seconds=base_seconds,partition_seconds=part_seconds,**stats)
            row.update({f'count_{i}':int(x) for i,x in enumerate(counts)})
            records.append(row)
        print(f'Local diagnostic {index+1}/{len(designs)} completed: q={q}, N={N}',flush=True)
    raw=pd.DataFrame(records)
    raw.to_csv(ROOT/'results/consistency_local_raw.csv',index=False)
    summaries=[]
    for (q,N),g in raw.groupby(['q','row_visits']):
        row=dict(q=q,row_visits=N,reps=len(g),population_lower=g.population_lower.iloc[0],
                 population_upper=g.population_upper.iloc[0],population_width=g.population_width.iloc[0])
        for name in ['base_width','partition_width','removable_relaxation','remaining_excess','base_seconds','partition_seconds']:
            row['mean_'+name]=g[name].mean();row['se_'+name]=g[name].std(ddof=1)/np.sqrt(len(g))
        for name in ['base_covered','partition_covered']:
            x=int(g[name].sum());ci=binomtest(x,len(g)).proportion_ci(.95,method='exact')
            row[name]=x/len(g);row[name+'_mc_lower']=ci.low;row[name+'_mc_upper']=ci.high
        for name in ['base_fallback','numerical_failure','empty_union','infeasible']:
            row[name]=int(g[name].sum())
        summaries.append(row)
    pd.DataFrame(summaries).to_csv(ROOT/'results/consistency_local_summary.csv',index=False)
    report=dict(independent_conditional_datasets=len(raw),reps_per_design=reps,
        interval_budget=8,alpha=.05,partition_rectangles=16,seed_base=BASE,
        historical_seed_overlap=0,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        seconds=time.perf_counter()-started,
        note='Conditional-row diagnostic; partitioned results remain outer and do not isolate pure sampling error.')
    (ROOT/'results/consistency_local_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(pd.DataFrame(summaries).to_string(index=False),flush=True)


if __name__=='__main__':main()
