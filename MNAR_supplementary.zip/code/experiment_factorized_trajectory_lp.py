#!/usr/bin/env python3
"""Exact two-stage check: Clock-Bellman = behavior-factorized trajectory LP."""
import itertools,argparse
from collections import defaultdict
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import linprog
from scipy.special import expit
V=(-1,1);B=(0,1)
def pi0(a):return .5
def py1(y,a):
 p=expit(-.2+.8*a);return p if y==1 else 1-p
def pz(z,y):return .8 if z==y else .2
def pr(r,y,z,k):
 p=expit(-.4+1.1*y+k*z);return p if r else 1-p
def h1(a0,y,z,r):return (a0,z,r,r*y)
def pi1p(h):a0,z,r,oy=h;return float(expit(-.2+.35*a0+.45*z+.5*oy+.15*r))
def pi1(a,h):p=pi1p(h);return p if a else 1-p
def py2(y,h,a):
 a0,z,r,oy=h;p=expit(-.1+.6*a+.2*z+.15*a0+.15*oy);return p if y==1 else 1-p
def d0():return 1
def d1(h):return int(h[1]==1 or h[2]==0)
def atoms(k):
 out={}
 for a0,y1,z1,r1,a1,y2,z2,r2 in itertools.product(B,V,V,B,B,V,V,B):
  h=h1(a0,y1,z1,r1);out[(a0,y1,z1,r1,a1,y2,z2,r2)]=pi0(a0)*py1(y1,a0)*pz(z1,y1)*pr(r1,y1,z1,k)*pi1(a1,h)*py2(y2,h,a1)*pz(z2,y2)*pr(r2,y2,z2,k)
 return out
def obs(a):a0,y1,z1,r1,a1,y2,z2,r2=a;return (a0,z1,r1,r1*y1,a1,z2,r2,r2*y2)
def constants(P):
 pO=defaultdict(float)
 for a,p in P.items():pO[obs(a)]+=p
 loc0={}
 for a0 in B:
  M=sum(p for a,p in P.items() if a[0]==a0);mu={z:sum(p for a,p in P.items() if a[0]==a0 and a[2]==z)/M for z in V};s={(y,z):sum(p for a,p in P.items() if a[0]==a0 and a[1]==y and a[2]==z and a[3]==1)/M for y in V for z in V};loc0[a0]=(M,mu,s)
 hs=set((h1(a[0],a[1],a[2],a[3]),a[4]) for a in P);loc1={}
 for h,aa in hs:
  q=[(a,p) for a,p in P.items() if h1(a[0],a[1],a[2],a[3])==h and a[4]==aa];M=sum(p for a,p in q);mu={z:sum(p for a,p in q if a[6]==z)/M for z in V};s={(y,z):sum(p for a,p in q if a[5]==y and a[6]==z and a[7]==1)/M for y in V for z in V};loc1[(h,aa)]=(M,mu,s)
 tr={}
 for a0 in B:
  M=sum(p for a,p in P.items() if a[0]==a0);d=defaultdict(float)
  for a,p in P.items():
   if a[0]==a0:d[h1(a[0],a[1],a[2],a[3])]+=p/M
  tr[a0]=d
 return pO,loc0,loc1,tr
def local(mu,s,G):
 q={}
 for y in V:
  d=sum(s[(y,z)] for z in V)
  for z in V:q[(y,z)]=s[(y,z)]/d
 idx={(-1,-1):0,(-1,1):1,(1,-1):2,(1,1):3};l,u=np.exp(-G),np.exp(G);Ae=[];be=[];Au=[];bu=[]
 for z in V:
  row=np.zeros(4)
  for y in V:row[idx[(y,z)]]=1
  Ae.append(row);be.append(mu[z])
 for y in V:
  yi=[idx[(y,z)] for z in V]
  for z in V:
   j=idx[(y,z)];row=np.zeros(4);row[j]=-1;Au.append(row);bu.append(-s[(y,z)]);row=np.zeros(4);row[j]=1
   for jj in yi:row[jj]-=u*q[(y,z)]
   Au.append(row);bu.append(0);row=np.zeros(4);row[j]=-1
   for jj in yi:row[jj]+=l*q[(y,z)]
   Au.append(row);bu.append(0)
 c=np.array([-1,-1,1,1.]);kw=dict(A_ub=np.array(Au),b_ub=np.array(bu),A_eq=np.array(Ae),b_eq=np.array(be),bounds=[(0,None)]*4,method='highs');lo=linprog(c,**kw);hi=linprog(-c,**kw);return lo.fun,-hi.fun
def bellman(P,G):
 _,l0,l1,tr=constants(P);mb={k:local(v[1],v[2],G) for k,v in l1.items()};a=d0();L,U=local(l0[a][1],l0[a][2],G)
 for h,p in tr[a].items():l,u=mb[(h,d1(h))];L+=p*l;U+=p*u
 return L,U
def global_lp(P,G):
 A=list(P);n=len(A);I={a:i for i,a in enumerate(A)};pO,l0,l1,_=constants(P);Ae=[];be=[];Au=[];bu=[];grp=defaultdict(list)
 for a in A:grp[obs(a)].append(I[a])
 for o,ids in grp.items():row=np.zeros(n);row[ids]=1;Ae.append(row);be.append(pO[o])
 # behavior-factorization constraints, including latent prefixes when R1=0
 for pref in set(a[:4] for a in A):
  h=h1(*pref)
  for aa in B:
   row=np.zeros(n)
   for a in A:
    if a[:4]==pref:row[I[a]]+=(1 if a[4]==aa else 0)-pi1(aa,h)
   Ae.append(row);be.append(0.)
 l,u=np.exp(-G),np.exp(G)
 def add_clock(items,M,mu,s,get_yz):
  q={}
  for y in V:
   d=sum(s[(y,z)] for z in V)
   for z in V:q[(y,z)]=s[(y,z)]/d
  def vec(y,z):
   row=np.zeros(n)
   for a in items:
    if get_yz(a)==(y,z):row[I[a]]=1
   return row
  for z in V:
   row=sum((vec(y,z) for y in V),start=np.zeros(n));Ae.append(row);be.append(M*mu[z])
  for y in V:
   vy=sum((vec(y,z) for z in V),start=np.zeros(n))
   for z in V:
    x=vec(y,z);Au.append(-x);bu.append(-M*s[(y,z)]);Au.append(x-u*q[(y,z)]*vy);bu.append(0.);Au.append(-x+l*q[(y,z)]*vy);bu.append(0.)
 for a0,(M,mu,s) in l0.items():add_clock([a for a in A if a[0]==a0],M,mu,s,lambda a:(a[1],a[2]))
 for (h,aa),(M,mu,s) in l1.items():add_clock([a for a in A if h1(a[0],a[1],a[2],a[3])==h and a[4]==aa],M,mu,s,lambda a:(a[5],a[6]))
 c=np.zeros(n)
 for a in A:
  a0,y1,z1,r1,a1,y2,z2,r2=a;h=h1(a0,y1,z1,r1);w1=(a0==d0())/pi0(a0);w2=w1*(a1==d1(h))/pi1(a1,h);c[I[a]]=y1*w1+y2*w2
 kw=dict(A_ub=np.array(Au),b_ub=np.array(bu),A_eq=np.array(Ae),b_eq=np.array(be),bounds=[(0,None)]*n,method='highs');lo=linprog(c,**kw);hi=linprog(-c,**kw);return lo.fun,-hi.fun
def truth(P):
 v=0
 for a,p in P.items():
  a0,y1,z1,r1,a1,y2,z2,r2=a;h=h1(a0,y1,z1,r1);w1=(a0==d0())/pi0(a0);w2=w1*(a1==d1(h))/pi1(a1,h);v+=p*(y1*w1+y2*w2)
 return v
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path('experiment_sequential_sharpness.csv'));args=ap.parse_args();rows=[]
 for k in [0,.1,.25,.5,.75]:
  P=atoms(k);G=2*abs(k);bl,bh=bellman(P,G);gl,gh=global_lp(P,G);rows.append({'kappa':k,'Gamma':G,'truth':truth(P),'global_lo':gl,'global_hi':gh,'bellman_lo':bl,'bellman_hi':bh,'global_width':gh-gl,'bellman_width':bh-bl})
 pd.DataFrame(rows).to_csv(args.out,index=False);print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
