#!/usr/bin/env python3
"""Observed-predictor Gamma calibration with patient-disjoint folds and half-open 12-hour bins. The benchmark severity state is retrospectively constructed; calibration is descriptive, not causal."""
import argparse,csv
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold,cross_val_predict

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data-dir',type=Path,required=True);ap.add_argument('--state-summary',type=Path,required=True);ap.add_argument('--out',type=Path,default=Path('gamma_calibration.csv'));args=ap.parse_args()
    st=pd.read_csv(args.state_summary);lookup={(int(r.RecordID),int(r.bin)):(int(r.state),int(r.agebin)) for r in st.itertuples()};rows=[]
    files=sorted((args.data_dir/'set-a').glob('*.txt')) if (args.data_dir/'set-a').exists() else sorted(args.data_dir.glob('*.txt'))
    for p in files:
        if not p.stem.isdigit():continue
        rid=int(p.stem);recs=list(csv.DictReader(open(p)));base={}
        for r in recs:
            if r['Parameter'] in ('Gender','ICUType'):
                try:base[r['Parameter']]=int(float(r['Value']))
                except:pass
        meas=[0]*4
        for r in recs:
            if r['Parameter']!='Creatinine':continue
            try:
                hh,mm=r['Time'].split(':');hour=int(hh)+int(mm)/60;val=float(r['Value'])
            except:continue
            if val>=0 and 0<=hour<48:meas[int(hour//12)]=1
        for b in range(1,4):
            ps,ag=lookup[(rid,b-1)];rows.append({'RecordID':rid,'stage':b,'M':meas[b],'prev_M':meas[b-1],'prev_state':ps,'agebin':ag,'Gender':base.get('Gender',-1),'ICUType':base.get('ICUType',-1)})
    df=pd.DataFrame(rows);y=df.M.to_numpy();all_cols=['stage','prev_M','prev_state','agebin','ICUType','Gender'];cat=['stage','ICUType','Gender'];cv=list(StratifiedGroupKFold(5,shuffle=True,random_state=42).split(df,y,groups=df.RecordID))
    def pred(cols):
        cats=[c for c in cat if c in cols];nums=[c for c in cols if c not in cats];pre=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),cats),('num','passthrough',nums)]);pipe=Pipeline([('pre',pre),('lr',LogisticRegression(max_iter=2000))]);return cross_val_predict(pipe,df[cols],y,cv=cv,method='predict_proba')[:,1]
    pfull=pred(all_cols);out=[]
    for W in ['prev_M','prev_state','agebin','ICUType','Gender']:
        predred=pred([c for c in all_cols if c!=W]);lr=np.abs(np.log(np.clip(pfull,1e-4,1-1e-4)/np.clip(predred,1e-4,1-1e-4)));out.append({'benchmark':W,'Gamma_90':np.quantile(lr,.90),'Gamma_95':np.quantile(lr,.95),'Gamma_99':np.quantile(lr,.99)})
    out=pd.DataFrame(out).sort_values('Gamma_95',ascending=False);out.to_csv(args.out,index=False);print(out.to_string(index=False))
if __name__=='__main__':main()
