"""Independent finite checks for the new confidence recursion."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from state_confidence import box_extreme,bound_pair,confidence_inputs,simulate_counts,OBS
from sign_preserving import signed_flows,contrast_bounds
from experiment_dynamic_grid import dgp,STATES,INITIAL

ROOT=Path(__file__).resolve().parents[1]


def main():
    rng=np.random.default_rng(821643); box_error=single_error=0.
    for _ in range(100):
        p=rng.dirichlet(np.ones(5)); lo=p*rng.uniform(0,1,5); hi=p+(1-p)*rng.uniform(0,1,5)
        v=rng.normal(size=5)
        for maximize in [False,True]:
            sign=-1 if maximize else 1
            lp=linprog(sign*v,A_eq=np.ones((1,5)),b_eq=[1],bounds=list(zip(lo,hi)),method='highs')
            assert lp.success
            box_error=max(box_error,abs(box_extreme(v,lo,hi,maximize)-sign*lp.fun))
    contained=0
    for _ in range(40):
        T,m,A=4,3,2; init=rng.dirichlet(np.ones(m)); tr=rng.dirichlet(np.ones(m),size=(T-1,m,A))
        low=rng.uniform(-1,.4,(T,m,A)); high=low+(1-low)*rng.random((T,m,A))
        p1=rng.integers(0,A,(T,m)); p0=rng.integers(0,A,(T,m))
        inputs=dict(initial=(init,init),transition=(tr,tr),reward=(low,high))
        result=bound_pair(inputs,p1,p0)
        def trans(t,s,a):
            return dict(enumerate(tr[t,s,a])) if t<T-1 else {s:1.}
        ref=contrast_bounds(signed_flows(dict(enumerate(init)),trans,lambda t,s:p1[t,s],lambda t,s:p0[t,s],T),
                            lambda t,s,a:(low[t,s,a],high[t,s,a]),weights=[1/T]*T)
        single_error=max(single_error,abs(result['lower']-ref['lower']),abs(result['upper']-ref['upper']))
        eps=.15
        outer=dict(initial=(np.maximum(0,init-eps),np.minimum(1,init+eps)),
                   transition=(np.maximum(0,tr-eps),np.minimum(1,tr+eps)),reward=(low,high))
        bound=bound_pair(outer,p1,p0)
        for _ in range(20):
            # Sample actual shared kernels in the interval set, then evaluate
            # with the original independent forward-flow implementation.
            mix=rng.uniform(0,.1)
            alternative=(1-mix)*tr+mix*rng.dirichlet(np.ones(m),size=(T-1,m,A))
            def trans2(t,s,a):return dict(enumerate(alternative[t,s,a])) if t<T-1 else {s:1.}
            z=contrast_bounds(signed_flows(dict(enumerate(init)),trans2,lambda t,s:p1[t,s],lambda t,s:p0[t,s],T),
                              lambda t,s,a:(low[t,s,a],high[t,s,a]),weights=[1/T]*T)
            assert bound['lower'] <= z['lower']+1e-10 and bound['upper'] >= z['upper']-1e-10
            contained+=1
        same=bound_pair(outer,p0,p0)
        assert same['lower']==same['upper']==0.
    # Strict statistical rectangularization: both policies share one uncertain
    # transition row after splitting. Every shared model has contrast zero,
    # whereas allowing the two sign branches separate kernels gives [-1,1].
    T,m,A=3,2,2; init=np.array([1.,0.]); tr=np.zeros((2,m,A,m));tr[:,:,:,0]=1.
    tl=tr.copy();tu=tr.copy();tl[1,0,0]=0.;tu[1,0,0]=1.
    reward=np.zeros((T,m,A));reward[2,1,:]=1.
    p0=np.zeros((T,m),int);p1=p0.copy();p1[0,:]=1
    wide=bound_pair(dict(initial=(init,init),transition=(tl,tu),reward=(reward,reward)),p1,p0,weights=np.ones(T))
    assert abs(wide['lower']+1)<1e-12 and abs(wide['upper']-1)<1e-12
    for p in np.linspace(0,1,21):
        candidate=tr.copy();candidate[1,0,0]=[1-p,p]
        exact=bound_pair(dict(initial=(init,init),transition=(candidate,candidate),reward=(reward,reward)),p1,p0)
        assert abs(exact['lower'])<1e-12 and abs(exact['upper'])<1e-12
    # Empty data never manufacture a narrow interval.
    empty=confidence_inputs(np.zeros(4,int),np.zeros((3,4,2,6),int),STATES)
    z=bound_pair(empty,np.ones((3,4),int),np.zeros((3,4),int))
    assert abs(z['lower']+2)<1e-10 and abs(z['upper']-2)<1e-10
    # Exact aggregate transition conservation at every stage.
    joint,_,_=dgp(.8,.8)
    initial,counts=simulate_counts(5000,6,STATES,INITIAL,joint,rng)
    assert initial.sum()==5000 and np.all(counts.sum(axis=(1,2,3))==5000)
    # Distribution check against a separate individual-trajectory simulator.
    # Different random draws need not match exactly; compare their cell counts
    # to the exact cell means and binomial standard deviations at each stage.
    N,T=30000,4
    initial,aggregate=simulate_counts(N,T,STATES,INITIAL,joint,rng)
    states_idx={s:i for i,s in enumerate(STATES)}
    individual=np.zeros_like(aggregate)
    current=rng.choice(4,N,p=[INITIAL.get(s,0.) for s in STATES])
    for t in range(T):
        actions=rng.integers(0,2,N); following=np.zeros(N,int)
        for si,s in enumerate(STATES):
            for a in [0,1]:
                indices=np.flatnonzero((current==si)&(actions==a))
                jj=joint(s,a)
                probs=[sum(p for (y,z,r),p in jj.items() if (z,r,r*y)==o) for o in OBS]
                draws=rng.choice(6,len(indices),p=probs)
                individual[t,si,a]=np.bincount(draws,minlength=6)
                following[indices]=[states_idx[OBS[j][:2]] for j in draws]
        current=following
    occupancy=np.array([INITIAL.get(s,0.) for s in STATES]); max_z=0.
    for t in range(T):
        next_occ=np.zeros(4)
        for si,s in enumerate(STATES):
            for a in [0,1]:
                jj=joint(s,a)
                probs=np.array([sum(p for (y,z,r),p in jj.items() if (z,r,r*y)==o) for o in OBS])
                p=.5*occupancy[si]*probs; sd=np.sqrt(N*p*(1-p))
                mask=sd>0
                for generated in [aggregate,individual]:
                    max_z=max(max_z,float(np.max(np.abs(generated[t,si,a][mask]-N*p[mask])/sd[mask])) if mask.any() else 0.)
                for o,p_o in zip(OBS,p):next_occ[states_idx[o[:2]]]+=p_o
        occupancy=next_occ
    assert max_z<6
    checks=dict(box_simplex_max_error=box_error,singleton_flow_max_error=single_error,
                shared_models_contained=contained,identical_policy_zero=True,empty_cell_safe=True,
                aggregate_and_individual_count_check_max_z=max_z,
                strict_relaxation_example=dict(shared_model_interval=[0,0],outer_interval=[-1,1]),
                interpretation='Numerical verification, not a proof certificate')
    assert box_error<1e-10 and single_error<1e-10
    import os
    output = os.environ.get('MNAR_CHECK_OUTPUT', 'state_confidence_checks.json')
    (ROOT/'results'/output).write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
