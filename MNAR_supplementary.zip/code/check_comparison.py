"""Audit shared-row and same-sample policy-selection diagnostics."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import binomtest
from experiment_comparison import summarize_selection
from state_confidence import bound_pair

ROOT=Path(__file__).resolve().parents[1]


def main():
    row=pd.read_csv(ROOT/'results/comparison_shared_row_raw.csv')
    assert len(row)==800 and row.seed.nunique()==800
    assert row.groupby(['b','row_visits']).size().eq(100).all()
    assert max(row.formula_error.max(),row.lp_error.max())<1e-12
    assert np.allclose(row.outer_width-row.joint_width,2*row.b*(row.row_upper-row.row_lower))
    saved=pd.read_csv(ROOT/'results/comparison_shared_row_mc.csv')
    for r in saved.itertuples():
        g=row[(row.b==r.b)&(row.row_visits==r.row_visits)]
        for name in ['joint_covered','outer_covered','joint_certified','outer_certified']:
            count=int(g[name].sum());ci=binomtest(count,len(g)).proportion_ci(.95,method='exact')
            assert count==getattr(r,name+'_count')
            assert abs(ci.low-getattr(r,name+'_mc95_lower'))<1e-12
            assert abs(ci.high-getattr(r,name+'_mc95_upper'))<1e-12
    report={'shared_row_records':len(row),'shared_row_formula_max_error':float(row.formula_error.max())}
    new_seeds=set(row.seed)
    for name,nrows in [('selection',300),('selection_followup',200)]:
        raw=pd.read_csv(ROOT/f'results/comparison_{name}_raw.csv')
        assert len(raw)==nrows and raw.seed.nunique()==nrows
        assert new_seeds.isdisjoint(raw.seed);new_seeds.update(raw.seed)
        expected=summarize_selection(raw)
        saved=pd.read_csv(ROOT/f'results/comparison_{name}_summary.csv')
        pd.testing.assert_frame_equal(saved,expected,check_exact=False,atol=1e-12,rtol=1e-12)
        assert (raw.lower<=raw.population_lower+1e-9).all()
        assert (raw.upper>=raw.population_upper-1e-9).all()
        assert (raw.lower>=raw.separate_lower-1e-9).all()
        assert (raw.upper<=raw.separate_upper+1e-9).all()
        assert raw.lp_fallbacks.eq(0).all()
        if name=='selection_followup':
            assert (raw.population_lower<=1e-9).all() and (raw.population_upper>=-1e-9).all()
        report[name]={'datasets':len(raw),'selected_pairs_by_n':{str(n):int(len(g[['first_policy','second_policy']].drop_duplicates())) for n,g in raw.groupby('n')},'lp_fallbacks':0}
    historical=set()
    for p in (ROOT/'results').glob('*.csv'):
        if p.name.startswith('comparison_'):continue
        if 'seed' in pd.read_csv(p,nrows=0).columns:
            historical.update(pd.read_csv(p,usecols=['seed']).seed.dropna().astype('int64'))
    assert not new_seeds & historical
    report['new_datasets']=len(new_seeds);report['historical_seed_overlap']=0

    # Exact local ranges do not imply nonnegative dynamics excess off row coverage.
    l=np.zeros((1,2,2));u=l.copy();u[0,1,:]=1
    empty=np.zeros((0,2,2,2));first=np.zeros((1,2),int);second=np.ones((1,2),int)
    true=np.array([.5,.5]);wrong=np.array([.75,.25])
    inp=dict(initial=(true,true),transition=(empty,empty),reward=(l,u))
    oracle=bound_pair(inp,first,second)
    outer=bound_pair(dict(inp,initial=(wrong,wrong)),first,second)
    dynamics=(outer['upper']-outer['lower'])-(oracle['upper']-oracle['lower'])
    assert abs(dynamics+.5)<1e-12
    report['local_coverage_without_initial_coverage_dynamics_excess']=float(dynamics)
    # The manuscript deliberately makes no fixed-alpha consistency claim.
    report['scope']='Numerical and artifact checks; not independent human proof verification.'
    (ROOT/'results/comparison_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
