"""Checks of input stability and clinical aggregates."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
from state_confidence import bound_pair, simulate_counts, box_extreme
from experiment_dynamic_grid import dgp, STATES, INITIAL
from experiment_local_confidence import OBS
from run_physionet_semisynthetic import lp_from_joint, load_physionet, build_empirical_mdp

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path)
    parser.add_argument('--output',default='overlap_checks.json')
    args=parser.parse_args()
    report={}
    # A population outcome absent among complete cases is a structural zero
    # under observation positivity, not an undefined q or a free reward mass.
    joint={(y,z,r): (0. if y==-1 else (.4 if z==1 else .6)*.5)
           for y in [-1,1] for z in [-1,1] for r in [0,1]}
    zero=[lp_from_joint(joint,g) for g in [0.,.1,1.]]
    assert np.allclose(zero,1.)
    report['zero_outcome_stratum_bounds']=zero
    rng=np.random.default_rng(202609245000000)
    worst_ratio=0.
    for case in range(100):
        T,m,A=4,3,2
        init=rng.dirichlet(np.ones(m))
        tr=rng.dirichlet(np.ones(m),size=(T-1,m,A))
        low=rng.uniform(-1,.3,size=(T,m,A))
        high=low+rng.random((T,m,A))*(1-low)
        first=rng.integers(A,size=(T,m));second=rng.integers(A,size=(T,m))
        weights=rng.random(T);weights/=weights.sum()
        exact=dict(initial=(init,init),transition=(tr,tr),reward=(low,high))
        pop=bound_pair(exact,first,second,weights)
        r=.005 if case%2 else .025
        il=np.maximum(0,init-r);iu=np.minimum(1,init+r)
        tl=np.maximum(0,tr-r);tu=np.minimum(1,tr+r)
        lo=np.maximum(-1,low-r);hi=np.minimum(1,high+r)
        sample=dict(initial=(il,iu),transition=(tl,tu),reward=(lo,hi))
        out=bound_pair(sample,first,second,weights)
        # Exact L1 radii via ||v||_1 = max over the 2^m sign vectors.
        signs=np.array(np.meshgrid(*[[-1.,1.]]*m)).T.reshape(-1,m)
        radius=lambda p,l,u: max(box_extreme(v,l,u,True)-p@v for v in signs)
        e0=radius(init,il,iu)
        eps=np.array([max(radius(tr[t,s,a],tl[t,s,a],tu[t,s,a])
                            for s in range(m) for a in range(A)) for t in range(T-1)])
        delta=np.maximum(abs(lo-low),abs(hi-high)).max(axis=(1,2))
        tail=np.array([weights[k+1:].sum() for k in range(T-1)])
        bound=2*weights@delta+2*tail@eps+2*weights.sum()*e0
        actual=max(abs(out['lower']-pop['lower']),abs(out['upper']-pop['upper']))
        assert actual<=bound+1e-10
        worst_ratio=max(worst_ratio,float(actual/bound))
    report['perturbation_bound_checks']=dict(models=100,max_error_over_bound=worst_ratio)
    joint,_,_=dgp(.8,.8)
    max_z=0.
    for behavior in [.1,.9]:
        n,T=50000,4
        initial,counts=simulate_counts(n,T,STATES,INITIAL,joint,rng,behavior_probability=behavior)
        occupancy=np.array([INITIAL.get(s,0.) for s in STATES])
        for t in range(T):
            following=np.zeros(4)
            for si,s in enumerate(STATES):
                for a,pa in [(0,1-behavior),(1,behavior)]:
                    jj=joint(s,a)
                    op=np.array([sum(v for (y,z,r),v in jj.items() if (z,r,r*y)==o) for o in OBS])
                    prob=occupancy[si]*pa*op
                    sd=np.sqrt(n*prob*(1-prob));mask=sd>0
                    if mask.any():max_z=max(max_z,float(np.max(abs(counts[t,si,a][mask]-n*prob[mask])/sd[mask])))
                    for o,p in zip(OBS,prob):following[STATES.index(o[:2])]+=p
            occupancy=following
    assert max_z<6
    report['biased_behavior_count_check_max_z']=max_z
    if args.data_dir:
        start=time.perf_counter()
        df=load_physionet(args.data_dir)
        initial,trans=build_empirical_mdp(df)
        ir=pd.read_csv(ROOT/'results/physionet_initial_distribution.csv')
        tr=pd.read_csv(ROOT/'results/physionet_empirical_transitions.csv')
        ie=max(abs(initial[r.state,r.agebin]-r.prob) for r in ir.itertuples())
        te=max(abs(trans[r.stage,r.state,r.agebin][r.next_state]-r.prob) for r in tr.itertuples())
        assert df.RecordID.nunique()==4000 and len(df)==16000 and max(ie,te)<1e-12
        report['clinical_aggregate_recheck']=dict(patients=4000,patient_bins=16000,
            initial_max_error=ie,transition_max_error=te,seconds=time.perf_counter()-start)
    report['limitation']='Numerical checks support implementation; they are not independent human proof verification.'
    (ROOT/'results'/args.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
