"""Focused validation of shared sorting, partition LPs and retained witnesses."""
import json
import time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from scipy.optimize import linprog
import state_confidence as sc
from experiment_consistency_local import partition_bounds
from experiment_dynamic_grid import dgp
from experiment_local_confidence import ATOMS, OBS
import experiment_policy_robustness as old
import run_physionet_semisynthetic as phys

ROOT=Path(__file__).resolve().parents[1]


def main():
    rng=np.random.default_rng(202609243999999)
    max_error=0.;sort_counts=[];timings=[]
    original=sc.box_extreme
    def resort(v,l,u,maximize=False,*,order=None):
        return original(v,l,u,maximize)
    def lp(v,l,u,maximize=False,*,order=None):
        sign=-1 if maximize else 1
        fit=linprog(sign*np.asarray(v),A_eq=np.ones((1,len(v))),b_eq=[1],
                    bounds=list(zip(l,u)),method='highs')
        assert fit.success
        return sign*fit.fun
    for m in [4,16,64,128]:
        T=6
        initial=rng.dirichlet(np.ones(m));tr=rng.dirichlet(np.ones(m),size=(T-1,m,2))
        reward_lo=rng.uniform(-1,.4,(T,m,2));reward_hi=reward_lo+rng.random((T,m,2))*(1-reward_lo)
        inp=dict(initial=(initial*.8,np.minimum(1,initial+.2)),
            transition=(tr*.8,np.minimum(1,tr+.2)),reward=(reward_lo,reward_hi))
        first=rng.integers(2,size=(T,m));second=rng.integers(2,size=(T,m))
        # Force common and split cells, and retain arbitrary nonuniform rows.
        second[:,::2]=first[:,::2]
        with patch.object(sc.np,'argsort',wraps=np.argsort) as sort:
            current=sc.bound_pair(inp,first,second)
            sort_counts.append(dict(states=m,calls=sort.call_count))
            assert sort.call_count==6*T
        for name,fn in [('shared_sort',None),('per_row_sort',resort)]:
            times=[]
            for _ in range(3):
                tic=time.perf_counter()
                if fn is None:result=sc.bound_pair(inp,first,second)
                else:
                    with patch.object(sc,'box_extreme',fn):result=sc.bound_pair(inp,first,second)
                times.append(time.perf_counter()-tic)
                max_error=max(max_error,max(abs(result[k]-current[k]) for k in current))
            timings.append(dict(states=m,horizon=T,method=name,median_seconds=float(np.median(times)),
                                min_seconds=min(times),max_seconds=max(times),repetitions=3))
        if m==4:
            with patch.object(sc,'box_extreme',lp):reference=sc.bound_pair(inp,first,second)
            max_error=max(max_error,max(abs(reference[k]-current[k]) for k in current))
    assert max_error<1e-10
    pd.DataFrame(timings).to_csv(ROOT/'results/consistency_scaling.csv',index=False)
    singleton_error=0.
    for q in [.6,.8,.95]:
        joint,_,ends=dgp(q,.8);law=joint((-1,1),0)
        p=np.array([sum(v for (y,z,r),v in law.items() if (z,r,r*y)==o) for o in OBS])
        qs=np.array([law[y,1,1]/sum(law[y,z,1] for z in [-1,1]) for y in [-1,1]])
        l,u,stat=partition_bounds(p,p,qs,qs,.1)
        expected=ends(0,(-1,1),0)
        singleton_error=max(singleton_error,abs(l-expected[0]),abs(u-expected[1]))
        assert not stat['numerical_failure'] and not stat['empty_union']
        previous=(-1.,1.)
        for pieces in [1,2,4]:
            l,u,stat=partition_bounds(np.maximum(0,p-.04),np.minimum(1,p+.04),
                                      np.maximum(0,qs-.08),np.minimum(1,qs+.08),.1,pieces)
            assert l>=previous[0]-1e-9 and u<=previous[1]+1e-9
            assert l<=expected[0]+1e-9 and u>=expected[1]-1e-9
            previous=(l,u)
    assert singleton_error<1e-9
    raw=pd.read_csv(ROOT/'results/consistency_local_raw.csv')
    assert len(raw)==180 and raw.seed.nunique()==180
    assert (raw.partition_lower>=raw.base_lower-1e-9).all()
    assert (raw.partition_upper<=raw.base_upper+1e-9).all()
    assert raw.numerical_failure.eq(0).all() and raw.empty_union.eq(0).all()
    assert np.allclose(raw.base_width-raw.population_width,
                       raw.removable_relaxation+raw.remaining_excess)
    # Reevaluate supplied witness kernels rather than reconstructing new ones.
    records=pd.read_csv(ROOT/'results/adverse_completion_kernels.csv')
    kernels={}
    for r in records.itertuples():
        h=tuple(json.loads(r.history));key=(r.stage,h,r.action)
        kernels.setdefault(key,{})[r.y,r.z,r.r]=r.probability
    initial,trans=old.read_mdp(ROOT);values={};max_obs=0.
    for (t,h,a),kernel in kernels.items():
        law=phys.local_joint(t,old.compressed(h),a,0.,trans)
        for o in OBS:
            coarsen=lambda j:sum(v for (y,z,r),v in j.items() if (z,r,r*y)==o)
            max_obs=max(max_obs,abs(coarsen(kernel)-coarsen(law)))
    for policy in ['missingness','state']:
        masses=dict(initial);value=0.
        for t in range(phys.T):
            following={}
            for h,p in masses.items():
                a=old.action(h,policy);law=kernels[t,h,a]
                value+=p*sum(y*v for (y,z,r),v in law.items())
                for (y,z,r),v in law.items():
                    nxt=h+(a,z,r,r*y);following[nxt]=following.get(nxt,0.)+p*v
            masses=following
        values[policy]=value
    delta=values['missingness']-values['state']
    assert abs(delta+0.012674303742829296)<1e-10 and max_obs<1e-10
    report=dict(sort_calls=sort_counts,recursion_reference_max_error=max_error,
        partition_singleton_max_error=singleton_error,partition_nesting_checked=True,
        local_datasets=180,adverse_completion_values=values,adverse_completion_contrast=delta,
        adverse_completion_observed_kernel_max_error=max_obs,
        note='AI-assisted numerical checks, not independent human proof verification.')
    (ROOT/'results/consistency_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
