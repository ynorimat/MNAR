"""Rebuild manuscript Table 6 from the saved paired-comparison summaries."""
import argparse
import csv
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,default=ROOT/'results')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    with (args.results/'point_baselines_summary.csv').open(newline='') as f:
        rows=list(csv.DictReader(f))
    assert [(float(r['q']),int(r['n'])) for r in rows]==[(q,n) for q in [.6,.8,.95] for n in [4000,64000]]
    assert all(int(r['reps'])==100 for r in rows)
    out=r'''\begin{tabular}{@{}rrrrrr@{}}
\toprule
$q$ & $n$/1000 & CC bias/RMSE & MAR-IPW bias/RMSE & Outer width & Cert. (\%)\\\midrule
'''
    for r in rows:
        out+=f"{float(r['q']):.2f} & {int(r['n'])//1000} & ${float(r['cc_bias']):.3f}/{float(r['cc_rmse']):.3f}$ & ${float(r['mar_ipw_bias']):.3f}/{float(r['mar_ipw_rmse']):.3f}$ & {float(r['mean_width']):.3f} & {100*float(r['certification']):.0f}"+r'\\'+'\n'
    out+=r'\bottomrule'+'\n'+r'\end{tabular}'+'\n'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(out,encoding='utf-8')


if __name__=='__main__':main()
