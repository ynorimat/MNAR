#!/usr/bin/env python3
"""Full MNAR DGP with action-dependent transitions and controlled policy splitting."""
import itertools
import json
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.special import expit,logit
from experiment_signed_aggregation import single_policy_interval
from sign_preserving import signed_flows,contrast_bounds
from run_physionet_semisynthetic import lp_from_joint

ROOT=Path(__file__).resolve().parents[1]
STATES=list(itertools.product([-1,1],[0,1]))
INITIAL={(-1,1):.5,(1,1):.5}


def dgp(strength,intercept,kappa=.04):
    @lru_cache(None)
    def joint(state,action):
        s,previous_r=state;out={};py=expit(-.25+.5*s+.9*action)
        for y in [-1,1]:
            pz=expit(logit(strength)*y+.35*s-.6*action)
            for z in [-1,1]:
                pr=expit(intercept+1.1*y+.2*action+.1*previous_r+kappa*z)
                for r in [0,1]:
                    out[y,z,r]=(py if y==1 else 1-py)*(pz if z==1 else 1-pz)*(pr if r else 1-pr)
        return out
    def transition(t,state,action):
        j=joint(state,action)
        return {(z,r):sum(j[y,z,r] for y in [-1,1]) for z,r in STATES}
    @lru_cache(None)
    def endpoints(t,state,action):
        return lp_from_joint(joint(state,action),.1)
    return joint,transition,endpoints


def enumerated_bounds(joint,endpoints,first,second,horizon):
    """Retain actions and complete observed tuples (Z,R,RY), not just S."""
    masses=[{(s,):p for s,p in INITIAL.items()} for _ in range(2)]
    lo=hi=0.
    state=lambda h:h[0] if len(h)==1 else h[-1][:2]
    for t in range(horizon):
        coefficients=defaultdict(float)
        for sign,policy,m in zip([1,-1],[first,second],masses):
            for h,p in m.items():coefficients[h,policy(t,state(h))]+=sign*p
        for (h,a),c in coefficients.items():
            l,u=endpoints(t,state(h),a)
            lo+=c*(l if c>=0 else u)/horizon
            hi+=c*(u if c>=0 else l)/horizon
        if t==horizon-1:break
        nxt=[]
        for policy,m in zip([first,second],masses):
            nm=defaultdict(float)
            for h,p in m.items():
                s=state(h);a=policy(t,s)
                for (y,z,r),v in joint(s,a).items():nm[h+(a,(z,r,r*y))]+=p*v
            nxt.append(dict(nm))
        masses=nxt
    return lo,hi


def common_gain(initial,transition,first,second,endpoints,horizon):
    common=dict(initial);gain=0.
    for t in range(horizon):
        nxt=defaultdict(float)
        for state,p in common.items():
            a,b=first(t,state),second(t,state)
            if a!=b:continue
            l,u=endpoints(t,state,a);gain+=p*(u-l)/horizon
            for ns,v in transition(t,state,a).items():nxt[ns]+=p*v
        common=dict(nxt)
    return gain


def main():
    rows=[];max_error=0.;checked=0
    for q,b,T in itertools.product([.6,.8,.95],[-1.8,-.4,.8],[3,6,12]):
        joint,tr,endpoints=dgp(q,b)
        gamma_actual=0.
        for state,a in itertools.product(STATES,[0,1]):
            jj=joint(state,a)
            for y,z in itertools.product([-1,1],repeat=2):
                pz=sum(jj[y,z,r] for r in [0,1])/sum(v for (yy,zz,r),v in jj.items() if yy==y)
                qz=jj[y,z,1]/sum(jj[y,zz,1] for zz in [-1,1])
                gamma_actual=max(gamma_actual,abs(np.log(pz/qz)))
        assert gamma_actual<.1
        action_tv=max(.5*sum(abs(tr(0,s,1)[ns]-tr(0,s,0)[ns]) for ns in STATES) for s in STATES)
        masses=dict(INITIAL);missing=0.
        for t in range(T):
            nxt=defaultdict(float)
            for state,p in masses.items():
                for a in [0,1]:
                    for ns,v in tr(t,state,a).items():
                        nxt[ns]+=.5*p*v
                        if ns[1]==0:missing+=.5*p*v/T
            masses=dict(nxt)
        for category,split in [('initial',0),('middle',T//2),('last',T-1)]:
            p1=lambda t,s:int(t==split)
            p2=lambda t,s:0
            flows=signed_flows(INITIAL,tr,p1,p2,T)
            value=contrast_bounds(flows,endpoints,weights=[1/T]*T)
            first=single_policy_interval(INITIAL,tr,p1,endpoints,T)
            second=single_policy_interval(INITIAL,tr,p2,endpoints,T)
            sl=(first[0]-second[1])/T;su=(first[1]-second[0])/T
            gain=common_gain(INITIAL,tr,p1,p2,endpoints,T)
            assert abs(value['lower']-sl-gain)<1e-10
            assert abs(su-value['upper']-gain)<1e-10
            truth=contrast_bounds(flows,lambda t,s,a:(sum(y*v for (y,z,r),v in joint(s,a).items()),)*2,
                                  weights=[1/T]*T)['lower']
            assert value['lower']-1e-10<=truth<=value['upper']+1e-10
            if split==0:assert abs(gain)<1e-12
            if T==3:
                ref=enumerated_bounds(joint,endpoints,p1,p2,T);checked+=1
                max_error=max(max_error,abs(ref[0]-value['lower']),abs(ref[1]-value['upper']))
            rows.append(dict(proxy_strength=q,observation_intercept=b,horizon=T,
                             split_category=category,first_disagreement=split,
                             Gamma=.1,actual_violation=gamma_actual,behavior_missing_rate=missing,
                             action_transition_tv=action_tv,true_contrast=truth,**value,
                             separate_lower=sl,separate_upper=su,common_gain=gain,
                             width_reduction=2*gain/(su-sl)))
    data=pd.DataFrame(rows);assert len(data)==81 and max_error<1e-10
    data['sharp_width']=data.upper-data.lower
    data.to_csv(ROOT/'results/dynamic_grid.csv',index=False)
    data.groupby(['proxy_strength','observation_intercept','split_category']).agg(
        mean_missing=('behavior_missing_rate','mean'),mean_width_reduction=('width_reduction','mean'),
        mean_pooling_gap=('pooling_gap','mean'),mean_sharp_width=('sharp_width','mean')).to_csv(ROOT/'results/dynamic_grid_summary.csv')
    audit=dict(settings=len(data),full_observed_history_enumerations=checked,max_error=max_error,
               min_action_transition_tv=float(data.action_transition_tv.min()),
               max_actual_violation=float(data.actual_violation.max()))
    (ROOT/'results/dynamic_grid_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    plt.rcParams.update({'font.size':8,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(6.8,2.2))
    for ax,column,title in zip(axes,['width_reduction','pooling_gap'],
                              ['Valid cancellation gain','Invalid mean-pooling gain']):
        for T,color in zip([3,6,12],['#286887','#9a5525','#6b5598']):
            groups=[data[(data.horizon==T)&(data.split_category==c)][column] for c in ['initial','middle','last']]
            x=np.arange(3);means=[g.mean() for g in groups]
            ax.plot(x,means,'o-',color=color,lw=1,label=f'T={T}')
            ax.fill_between(x,[g.min() for g in groups],[g.max() for g in groups],color=color,alpha=.08)
        ax.set_xticks([0,1,2],['Initial','Middle','Last']);ax.set_xlabel('First policy disagreement')
        ax.set_title(title);ax.grid(alpha=.15)
    axes[0].set_ylabel('Relative reduction in interval width');axes[1].set_ylabel('Increase in lower endpoint')
    axes[0].legend(fontsize=7,frameon=False);fig.tight_layout(pad=.5)
    (ROOT/'figures').mkdir(parents=True, exist_ok=True)
    fig.savefig(ROOT/'figures/fig_dynamic_grid.pdf');fig.savefig(ROOT/'figures/fig_dynamic_grid.png',dpi=180)
    print(json.dumps(audit,indent=2));print(data.groupby('split_category')[['width_reduction','pooling_gap']].agg(['min','mean','max']).to_string())


if __name__=='__main__':main()
