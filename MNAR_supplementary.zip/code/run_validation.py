"""Run focused checks in a temporary copy, preserving all supplied results.

From supplementary/: python code/run_validation.py --output validation_v2
This runs implementation checks, not the full Monte Carlo experiments or
clinical preprocessing. Dependencies are listed in requirements.txt.
"""
import argparse
from contextlib import contextmanager
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
CHECKS = (
    'check_state_sufficiency.py',
    'audit_theory.py',
    'check_state_confidence.py',
    'check_comparison.py',
    'check_overlap.py',
    'check_consistency.py',
    # Summarize original timings before check_refinement remeasures them.
    'report_refinement.py',
    'check_refinement.py',
)


def hashes(folder):
    return {p.relative_to(folder).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob('*')) if p.is_file()}


@contextmanager
def working_copy(output):
    # Use a normal directory so inherited Windows workspace permissions apply.
    scratch = output / ('working-' + uuid.uuid4().hex)
    scratch.mkdir()
    try:
        yield scratch
    finally:
        resolved = scratch.resolve()
        if resolved.parent != output.resolve() or not resolved.name.startswith('working-'):
            raise RuntimeError('Refusing to remove a working directory outside the output folder.')
        shutil.rmtree(resolved)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('validation_v2'))
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or output.is_relative_to(ROOT / 'code') or output.is_relative_to(ROOT / 'results') or output.is_relative_to(ROOT / 'protocols'):
        parser.error('Choose an output directory outside code/, results/ and protocols/.')
    if output.exists() and any(output.iterdir()):
        parser.error('Output directory must be empty; choose a new name to retain previous checks.')
    output.mkdir(parents=True, exist_ok=True)
    original = hashes(ROOT / 'results')
    environment = dict(os.environ)
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        environment[key] = '1'
    # Do not inherit an output override that could point outside the copy.
    environment.pop('MNAR_CHECK_OUTPUT', None)
    report = {
        'scope': 'Focused numerical checks; no full Monte Carlo rerun or clinical preprocessing.',
        'python': platform.python_version(),
        'platform': platform.system() + ' ' + platform.machine(),
        'dependencies': {name: importlib.metadata.version(name) for name in
                         ('numpy', 'pandas', 'scipy', 'scikit-learn', 'matplotlib')},
        'checks': [],
    }
    with working_copy(output) as copied:
        for name in ('code', 'results'):
            shutil.copytree(ROOT / name, copied / name, ignore=shutil.ignore_patterns('__pycache__'))
        for script in CHECKS:
            before = hashes(copied / 'results')
            start = time.perf_counter()
            timed_out = False
            try:
                result = subprocess.run([sys.executable, '-X', 'utf8', 'code/' + script],
                                        cwd=copied, env=environment, capture_output=True,
                                        text=True, encoding='utf8', errors='replace', timeout=600)
                status, log = result.returncode, result.stdout + result.stderr
            except subprocess.TimeoutExpired as exc:
                status, timed_out = -1, True
                def decode(value):
                    return value.decode('utf8', errors='replace') if isinstance(value, bytes) else (value or '')
                log = decode(exc.stdout) + decode(exc.stderr) + '\nTimed out after 600 seconds.\n'
            target = output / Path(script).stem
            target.mkdir()
            # Temporary paths have no scientific meaning; omit them from logs.
            (target / 'run.log').write_text(log.replace(str(copied), '<working-copy>'), encoding='utf8')
            after = hashes(copied / 'results')
            changed = [name for name, digest in after.items() if before.get(name) != digest]
            for name in changed:
                destination = target / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(copied / 'results' / name, destination)
            entry = dict(script=script, passed=status == 0, returncode=status,
                         timed_out=timed_out, seconds=time.perf_counter()-start,
                         changed_result_files=changed)
            report['checks'].append(entry)
            print(f"{script}: {'PASS' if status == 0 else 'FAIL'} ({entry['seconds']:.1f}s)", flush=True)
    report['supplied_results_unchanged'] = hashes(ROOT / 'results') == original
    report['all_passed'] = all(item['passed'] for item in report['checks']) and report['supplied_results_unchanged']
    (output / 'validation_summary.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf8')
    (output / 'supplied_results_sha256.json').write_text(json.dumps(original, indent=2)+'\n', encoding='utf8')
    return 0 if report['all_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
