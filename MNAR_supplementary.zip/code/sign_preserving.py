"""Exact shared-law contrasts for two deterministic finite-state policies.

The observed law and the local ambiguity sets may depend only on a finite
state. Unknown reward completions remain free across full histories. Keep
common, first-policy-only and second-policy-only path masses separate.
"""
from collections import defaultdict


def iter_signed_flows(initial, transition, policy1, policy2, horizon):
    """Yield positive/negative occupancy masses using O(m) working memory.

    transition(t, state, action) returns {next_state: probability}.
    Policies are deterministic and may be time dependent. State must contain
    their required memory. Returned negative masses are NONNEGATIVE magnitudes.
    """
    common, first, second = dict(initial), {}, {}
    for t in range(horizon):
        positive, negative = defaultdict(float), defaultdict(float)
        common_next, first_next, second_next = (defaultdict(float) for _ in range(3))
        for state, mass in first.items():
            positive[state, policy1(t, state)] += mass
        for state, mass in second.items():
            negative[state, policy2(t, state)] += mass
        for state, mass in common.items():
            a, b = policy1(t, state), policy2(t, state)
            if a == b:
                for nxt, prob in transition(t, state, a).items():
                    common_next[nxt] += mass * prob
            else:
                positive[state, a] += mass
                negative[state, b] += mass
        for occupancy, dest in [(positive, first_next), (negative, second_next)]:
            for (state, action), mass in occupancy.items():
                for nxt, prob in transition(t, state, action).items():
                    dest[nxt] += mass * prob
        common_total = sum(common_next.values())
        assert abs(common_total + sum(first_next.values()) - 1.0) < 1e-10
        assert abs(common_total + sum(second_next.values()) - 1.0) < 1e-10
        yield dict(positive), dict(negative)
        common, first, second = dict(common_next), dict(first_next), dict(second_next)


def signed_flows(initial, transition, policy1, policy2, horizon):
    """Materialize O(Km) output for diagnostics or reuse at multiple radii.

    Use iter_signed_flows directly with contrast_bounds for O(m) working space.
    """
    return list(iter_signed_flows(initial, transition, policy1, policy2, horizon))


def contrast_bounds(flows, endpoints, weights=None):
    """endpoints(t, state, action) -> (lower, upper)."""
    lower = upper = pooled_lower = pooled_upper = gap = 0.0
    for t, (positive, negative) in enumerate(flows):
        for state, action in positive.keys() | negative.keys():
            weight = 1.0 if weights is None else weights[t]
            if weight < 0:
                raise ValueError('Reward weights must be nonnegative.')
            p = weight * positive.get((state, action), 0.0)
            n = weight * negative.get((state, action), 0.0)
            lo, hi = endpoints(t, state, action)
            lower += p * lo - n * hi
            upper += p * hi - n * lo
            c = p - n
            pooled_lower += c * (lo if c >= 0 else hi)
            pooled_upper += c * (hi if c >= 0 else lo)
            gap += (hi - lo) * min(p, n)
    assert abs(pooled_lower - lower - gap) < 1e-9
    assert abs(upper - pooled_upper - gap) < 1e-9
    return dict(lower=lower, upper=upper, pooled_lower=pooled_lower,
                pooled_upper=pooled_upper, pooling_gap=gap)
