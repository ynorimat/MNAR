#!/usr/bin/env python3
"""Observed-data plug-in endpoints and a known-randomization outer interval.

All estimation receives only counts of COARSENED trajectories. Full latent
atoms are optimization variables, never available to the estimator. Exact
Clopper-Pearson intervals and Bonferroni produce a conservative outer region.
"""
import argparse
import itertools
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.stats import beta

import experiment_factorized_trajectory_lp as seq

ROOT = Path(__file__).resolve().parents[1]


def cp_intervals(successes, totals, error):
    x, n = np.asarray(successes), np.asarray(totals)
    lo, hi = np.zeros(x.shape), np.ones(x.shape)
    mask = x > 0
    lo[mask] = beta.ppf(error / 2, x[mask], n[mask] - x[mask] + 1)
    mask = x < n
    hi[mask] = beta.ppf(1 - error / 2, x[mask] + 1, n[mask] - x[mask])
    return lo, hi


class Model:
    def __init__(self, kappa=.1, gamma=.2, truth_law=None):
        self.gamma = gamma
        self.truth_law = seq.atoms(kappa) if truth_law is None else truth_law
        self.atoms = sorted(self.truth_law)
        self.observed = sorted({seq.obs(a) for a in self.atoms})
        self.coarsening = np.array([[seq.obs(a) == o for a in self.atoms]
                                    for o in self.observed], dtype=float)
        self.observed_probability = self.coarsening @ np.array(
            [self.truth_law[a] for a in self.atoms])
        n = len(self.atoms)
        equalities = [np.ones(n), np.array([float(a[0] == 1) - .5 for a in self.atoms])]
        rhs = [1., 0.]
        for prefix in sorted({a[:4] for a in self.atoms}):
            h = seq.h1(*prefix)
            equalities.append(np.array([
                (float(a[4] == 1) - seq.pi1(1, h)) if a[:4] == prefix else 0.
                for a in self.atoms]))
            rhs.append(0.)
        self.eq, self.eq_rhs = np.array(equalities), np.array(rhs)
        self.objective = np.array([
            a[5] * (a[0] == 1) / seq.pi0(a[0]) *
            ((a[4] == seq.d1(seq.h1(*a[:4]))) -
             (a[4] == int(a[2] == 1))) / seq.pi1(a[4], seq.h1(*a[:4]))
            for a in self.atoms])
        # Per-stratum proxy conditionals: one binomial interval per reward,
        # since Z=-1 and Z=+1 sum to one.
        strata = [(0, (a,)) for a in seq.B]
        histories = sorted({o[:4] for o in self.observed})
        strata += [(1, h + (a,)) for h in histories for a in seq.B]
        self.clock_rows = []
        self.q_num, self.q_den = [], []
        for stage, key in strata:
            def full_match(atom):
                return ((atom[0],) == key if stage == 0 else
                        seq.h1(*atom[:4]) + (atom[4],) == key)
            def observed_match(o):
                return ((o[0],) == key if stage == 0 else o[:5] == key)
            yi, zi, ri = (1, 2, 3) if stage == 0 else (5, 6, 7)
            ozi, ori, oyi = (1, 2, 3) if stage == 0 else (5, 6, 7)
            for y in seq.V:
                xminus = np.array([float(full_match(a) and a[yi] == y and a[zi] == -1)
                                   for a in self.atoms])
                xplus = np.array([float(full_match(a) and a[yi] == y and a[zi] == 1)
                                  for a in self.atoms])
                self.clock_rows.append((xminus, xplus))
                self.q_num.append([float(observed_match(o) and o[ori] == 1 and
                                         o[oyi] == y and o[ozi] == 1)
                                   for o in self.observed])
                self.q_den.append([float(observed_match(o) and o[ori] == 1 and o[oyi] == y)
                                   for o in self.observed])
        self.q_num, self.q_den = np.array(self.q_num), np.array(self.q_den)
        self.interval_count = len(self.observed) + len(self.clock_rows)

    def clock_matrix(self, qlo, qhi):
        rows = []
        for i, (minus, plus) in enumerate(self.clock_rows):
            total = minus + plus
            for cell, lo, hi in [(plus, qlo[i], qhi[i]),
                                 (minus, 1-qhi[i], 1-qlo[i])]:
                rows.append(np.exp(-self.gamma) * lo * total - cell)
                rows.append(cell - np.exp(self.gamma) * hi * total)
        return np.array(rows)

    def solve(self, observed_lo, observed_hi, qlo, qhi):
        clocks = self.clock_matrix(qlo, qhi)
        aub = np.vstack([self.coarsening, -self.coarsening, clocks])
        bub = np.concatenate([observed_hi, -observed_lo, np.zeros(len(clocks))])
        endpoints = []
        for sign in [1, -1]:
            result = linprog(sign*self.objective, A_ub=aub, b_ub=bub,
                             A_eq=self.eq, b_eq=self.eq_rhs, bounds=(0, None),
                             method='highs', options={'primal_feasibility_tolerance':1e-8,
                                                      'dual_feasibility_tolerance':1e-8})
            if not result.success:
                return np.nan, np.nan, result.status
            endpoints.append(sign * result.fun)
        return *endpoints, 0

    def population(self):
        q = self.q_num @ self.observed_probability / (self.q_den @ self.observed_probability)
        return self.solve(self.observed_probability, self.observed_probability, q, q)

    def confidence(self, counts, alpha=.05):
        error = alpha / self.interval_count
        plo, phi = cp_intervals(counts, np.full(len(counts), counts.sum()), error)
        qlo, qhi = cp_intervals(self.q_num @ counts, self.q_den @ counts, error)
        return self.solve(plo, phi, qlo, qhi)

    def plugin(self, counts):
        # First actions agree. Only (A0=1,Z1=-1,R1=0) has different next actions.
        h = (1, -1, 0, 0)
        first_count = sum(c for o, c in zip(self.observed, counts) if o[0] == 1)
        h_count = sum(c for o, c in zip(self.observed, counts) if o[:4] == h)
        if first_count == 0 or h_count == 0:
            return np.nan, np.nan, 1
        bounds = {}
        for action in seq.B:
            selected = [(o, c) for o, c in zip(self.observed, counts) if o[:5] == h+(action,)]
            total = sum(c for o, c in selected)
            if total == 0:
                return np.nan, np.nan, 1
            mu = {z: sum(c for o, c in selected if o[5] == z)/total for z in seq.V}
            s = {(y,z): sum(c for o,c in selected if o[5]==z and o[6]==1 and o[7]==y)/total
                 for y in seq.V for z in seq.V}
            if any(sum(s[y,z] for z in seq.V) == 0 for y in seq.V):
                return np.nan, np.nan, 2
            try:
                lo, hi = seq.local(mu, s, self.gamma)
                if lo is None or hi is None:
                    return np.nan, np.nan, 3
                bounds[action] = lo, hi
            except (TypeError, ValueError):
                return np.nan, np.nan, 3
        mass = h_count/first_count
        return mass*(bounds[1][0]-bounds[0][1]), mass*(bounds[1][1]-bounds[0][0]), 0


def summarize(raw, population):
    rows=[]
    for n,g in raw.groupby('n',sort=True):
        good=g[g.plugin_status==0]
        ok=(g.outer_status==0)&(g.outer_lower<=population[0]+1e-7)&(g.outer_upper>=population[1]-1e-7)
        width=g.outer_upper-g.outer_lower
        coverage_lo,coverage_hi=cp_intervals(np.array([ok.sum()]),np.array([len(g)]),.05)
        rows.append(dict(n=int(n),replications=len(g),plugin_feasible=len(good)/len(g),
          plugin_missing_cell_failures=int(g.plugin_status.isin([1,2]).sum()),
          plugin_lp_failures=int((g.plugin_status==3).sum()),
          plugin_endpoint_rmse=float(np.sqrt(np.mean(np.r_[
              (good.plugin_lower-population[0])**2,(good.plugin_upper-population[1])**2])))
              if len(good) else np.nan,
          outer_set_coverage=ok.mean(),coverage_mc_se=np.sqrt(ok.mean()*(1-ok.mean())/len(g)),
          coverage_mc_95_lower=float(coverage_lo[0]),coverage_mc_95_upper=float(coverage_hi[0]),
          outer_mean_width=width.mean(),outer_width_mc_se=width.std(ddof=1)/np.sqrt(len(g)),
          outer_failures=int((g.outer_status!=0).sum()),population_lower=population[0],
          population_upper=population[1],population_width=population[1]-population[0]))
    return pd.DataFrame(rows)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=200)
    parser.add_argument('--sizes',type=int,nargs='+',default=[1000,4000,16000,64000])
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--diagnostic',action='store_true')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    model=Model();population=model.population();assert population[2]==0
    plugin_pop=model.plugin(model.observed_probability*1e7)
    assert np.max(np.abs(np.array(plugin_pop[:2])-population[:2]))<1e-8
    truth=float(model.objective @ np.array([model.truth_law[a] for a in model.atoms]))
    assert population[0]<=truth<=population[1]
    rows=[];started=time.perf_counter()
    base=782000000 if args.diagnostic else 2027091700
    for j,n in enumerate(args.sizes):
        for r in range(args.reps):
            seed=base+100000*j+r
            counts=np.random.default_rng(seed).multinomial(n,model.observed_probability)
            pl,pu,ps=model.plugin(counts);lo,hi,status=model.confidence(counts)
            rows.append(dict(n=n,replication=r,seed=seed,plugin_lower=pl,plugin_upper=pu,
                             plugin_status=ps,outer_lower=lo,outer_upper=hi,outer_status=status))
        raw=pd.DataFrame(rows);raw.to_csv(args.out/'endpoint_inference_raw.csv',index=False)
        print(summarize(raw,population).tail(1).to_string(index=False),flush=True)
    summary=summarize(raw,population);summary.to_csv(args.out/'endpoint_inference_summary.csv',index=False)
    metadata=dict(kappa=.1,Gamma=.2,alpha=.05,scalar_intervals=model.interval_count,
                  observed_atoms=len(model.observed),latent_atoms=len(model.atoms),
                  true_contrast=truth,seconds=time.perf_counter()-started,
                  diagnostic=args.diagnostic,replications=args.reps,sizes=args.sizes,
                  plugin_status_codes={'0':'success','1':'empty history/action cell',
                                       '2':'empty complete-case outcome cell','3':'local LP failure'},
                  plugin_scope='two contrast-relevant second-stage local LPs; not global empirical-model feasibility',
                  population_endpoints=list(population[:2]))
    (args.out/'endpoint_inference_manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps(metadata,indent=2))


if __name__=='__main__':main()
