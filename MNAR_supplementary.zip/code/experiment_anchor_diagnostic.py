#!/usr/bin/env python3
"""Exact population diagnostic: observed-predictor anchors versus latent radii."""
import itertools
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from experiment_dynamic_grid import dgp, STATES, INITIAL

ROOT = Path(__file__).resolve().parents[1]


def weighted_quantile(values, masses, level=.95):
    order = np.argsort(values, kind='stable')
    values, masses = np.asarray(values)[order], np.asarray(masses)[order]
    assert np.all(masses >= 0) and abs(masses.sum()-1) < 1e-10
    index = np.searchsorted(np.cumsum(masses), level, side='left')
    return float(values[min(index, len(values)-1)])


def actual_violation(joint):
    result = 0.
    for y, z in itertools.product([-1, 1], repeat=2):
        row = sum(p for (yy, zz, r), p in joint.items() if yy == y)
        response = sum(joint[y, zz, 1] for zz in [-1, 1])
        pz = sum(joint[y, z, r] for r in [0, 1]) / row
        qz = joint[y, z, 1] / response
        result = max(result, abs(np.log(pz/qz)))
    return float(result)


def toy_examples():
    rows = []
    expected = [(0., abs(np.log(.64))), (np.log(3.25), 0.),
                (np.log(.892/.1), np.log(.9/.892))]
    for i, name in enumerate(['exact_shadow_positive_anchor',
                               'zero_anchor_positive_violation', 'rare_proxy_tail']):
        joint = {}
        for y, z, r in itertools.product([-1, 1], [-1, 1], [0, 1]):
            if i == 0:
                pz = .8 if z == y else .2
                pr = .8 if y == 1 else .2
            elif i == 1:
                pz = .75 if z == y else .25
                pr = .8 if z == y else .2
            else:
                pz = .01 if z == 1 else .99
                pr = .1 if z == 1 else .9
            joint[y, z, r] = .5*pz*(pr if r == 1 else 1-pr)
        assert abs(sum(joint.values())-1) < 1e-12 and min(joint.values()) > 0
        marginal_r = sum(p for (y, z, r), p in joint.items() if r == 1)
        masses, ratios = [], []
        for z in [-1, 1]:
            mass = sum(p for (y, zz, r), p in joint.items() if zz == z)
            full = sum(joint[y, z, 1] for y in [-1, 1])/mass
            masses.append(mass); ratios.append(abs(np.log(full/marginal_r)))
        gamma = actual_violation(joint)
        anchor = weighted_quantile(ratios, masses)
        assert np.allclose([gamma, anchor], expected[i], atol=1e-12)
        rows.append(dict(example=name, actual_Gamma=gamma, anchor_q95=anchor,
                         anchor_max=max(ratios), response_probability=marginal_r))
    return pd.DataFrame(rows)


def main():
    rows = []
    horizon = 6
    for q, b, kappa in itertools.product([.6, .8, .95], [-1.8, -.4, .8], [0., .04, .2, .5]):
        joint, transition, _ = dgp(q, b, kappa)
        gamma = max(actual_violation(joint(s, a)) for s in STATES for a in [0, 1])
        cells = []
        masses = dict(INITIAL)
        for t in range(horizon):
            nxt = defaultdict(float)
            for state, mass in masses.items():
                for a in [0, 1]:
                    kernel = joint(state, a)
                    prob = sum(v for (y, z, r), v in kernel.items() if r == 1)
                    cells.append(((t, *state, a), mass*.5/horizon, prob))
                    for ns, p in transition(t, state, a).items():
                        nxt[ns] += mass*.5*p
            masses = dict(nxt)
            assert abs(sum(masses.values())-1) < 1e-12
        for name, drop in [('previous_proxy', 1), ('previous_response', 2), ('action', 3)]:
            totals, positive = defaultdict(float), defaultdict(float)
            for key, mass, prob in cells:
                reduced = key[:drop]+key[drop+1:]
                totals[reduced] += mass; positive[reduced] += mass*prob
            values, weights = [], []
            for key, mass, prob in cells:
                reduced = key[:drop]+key[drop+1:]
                pred = positive[reduced]/totals[reduced]
                values.append(abs(np.log(prob/pred))); weights.append(mass)
            rows.append(dict(proxy_strength=q, observation_intercept=b, kappa=kappa,
                             omitted=name, actual_Gamma=gamma,
                             anchor_q95=weighted_quantile(values, weights),
                             anchor_max=max(values), observed_cells=len(cells),
                             missingness=sum(m*(1-p) for key, m, p in cells)))
    result = pd.DataFrame(rows)
    assert len(result) == 108 and result.observed_cells.eq(44).all()
    result.to_csv(ROOT/'results/anchor_diagnostic_grid.csv', index=False)
    toys = toy_examples(); toys.to_csv(ROOT/'results/anchor_diagnostic_examples.csv', index=False)
    summaries = result.groupby('kappa', sort=True).agg(
        gamma_min=('actual_Gamma', 'min'), gamma_max=('actual_Gamma', 'max'),
        anchor_min=('anchor_q95', 'min'), anchor_max=('anchor_q95', 'max'))
    summaries.to_csv(ROOT/'results/anchor_diagnostic_summary.csv')
    audit = dict(laws=36, predictor_omissions=3, rows=len(result),
                 exact_shadow_rows=int(result.kappa.eq(0).sum()),
                 exact_shadow_positive_anchors=int(((result.kappa==0)&(result.anchor_q95>1e-10)).sum()),
                 positive_radius_rows=int(result.kappa.gt(0).sum()),
                 positive_radius_anchor_below=int(((result.kappa>0)&(result.anchor_q95<result.actual_Gamma-1e-10)).sum()),
                 toy_closed_forms_verified=True, oracle_probabilities=True,
                 monte_carlo=False, fitted_predictions=False)
    (ROOT/'results/anchor_diagnostic_audit.json').write_text(json.dumps(audit, indent=2)+'\n')
    print(json.dumps(audit, indent=2)); print(toys.to_string(index=False)); print(summaries.to_string())


if __name__ == '__main__':
    main()
