#!/usr/bin/env python3
"""Independent validation of a two-stage, one-disagreement-history outer CI."""
import itertools
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from experiment_endpoint_inference import Model, cp_intervals
from experiment_ranking_certificates import law, summary

ROOT=Path(__file__).resolve().parents[1]
ATOMS=list(itertools.product([-1,1],[-1,1],[0,1]))  # Y,Z,R
OBS=sorted({(z,r,r*y) for y,z,r in ATOMS})
COARSE=np.array([[float((z,r,r*y)==o) for y,z,r in ATOMS] for o in OBS])
MEAN=np.array([y for y,z,r in ATOMS],dtype=float)


def local_outer(counts,gamma,scalar_error):
    total=int(np.sum(counts))
    plo,phi=cp_intervals(counts,np.full(len(counts),total),scalar_error)
    qx=np.array([sum(c for o,c in zip(OBS,counts) if o==(1,1,y)) for y in [-1,1]])
    qn=np.array([sum(c for o,c in zip(OBS,counts) if o[1:]==(1,y)) for y in [-1,1]])
    qlo,qhi=cp_intervals(qx,qn,scalar_error)
    rows=[*COARSE,*(-COARSE)];rhs=[*phi,*(-plo)]
    for j,y in enumerate([-1,1]):
        ymass=np.array([float(a[0]==y) for a in ATOMS])
        for z,lo,hi in [(1,qlo[j],qhi[j]),(-1,1-qhi[j],1-qlo[j])]:
            cell=np.array([float(a[:2]==(y,z)) for a in ATOMS])
            rows.extend([np.exp(-gamma)*lo*ymass-cell,cell-np.exp(gamma)*hi*ymass])
            rhs.extend([0.,0.])
    values=[]
    for sign in [1,-1]:
        fit=linprog(sign*MEAN,A_ub=np.array(rows),b_ub=np.array(rhs),
                    A_eq=np.ones((1,8)),b_eq=[1.],bounds=(0,None),method='highs')
        if not fit.success:return np.nan,np.nan,fit.status
        values.append(sign*fit.fun)
    return *values,0


def local_confidence(model,counts,alpha=.05):
    h=(1,-1,0,0)
    first=sum(c for o,c in zip(model.observed,counts) if o[0]==1)
    hcount=sum(c for o,c in zip(model.observed,counts) if o[:4]==h)
    plo,phi=cp_intervals(np.array([hcount]),np.array([first]),alpha/17)
    bounds={}
    for action in [0,1]:
        local=np.array([sum(c for o,c in zip(model.observed,counts)
                            if o[:5]==h+(action,) and o[5:]==outcome) for outcome in OBS])
        lo,hi,status=local_outer(local,model.gamma,alpha/17)
        if status:return np.nan,np.nan,status
        bounds[action]=(lo,hi)
    dlo=bounds[1][0]-bounds[0][1];dhi=bounds[1][1]-bounds[0][0]
    corners=[p*d for p in [float(plo[0]),float(phi[0])] for d in [dlo,dhi]]
    return min(corners),max(corners),0


def main():
    started=time.perf_counter();rows=[]
    validation_seeds={202709190000+1000000*j+100000*k+r
                      for j in range(4) for k in range(4) for r in range(200)}
    development=pd.read_csv(ROOT/'results/ranking_certificates_raw.csv')
    assert len(validation_seeds)==3200
    assert validation_seeds.isdisjoint(set(development.seed.astype(int)))
    for j,effect in enumerate([.6,2.4,-2.4,0.]):
        model=Model(truth_law=law(effect));pop=model.population();assert pop[2]==0
        truth=float(model.objective @ np.array([model.truth_law[a] for a in model.atoms]))
        for k,n in enumerate([1000,4000,16000,64000]):
            for r in range(200):
                seed=202709190000+1000000*j+100000*k+r
                counts=np.random.default_rng(seed).multinomial(n,model.observed_probability)
                for method,fn in [('trajectory',model.confidence),
                                  ('contrast_local',lambda c:local_confidence(model,c))]:
                    lo,hi,status=fn(counts)
                    rows.append(dict(method=method,effect=effect,n=n,replication=r,seed=seed,
                                     outer_lower=lo,outer_upper=hi,outer_status=status,
                                     population_lower=pop[0],population_upper=pop[1],true_contrast=truth))
            print('completed',effect,n,flush=True)
    raw=pd.DataFrame(rows);raw.to_csv(ROOT/'results/local_confidence_raw.csv',index=False)
    summaries=[]
    for method,g in raw.groupby('method',sort=False):
        out=summary(g);out.insert(0,'method',method);summaries.append(out)
    pd.concat(summaries,ignore_index=True).to_csv(ROOT/'results/local_confidence_summary.csv',index=False)
    meta=dict(paired_replications=3200,methods=['trajectory','contrast_local'],alpha=.05,
              interval_counts={'trajectory':196,'contrast_local':17},seconds=time.perf_counter()-started,
              independent_of_development_runs=True,local_scope='two stages, shared first action, one disagreement history')
    (ROOT/'results/local_confidence_manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2))


if __name__=='__main__':main()
